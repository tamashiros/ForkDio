---
name: Community Challenge
about: Crie uma issue sobre o Desafio proposto à comunidade
title: "[DESAFIO]"
labels: community challenge
assignees: ''

---

*Tem alguma sugestão para quem for fazer o Desafio? Por favor descreva.*
Uma descrição do que pode ser feito. 

*Descreva como você realizou o seu*
Uma descrição sobre como você fez o seu.

*Links úteis*
- [Nome do Link](URL)
