### Olá, eu sou Alessandro Cipriano 👍

✨ **Aluno no SANTANDER BOOTCAMP** na [DIO](https://dio.me) e estudante de Sistemas de Informação na Estácio.

🏢 **Atuação Profissional**
- ✒ Designer Gráfico e Animação 🎬.
- 💻 Muita vontade de criar aplicativos!📱

### 📊 Estatísticas no GitHub

![Alessandro's GitHub stats](https://github-readme-stats.vercel.app/api?username=Ale-cipriano&show_icons=true&theme=dracula)

### 📌 Projetos em Destaque



[![AndroidOtsIntroAleb](https://github.com/Ale-cipriano/ots_python_web)](https://github.com/Ale-cipriano/AndroidOtsIntroAle)




### 🚀 Linguagens Mais Usadas

![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=Ale-cipriano&layout=compact)
