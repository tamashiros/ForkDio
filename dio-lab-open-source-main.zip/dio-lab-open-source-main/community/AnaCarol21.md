# Bem vindo ao meu perfil!
## Olá!
 Eu me chamo Ana, formada em Análise e Desenvolvimento de Sistemas e estou participando do bootcamp Santander - Backend com java.

## Habilidades
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AnaCarol21&layout=compact&bg_color=000&border_color=30A3DC&title_color=30A3DC&text_color=FFF)

## Github Status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AnaCarol21&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=30A3DC&text_color=FFF)

## Minhas contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AnaCarol21&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=30A3DC&text_color=FFF)](https://github.com/AnaCarol21/dio-lab-open-source)

## Links
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/ana-lima-6957431a5/)
[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AnaCarol21)