<div align="center">
  <img src="https://komarev.com/ghpvc/?username=Amanda-ribeiiro0&color=blue&style=flat" alt="Profile Views">
  <a href="https://github.com/Amanda-ribeiiro/"><img src="https://img.shields.io/github/followers/Amanda-ribeiiro?color=%234CC61E&label=GitHub%20Followers%20%3A"/></a>
</div>

<p align="center">
  <img src="https://readme-typing-svg.herokuapp.com?font=Caveat&weight=600&size=45&duration=4000&pause=1000&color=F4FFF9&center=true&vCenter=true&repeat=false&width=435&lines=Hi!+my+name+is+Amanda" alt="Typing SVG">
  <img src="https://github.githubassets.com/images/icons/emoji/octocat.png" width="40" height="40">
</p>

<p align="center">
  <a href="https://git.io/typing-svg">
    <img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&weight=600&size=25&duration=3000&pause=1000&color=F731F1&background=FF27D500&vCenter=true&multiline=true&width=435&lines=Developer+FullStack" alt="Typing SVG">
  </a>
</p>


### Conecte-se comigo:
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/amanda_ribeiro98) [![Linkedin Badge](https://img.shields.io/badge/-Amanda%20Ribeiro-0066A1?style=flat-square&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/amandarcerqueira/)](https://www.linkedin.com/in/amandarcerqueira//) [![Discord](https://img.shields.io/discord/1001854951514963978?label=discord&logo=discord&logoColor=violet)](https://discord.com/channels/999175108256092251) [![Twitch: amrcerq](https://img.shields.io/badge/-Twitch-blueviolet?style=flat-square&logo=Twitch&logoColor=white&link=https://www.twitch.tv/amrcerq)](https://www.twitch.tv/amrcerq) [![Twitter Follow](https://img.shields.io/twitter/follow/daaribeiro_?style=social)](https://twitter.com/daaribeiro_)

<p align="center">
  <a href="https://github.com/Amanda-ribeiiro/">
     <img width="100%" src="https://github-widgetbox.vercel.app/api/profile?username=Amanda-ribeiiro&data=followers,repositories,stars,commits&theme=aether" alt="GitHub WirdgetBox" />
  </a>
  <a href="https://github.com/Amanda-ribeiiro/github-readme-streak-stats">
    <img title="🔥 Get streak stats for your profile at git.io/streak-stats" alt="vitorkol's streak" src="https://github-readme-streak-stats.herokuapp.com/?user=Amanda-ribeiiro&theme=monokai-metallian&hide_border=true"/>
  </a>
</p>





<div alig="left">
   <p align="right"><a href="https://github.com/Amanda-ribeiiro?tab=repositories"><img alt="All Repositories" title="All Repositories" src="https://custom-icon-badges.herokuapp.com/badge/-All%20Repos-2962FF?style=for-the-badge&logoColor=white&logo=repo"/></a></p>
</div>
