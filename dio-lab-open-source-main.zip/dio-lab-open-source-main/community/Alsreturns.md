# Oi! Eu sou o Artur! 

Quem sou eu:
- 👦 Sou engenheiro mecânico e trabalho com gestão de projetos
- 💻 Iniciando os estudos sobre Data Analytics e Data Science.
- 💪  Apaixonado por musculação
- 📕 Amo leitura

<div align="center">
 <h3>📊 Github Analytics</h3>
  <img width="49%" height="195px" src= "https://github-readme-stats.vercel.app/api?username=Alsreturns&show_icons=true&theme=tokyonight" /> 

</div>

<div style="display: inline_block"><br>
  <h3>⚙️ Tools</h3>
  <img align="center" alt="Excel" height="40" width="40" src="https://img.icons8.com/?size=512&id=UECmBSgBOvPT&format=png"/>
  <img align="center" alt="Project" height="40" width="40" src="https://img.icons8.com/?size=512&id=7lJtplrxEIbD&format=png"/>
  <img align="center" alt="Power Point" height="40" width="40" src="https://img.icons8.com/?size=512&id=81726&format=png"/>
  <img align="center" alt="Python" height="40" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  
  
</div>


<div> 
  <h3>📍 Contatos</h3>
  <a href="https://www.instagram.com/_alsantos_/" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href = "mailto:arturlsantos1@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/arturlsantos/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 

</div>




  
<h5> Artur Lima Santos 😄 <h5>


