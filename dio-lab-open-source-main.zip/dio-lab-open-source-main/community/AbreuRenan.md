# Renan Abreu

## Sobre mim

Olá! Meu nome é Renan Abreu, atuo na área de tecnologia a quase 10 anos e agora busco evoluir minha carreira na área de programação. Gosto bastante da área, e já uso algumas linguagens como PHP, SQL, JavaScript. Atualmente estudo para ter as competências necessárias para fazer um projeto do 0 ao deploy, meus últimos projetos são o **[https://www.brissy.com.br](brissy.com.br)** e o **[https://paos.pt](paos.pt)** . Meu objetivo é me tornar um desenvolvedor fullstack para atender as demandas de ponta a ponta.

### Habilidades

- PHP
- SQL
- JavaScript
- React
- HTML
- CSS
- Apache e Nginx
- Nodejs
- git e github

## Contato

- GitHub: [https://github.com/AbreuRenan](https://github.com/AbreuRenan)
- LinkedIn: [https://www.linkedin.com/in/renan-abreu-46a29069/](https://www.linkedin.com/in/renan-abreu-46a29069/)
