## 🚀 Sobre mim

Em breve serei uma pessoa desenvolvedora full-stack...


Louco e Sonhador, iniciante em programação. Apaxonado por Linux, e ancioso para trabalhar na área de TI. Me aguardem!

att: Alan Mendes
