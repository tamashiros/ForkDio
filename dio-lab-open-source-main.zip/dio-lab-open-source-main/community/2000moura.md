## Saudações, visitante!

Me chamo João Gabriel Amaral de Moura, tenho 23 anos. Sou graduando de engenharia eletrônica e de telecomunicações na Universidade Federal de Uberlândia.

> https://www.linkedin.com/in/2000moura/

≈ 2 anos de estudos e prática em Java.
≈ 3 anos de estudos e prática em C#.
≈ 6 anos de estudos e prática em C++.
