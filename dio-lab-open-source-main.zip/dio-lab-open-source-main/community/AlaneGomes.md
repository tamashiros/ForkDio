# Olá, eu sou Alane Gomes 👋🏻
Sou estudante da Sistemas de Informação, estou em um emocionante período de transição de carreira rumo à tecnologia, com um foco particular na área de desenvolvimento Web Backend!

## 📚 Hard Skills
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5&logoColor=)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=blue)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=blue)
![.NET](https://img.shields.io/badge/.NET-000?style=for-the-badge&logo=.net&logoColor=purple)
![Git](https://img.shields.io/badge/GIT-000?style=for-the-badge&logo=git&logoColor=)
![Vscode](https://img.shields.io/badge/Vscode-000?style=for-the-badge&logo=visual-studio-code&logoColor=blue)
![NodeJS](https://img.shields.io/badge/node.js-000?style=for-the-badge&logo=node.js&logoColor=)

## 📲 Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=blue)](https://www.linkedin.com/in/alane-gomes)
[![Instagram](https://img.shields.io/badge/-Instagram-000?style=for-the-badge&logo=instagram&logoColor=)](https://www.instagram.com/alane.gomess/)
[![Gmail](https://img.shields.io/badge/Gmail-000?style=for-the-badge&logo=gmail&logoColor=red)](mailto:alane.gomes91@gmail.com)
[![Portfolio](https://img.shields.io/badge/Portfolio-000?style=for-the-badge&logo=todoist&logoColor=)](https://seulink.com)
## GitHub Stats



