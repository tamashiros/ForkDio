<div align="center" style="text-align: center;">
 <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.herokuapp.com?font=Archivo+Black&pause=1000&color=BF2CF7&center=true&random=false&width=500&height=65&lines=Oii%2C+Sou+a+Adrielle+%F0%9F%96%90%F0%9F%8F%BC;Estudante+de+Ads+e+Designer+%F0%9F%91%A9%F0%9F%8F%BD%E2%80%8D%F0%9F%92%BB%F0%9F%96%8C%EF%B8%8F;Sinta+se+a+vontade+para+me+conhecer+%F0%9F%92%9C" alt="Typing SVG" /></a>
 
</div>
<p align="center">
  <a href="https://adjcds.github.io/portfolio/home.html">
   <img src="https://img.shields.io/badge/Portfólio-6A5ACD?style=for-the-badge&logo=&logoColor=white" alt="blog">
  </a>
  <a href="https://www.linkedin.com/in/ajcds/">
    <img src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white" alt="linkedin">
  </a>
  <a href="https://www.instagram.com/starvalentz/">
    <img src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white" alt="instagram">
  </a>
</p>
🚀 Atualmente, atuo como Jovem Aprendiz na Unimed, desempenhando o papel de auxiliar na farmácia por meio do CIEE. Essa experiência não só me proporciona a oportunidade de financiar meu curso, mas também representa um passo crucial em direção à realização do meu sonho: conquistar uma vaga de desenvolvedora.
<h2 align="center">👩‍💻Principais tecnologias:</h2>
<div align="center">
  <img src="https://skillicons.dev/icons?i=html,css,js,nodejs,react,vscode,figma,&perline=14" />
</div>

<h2 align="center">🚀Estudando tecnologias:</h2>
<div align="center">
<img src="https://skillicons.dev/icons?i=py,cs,java,react,nodejs,c#,mysql,git,github,&perline=14" />
<div/>
<div/>
<br>
 <h2 align="center">Principais projetos:</h2>
<p align="center">
  <a href="https://adjcds.github.io/portfolio/home.html">
   <img src="https://img.shields.io/badge/Portfólio-6A5ACD?style=for-the-badge&logo=&logoColor=white" alt="blog">
  </a>
  <a href="https://gelateria-delta.vercel.app/">
    <img src="https://img.shields.io/badge/Sorveteria-FFE4B5?style=for-the-badge&logo=&logoColor=white" alt="linkedin">
  </a>
