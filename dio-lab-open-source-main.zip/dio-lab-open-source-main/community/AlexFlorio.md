# Olá, eu sou o Alex! 😎

## 📝 Sobre mim
Sou analista de sitemas!
Estou na área de tecnologia há 6 anos e ingressei no mercado de trabalho após concluir meu Bacharelado em Ciências da Computação.

# Habilidades
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)

📫 Como entrar em contato comigo através das minhas redes abaixo:<br>

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/aleexflorio/)
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)][def]

[def]: https://www.dio.me/users/alex_florio