## Olá, meu nome é Alex👋

**💻 O que é este projeto?**
- Este projeto faz parte de uma contribuição para o projeto open source da DIO, o [dio-lab-open-source](https://github.com/digitalinnovationone/dio-lab-open-source).

**Meus Certificados:**

✔ Metodologia Agil.

✔ Flutter

✔ HTML e CSS

✔ JavaScript

✔ Word e Excell

### 🚀 Sobre mim

- Atualmente estou no 5ºPeriodo do curso de Gestão da Informação na UFPE e tenho o desejo de começar a trabalhar no mercado de programação. 

- Resumidamente, tenho experiência como freelancer em Implantação de sistema ERP MarketUp em nuvem e suporte remoto e tratamento de dados.


- Possuo Inglês avançado e também conhecimento em WordPress e Banco de Dados.

####  Para me conhecer melhor, acesse:
 [![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alex-de-jesus/)