# Oi, eu sou o Alisson! 😁

## Sobre mim

Me chamo Alisson, tenho 27 anos de idade e sonho em ser um desenvolvedor Full-Stack JAVA.

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alissonsilva07/)

[![Twitter](https://img.shields.io/badge/Twitter-000?style=for-the-badge&logo=twitter)](https://twitter.com/Alisson_Silva07)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/alisson_silva07)

## Habilidades

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

![Sass](https://img.shields.io/badge/Sass-000?style=for-the-badge&logo=sass)

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)

![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)

![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=angular&logoColor=C3002F)

## Github Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlissonSilva07&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas Contribuicoes

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AlissonSilva07&repo=fake-store&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/SEUUSERNAME/SEUREPOSITORIO)



