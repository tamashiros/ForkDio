Abilene Ranane Carvalho Sanches
(Campina Grande,PB – BRASIL)

Área Afins: Ciência de Dados (SQL, Linguagem R, Python), Computação em Nuvem e Mobile (Swift).

Olá, meu nome é Abilene Ranane Carvalho Sanches, sou muito curiosa e gosto de enfrentar desafios que me levem a mergulhar em uma área que acredito ser um caminho certo.
A inovação faz parte de uma trilha que ajudará a compreender muito esse mundo da tecnologia, no qual é uma jornada profissional no qual podemos explorar todas as
que proporciona um encantamento com todo o processo desenvolvido no trajeto de boas práticas e análises, assim ajudando a buscarmos ao nosso sucesso.
Sou Graduado em Sistemas de Informação, estou em busca da minha primeira experiência no mercado, desenvolve códigos de acordo com o cronograma da faculdade e
cursos/tutoriais aprendendo de acordo com minha área de interesse. Uma profunda pensadora criativa que aprecia trabalhar em equipe e com ideias inovadoras estou
sempre pronto para me desenvolver habilidades e competências que o mercado procura.
Desejo colaborar em um ambiente de trabalho dinâmico, onde posso colocar em prática meus conhecimentos em benefício e o crescimento da organização e o crescimento profissional.
