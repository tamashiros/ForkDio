# Bem vindo 


Olá, seja bem vindo(a) ao meu perfil, aqui você ira poder encontrar algumas das minhas habilidades.

## Sobre mim
Meu nome é Guilherme atualmente tenho 17 anos e estudo no IFRJ e estou em um curso ligado a área da tecnologia. 

## Habilidades
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)

![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)

![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)

![C#](https://img.shields.io/badge/C%23-381575?style=for-the-badge&logo=c-sharp&logoColor=white)

![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Ahlkimyst)
