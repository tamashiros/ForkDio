# AGEM20

Olá! Sou AGEM20, um entusiasta da tecnologia apaixonado por programação e desenvolvimento web.

## Sobre Mim

- 🌱 Atualmente, estou aprendendo mais sobre inteligência artificial e machine learning.
- 💼 Trabalho como desenvolvedor de software.
- 🎓 Bacharel em Sistemas de Informações.

## Projetos

- [Projeto 1](https://github.com/seu-usuario/projeto-1): Uma breve descrição do projeto.
- [Projeto 2](https://github.com/seu-usuario/projeto-2): Outra breve descrição do projeto.

## Estatísticas do GitHub

![Estatísticas do GitHub](https://github-readme-stats.vercel.app/api?username=AGEM20&show_icons=true)

## Contato

- [GitHub](https://github.com/AGEM20)
- [LinkedIn](https://www.linkedin.com/in/alberto-rodrigues-lopes-pcd-791b4427/)
- Email: alberto.rodrigueslopes@gmail.com

