### Olá, eu sou o Alexandre Costa (AleCosta00) 😉

Tenho 27 anos, sou estudante de Análise e Desenvolvimento de Sistemas 💻

| Dinâmico e Apaixonado por Tecnologia

## Conecte-se Comigo 📡

[![Instagram](https://img.shields.io/badge/-Instagram-FFF?style=for-the-badge&logo=instagram)](https://www.instagram.com/alecosta_andrade/)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-FFF?style=for-the-badge&logo=linkedin&logoColor=blue)]([https://www.linkedin.com/in/SEUUSERNAME/](https://www.linkedin.com/in/alexandre-costa-6b7018158/))
[![Gmail](https://img.shields.io/badge/Gmail-FFF?style=for-the-badge&logo=gmail&logoColor=red)](mailto:alecostajj@gmail.com)

## Habilidades 🏆

![HTML5](https://img.shields.io/badge/HTML5-FFF?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-FFF?style=for-the-badge&logo=css3&logoColor=blue)
![Markdown](https://img.shields.io/badge/Markdown-FFF?style=for-the-badge&logo=markdown&logoColor=black)
![Java](https://img.shields.io/badge/java-FFF?style=for-the-badge&logo=openjdk&logoColor=black)
![Python](https://img.shields.io/badge/python-FFF?style=for-the-badge&logo=python&logoColor=yellow)
![C](https://img.shields.io/badge/C-FFF?style=for-the-badge&logo=c&logoColor=blue)
![MySQL](https://img.shields.io/badge/MySQL-FFF?style=for-the-badge&logo=mysql&logoColor=black)

## GitHub Stats ✅

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AleCosta00&theme=transparent&bg_color=FFF&border_color=black&show_icons=true&icon_color=black&title_color=black&text_color=black)

## Minhas Contribuições 🤙🏻

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AleCosta00&repo=dio-lab-open-source&bg_color=FFF&border_color=black&show_icons=true&icon_color=black&title_color=black&text_color=black)](https://github.com//dio-lab-open-source)
