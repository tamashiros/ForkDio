### Sobre Mim 𓃠
Nome: Ana Beatriz Mamprin

Idade: 25 anos

Análise e Desenvolvimento de Sistemas — FATEC Guarulhos — 2º semestre

Amante de gatos e sorvete. 🐈‍🍨

### Redes Sociais
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/ana-beatriz-mamprin/)
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://www.discord.com/channels/@.anabm/)
[![DIO.me](https://img.shields.io/badge/DIO.me-000?style=for-the-badge&logo=dio-me)](https://www.dio.me/users/ana_b_mamprin)

### Habilidades
![Microsoft Access](https://img.shields.io/badge/Access-000?style=for-the-badge&logo=microsoft-access)
![Power BI](https://img.shields.io/badge/Power_BI-000?style=for-the-badge&logo=power-bi)
![VBA](https://img.shields.io/badge/Visual_Basic-000?style=for-the-badge&logo=visual-basic)

### Estudando
![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)

### Status

![AnaBMamprin's GitHub stats](https://github-readme-stats.vercel.app/api?username=AnaBMamprin&theme=nightowl&show_icons=true)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AnaBMamprin&theme=nightowl&show_icons=true)

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/mari4souza/mari4souza/output/github-contribution-grid-snake-dark.svg">
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/mari4souza/mari4souza/output/github-contribution-grid-snake.svg">
  <img alt="github contribution grid snake animation" src="https://raw.githubusercontent.com/mari4souza/mari4souza/output/github-contribution-grid-snake.svg">
</picture>