# - 👋 Olá, eu sou Amanda!

Sou designer, com foco em produtos digitais e experiência do usuário. Atualmente, procuro recolocação no mercado e achei pertinente aprender uma coisa nova e cá estou!
Aprender programação do zero pra melhorar minhas entregas e vai que pego o jeito e me torno programadora?!

## Conecte-se Comigo
[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AmandaZanatta)

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/amanda-zanatta/)

[![Portfolio](https://img.shields.io/badge/Portfolio-FF5722?style=for-the-badge&logo=todoist&logoColor=white)](https://www.amandazanatta.com/)
