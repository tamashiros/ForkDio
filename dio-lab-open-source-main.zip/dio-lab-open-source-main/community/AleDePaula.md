# ALEXANDRE DE PAULA
### Muito prazer! Meu nome é Alexandre de Paula

Sou **Fonoaudiólogo** e tenho 40 anos. Amo a fonoaudiologia e o trabalho com a Voz.
Também sou cantor e professor de canto.

Você deve estar se perguntando o que estou fazendo aqui.
Desde pequeno, tenho o sonho de trabalhar na industria de jogos. Sempre estou inventando e criando jogos e histórias para jogos, imaginando jogabilidades e estilos. Então vi na DIO a possibilidade de perseguir esse sonho de criar jogos.

Meus jogos favoritos: 

- Série Fallout
- Série Elder Scrolls (Jogo desde o III: Morrowind)
- Zeldinha Ocarina of Time, BotW e TotK (Goty de coração)
- Série Mass Effect
- Minecraft (com mods, claro)
- Factorio
- RimWorld
- POKEMON (Iron Valiant é o mais legal)
---
### Estou estudando:

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)	![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)![Bootstrap](https://img.shields.io/badge/-boostrap-0D1117?style=for-the-badge&logo=bootstrap&labelColor=0D1117)![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)![C++](https://img.shields.io/badge/C%2B%2B-00599C?style=for-the-badge&logo=c%2B%2B&logoColor=white)![C#](https://img.shields.io/badge/C%23-239120?style=for-the-badge&logo=c-sharp&logoColor=white)
![Godot Engine](https://img.shields.io/badge/GODOT-%23FFFFFF.svg?style=for-the-badge&logo=godot-engine)	![Unity](https://img.shields.io/badge/unity-%23000000.svg?style=for-the-badge&logo=unity&logoColor=white)![Unreal Engine](https://img.shields.io/badge/unrealengine-%23313131.svg?style=for-the-badge&logo=unrealengine&logoColor=white)

---
### ME ACHE AQUI:

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)](https://github.com/AleDePaula)	
[![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/fonogamer/)

[![Steam](https://img.shields.io/badge/steam-%23000000.svg?style=for-the-badge&logo=steam&logoColor=white)](https://steamcommunity.com/id/gelaman/)![Xbox](https://img.shields.io/badge/xbox-%23107C10.svg?style=for-the-badge&logo=xbox&logoColor=white)






