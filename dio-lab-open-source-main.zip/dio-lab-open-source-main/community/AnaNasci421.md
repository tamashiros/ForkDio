<h1> 
  <a href="https://www.linkedin.com/in/ana-luiza-nascimento-331a46159/" style="color: #FFF !important; text-decoration: none; color: inherit;">
    <span>Ana Luiza Nascimento</span>
  </a>
</h1>

#### Software Engineer | Full Stack Developer 

_Olá, me chamo Ana Luiza sou estudante de Engenharia de Software e trabalho atualmente na área de Desenvolvimento._

_Atualmente participo do  BootCamp Santandar 2024 oferecido pela DIO, estou atualmente terminando a aula de Contribuindo em um Projeto Open Source no GitHub._

_Obrigado pela atenção. 🚀_

<i>(Barueri, SP - Brasil)</i>

## GitHub Stats

_Acompanhe todo meu Desenvolvimento no GitHub_

[![GitHub Streak](https://streak-stats.demolab.com/?user=AnaNasci421&theme=bear&background=FFF&border=FFF&dates=00aeff)](https://git.io/streak-stats)


## Conecte-se 

[![LinkedIn](https://img.shields.io/badge/linkedin-%23e03c8a.svg?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/ana-luiza-nascimento-331a46159/)
[![E-mail](https://img.shields.io/badge/-Email-e03c8a?style=for-the-badge&logo=microsoft-outlook&logoColor=white)](mailto:analuiza.analuiza2002@hotmail.com)
[![GitHub](https://img.shields.io/badge/GitHub-e03c8a?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AnaNasci421)
[![Perfil DIO](https://img.shields.io/badge/-Perfil%20Da%20DIO-e03c8a?style=for-the-badge&logo=gitbook&logoColor=white)](https://www.dio.me/users/analuiza_analuiza2002)




