<img src="https://github-production-user-asset-6210df.s3.amazonaws.com/97841160/263562401-9669836f-60c9-4239-87bb-5d8f7d60f008.png" min-width="400px" max-width="400px" width="400px" align="right">

<p align="left"> 
  Olá eu sou <b>Tiago</b> <i>Desenvolvedor de software</i> em desenvolvimento!😁
  Sem mais trocadilhos irei contar um pouco sobre mim.<br>
  Um jovem estudante de <strong>engenharia de software</strong> focado na area de front-end. Atualmente acumulo conhecimento em React, React-Native, Angular, Styled-components, Sass, Tailwindcss, Nodejs, Express, TypeScript, Redux, Jest e 🚀
</p>

<p align="left">
  <h3>💻 Por que a Tecnologia?</h3>
  <p>Acretido que posso impactar as pessoas com a tecnologia. Sempre fui apaixonado por esta área e em tudo que fiz até agora penso em ideias de melhoria com o uso da tecnologia. </p>
</p>

<p align="left">
   <h3>🚀 Por que front-end?</h3>
  <p>
    Sou uma pessoa muito visual e me agrada muito transformar código em intefaces que seja incrivelmente intuitiva e acessivel. É onde o usuário final vai acessar
  </p>
</p>

<p align="left">
   <h3>📨 Vamos trocar uma ideia? </h3> 

  <a href="mailto:7iagocabral@gmail.com" alt="Gmail">
  <img src="https://img.shields.io/badge/-Gmail-FF0000?style=flat-square&labelColor=FF0000&logo=gmail&logoColor=white&link=LINK-DO-SEU-GMAIL" /></a>

  <a href="https://www.linkedin.com/in/7iagocabral/" alt="LinkedIn">
  <img src="https://img.shields.io/badge/-Linkedin-0e76a8?style=flat-square&logo=Linkedin&logoColor=white&link=LINK-DO-SEU-LINKEDIN" /></a>

  <a href="https://instagram.com/7iagocabral" alt="Instagram">
  <img src="https://img.shields.io/badge/-Instagram-DF0174?style=flat-square&labelColor=DF0174&logo=instagram&logoColor=white&link=LINK-DO-SEU-INSTAGRAM"/></a>
</p>

## Projetos

[🏛️ Blog Museu Nacional - Angular ](https://github.com/7iagoCabral/blog-museum-angular)<br>
[✅ BuzzFeed - Angular ](https://github.com/7iagoCabral/angular_buzzfeed_quizz)<br>
[🐦 PokeStore - React, Sass, Redux](https://github.com/7iagoCabral/pokestore)<br>
[❌ Jogo da velha - javascript](https://github.com/7iagoCabral/tic-tac-toe-Jogo-da-velha-)<br>
[🚀 NASA - Foto Astronômica do Dia - React, Tailwindcss, Api rest ](https://github.com/7iagoCabral/nasa-apod-Imagem-Astronomica-do-Dia)<br>
