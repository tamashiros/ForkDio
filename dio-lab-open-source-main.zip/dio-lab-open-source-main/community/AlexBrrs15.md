# Olá! eu sou o Alexandro 👋🏻


### Meu nome é Alexandro sou de São João dos Patos - MA, tenha uma formação em tecnologia em Redes de Computadores pelo IFMA.



## Redes Sociais

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=fff)](www.linkedin.com/in/alexandro-barroso-35b0921b9)
 [![Instagram](https://img.shields.io/badge/Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=fff)](https://www.instagram.com/alexxbarroso?utm_source=qr&igsh=YXZxazlld2ltN3Jm) [![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:alexxbarros4@gmail.com)

## Linguagens
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)

## Linguagens de Marcação e Estilo

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)

## Ferramentas
![Git](https://img.shields.io/badge/Git-black?style=for-the-badge&logo=git&logoColor)



## GitHub Stats

![AlexBrrs15 GitHub stats](https://github-readme-stats.vercel.app/api?username=AlexBrrs15&theme=tokyonight&_icons=true&hide_title=true)

[![GitHub Streak](https://streak-stats.demolab.com/?user=AlexBrrs15&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)
