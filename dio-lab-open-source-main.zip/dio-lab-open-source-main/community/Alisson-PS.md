
# Alisson Pereira
Olá, sou Alisson Pereira. Graduado em Análise e Desenvolvimento de Sistemas. Sou mais um louco por desenvolvimento, onde procuro adquirir mais conehcimento e experiencias para aprimorar Soft e Hard Skills. 

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)]([https://web.dio.me/users/SEUUSERNAME/](https://www.dio.me/users/alisson_ps08_38106))
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=fff)]([https://www.linkedin.com/in/SEUUSERNAME/](https://www.linkedin.com/in/alisson-pereira-7309596b/))




### Habilidades
![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=fff)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=fff)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=fff)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=fff)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://docs.github.com/)
![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=fff)


![ ](https://github-readme-stats.vercel.app/api?username=Alisson-PS&theme=transparent&bg_color=000&border_color=&show_icons=true&icon_color=30A3DC&title_color=fff&text_color=fff&hide_title=true&hide=stars)