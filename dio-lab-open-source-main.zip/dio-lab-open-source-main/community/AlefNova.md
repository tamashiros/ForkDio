## 🚀 Alef Nova

Olá, sou formado em técnico em plásticos pelo SENAI Mario Amato, me formei no ano de 2016, e desde de então atuo na área industrial, buscando sempre me aperfeiçoa como profissional e pessoalmente.
Atualmente estou estudando bootcamps com a DIO onde busco me aperfeiçoa gradativamente.

## Habilidades

![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)


## Github Stats 
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlefNova&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


## Conecte-se comigo😉

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alef-dos-santos-a6428314a/)

[![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/alefdsbn/)

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AlefNova)
