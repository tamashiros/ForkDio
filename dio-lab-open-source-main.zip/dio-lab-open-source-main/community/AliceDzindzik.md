# Alice Dzindzik

Me chamo Alice, tenho 18 anos e moro no interior de Rondônia! 
Sempre fui apaixonada por tudo que envolve tecnologia, mas não tive  oportunidade de iniciar de cara nela. Cursei Arq e Urb durante um ano, onde percebi que odiava aquele curso, e realmente gostava de tecnologia e tudo que envolvesse numeros, foi onde decidi trocar o curso, e iniciei no mundo da tecnologia, atualmente cursando Ciência da Computação.
Backend é o meu principal foco.

# Conecte-se comigo!
[![Linkedin]](https://www.linkedin.com/in/alice-dzindzik/)
[![Github]](https://github.com/AliceDzindzik)
[![Dio]](https://dio.me/users/alicedzindzik8)