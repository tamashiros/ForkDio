# **Alex Felipe Honório**
Estou iniciando e estudando a área de programação com intuito de me desenvolver e me aprimorar para o meu futuro!

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alex-hon%C3%B3rio-70a0a3303/)
[![Instagram](https://img.shields.io/badge/-Instagram-FFF?style=for-the-badge&logo=instagram)](https://www.instagram.com/_alex.felipe/)
[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AlexFelipeHonorio)
[![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:alexfelipehonorio@gmail.com)

## Minhas Habilidades
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)

## Aprimorando
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![Java](https://img.shields.io/badge/Java-%23ED8B00?style=for-the-badge&logo=openjdk&logoColor=White)

## Ferramentas que utilizo
![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)
![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)

## GitHub Status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlexFelipeHonorio&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Desafios Participados
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AlexFelipeHonorio&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/AlexFelipeHonorio/dio-lab-open-source)