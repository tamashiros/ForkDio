
---

# Alessandro Tregansin

# Quem sou eu?
Olá, me chamo Alessandro Diogo Tregansin, estou começando a minha caminhada nesse fascinante mundo da TI, sou estudante em Análise e Desenvolvimento de Sistemas, no momento trabalho na área da metalurgia e estou buscando uma oportunidade para estagiar. Estou sempre buscando evolução, apreendizado e novos desafios.
Para o lado pessoal, gosto de me exercitar, correr e fazer musculação, gosto de ouvir música e sou um grande fã de games.

### Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alessandro-diogo-tregansin-67178599/)
[![E-mail](https://img.shields.io/badge/-Gmail-FF0000?style=flat-square&labelColor=FF0000&logo=gmail&logoColor=white&link=LINK-DO-SEU-GMAIL)](mailto:alessandrotregansin@gmail.com)

## Habilidades
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alemetall&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Alemetall&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/AlessandroGZaros/dio-lab-open-source)

## Resumo

Atualmente estou terminando o 2º semestre de Análise e Desenvolvimento de Sistemas na Uniftec.