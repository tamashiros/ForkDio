<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=D41b22&height=180&section=header&text=Alex+Souza&fontSize=25&fontColor=ffffff&animation=twinkling&fontAlignY=35"/>

## [![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=ffffff&size=35&center=true&vCenter=true&width=1000&lines=Olá,+Seja+Bem-Vindo+ao+meu+mundo+:%29;Hello,+Welcome+to+my+world!+:%29;)](https://git.io/typing-svg)



Olá! Me chamo Alex e sou desenvolvedor atualmente cursando Análise e Desemvolvimento de Sistemas.

Estou buscando minha primeira oportunidade de trabalho e me interesso principalmente por tecnologias relacionadas a backend e fullstack, gosto bastante da área de desenvolvimento e estou bem aberto as dviversas opotunidadesn que esse mervadp tem a oferecer.

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/alexsolliveira9/) 
[![E-mail](https://img.shields.io/badge/-Gmail-000?style=for-the-badge&logo=Gmail&logoColor=E94D5F)](mailto:alexsolliveira9@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/alex-souza-b19224117/)


### Habilidades
![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=fd7e14)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=339af0)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=fcc419)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F) 
![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=f8f9fa)


### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alexjacsouza50&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF&hide=stars)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Alexjacsouza50&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

### Meus Principais Desafios de Projeto DIO
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=Alexjacsouza50&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Alexjacsouza50/dio-lab-open-source)
