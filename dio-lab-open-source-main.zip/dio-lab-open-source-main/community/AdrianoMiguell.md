![Adriano miguel](https://github.com/AdrianoMiguell/AdrianoMiguell/blob/main/banner-my-github2.png)

<div align="center">
   
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=30&pause=1000&color=70A5FD&center=true&width=600&height=100&lines=Hello+World!;My+name+is+Adriano+Miguel;I+really+like+programming;and+solving+challenges)](https://git.io/typing-svg)

</div>


## Stars and Contribui


<div align="center">
  <a href="https://github.com/AdrianoMiguell">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=AdrianoMiguell&show_icons=true&theme=tokyonight&include_all_commits=true&count_private=true"/>
  
  [![GitHub Streak](https://streak-stats.demolab.com?user=adrianomiguell&theme=tokyonight-duo&hide_border=true&border_radius=4.1&date_format=j%20M%5B%20Y%5D&mode=weekly)](https://git.io/streak-stats)

  [![Ashutosh's github activity graph](https://github-readme-activity-graph.vercel.app/graph?username=adrianomiguell&bg_color=1a1b27&color=bf91f3&line=bf91f3&point=200528&area=true&hide_border=true)](https://github.com/ashutosh00710/github-readme-activity-graph)

  
</div>

## Used Languages


<div style="display: inline_block" align="center">
  <img align="center" alt="Adriano-CShap" height="50" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg" />
  <img align="center" alt="Adriano-php" height="50" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg" />
  <img align="center" alt="Adriano-html5" height="50" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" />
  <img align="center" alt="Adriano-css3" height="50" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" />
  <img align="center" alt="Adriano-js" height="50" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" />
  <img  align="center" alt="Adriano-react" height="50" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original-wordmark.svg" />
  <img align="center" alt="Adriano-bootstrap" height="50" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original.svg" />    
  <img align="center" alt="Adriano-laravel" height="50" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/laravel/laravel-plain-wordmark.svg" />
  <img align="center" alt="Adriano-dotnet" height="50" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/dot-net/dot-net-original.svg" />           
</div>

<div align="center">
  <a href="https://github.com/AdrianoMiguell">
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=AdrianoMiguell&layout=compact&langs_count=7&theme=tokyonight"/>  
</div>
