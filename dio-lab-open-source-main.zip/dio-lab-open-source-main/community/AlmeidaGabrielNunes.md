# Gabriel Almeida Nunes
## Contato-me
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/gabriel-anunes/)
## Git Status
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=almeidagabrielnunes&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
[![GitHub Streak](https://streak-stats.demolab.com/?user=almeidagabrielnunes&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)