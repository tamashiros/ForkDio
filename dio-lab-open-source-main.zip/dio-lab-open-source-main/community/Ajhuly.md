### 👋 _Olá!_
### _Me chamo Juliana_ :nerd_face: :brain:
### _Sou entusiasta em TI e venho me aprofundando cada vez mais em Git e GitHub dentre outras da área da tecnologia._ :computer:

<!--
**Ajhuly/Ajhuly** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->

----

<div>

<img height="150em" src="https://github-readme-stats.vercel.app/api?username=ajhuly&show_icons=true&theme=tokyonight"/>

</div>

----

### Contato

<div>

<a href="www.linkedin.com/in/juliana-r-silvestre-esposti">

<img src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/linkedin/linkedin-original.svg" align="center" heigth="50" width="60">

</a>

</div>

----

### Linguagens

<div>


<img src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/linux/linux-original.svg" align="center" heigth="50" width="60">
          

<img src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/bash/bash-original.svg" align="center" heigth="50" width="60">


<img src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/docker/docker-plain.svg" align="center" heigth="50" width="60">

<img src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/python/python-original.svg" align="center" heigth="50" width="60">
          

<img src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/django/django-plain.svg" align="center" heigth="50" width="60">


</div>

----
