# Matheus Legnani Wilken

- ## About Me

    My name is Matheus Legnani Wilken, I am actually a enviromental and sanitary engineer student, but since my first semester in college, I've been interested in programming because of the classes that I had.<br>
    My interest just increased when I had a Cientific Iniciation involving analytical geometry and **programming**. Since then, I had to search for myself a language that could work well with maths and project the graphics and the mathematical situation of the problems that me and my professor wanted to solve. Python was my first choice and my first language, I absolutely loved it and so, I started to dig depper and depper into this world and I gotta say, I have no regrets whatsoever<br>
    My next step: Learn Javascript.

- ## Soft Skills 

    - Communication
    - Teamwork
    - Spirit of leadership
    - Organization
    - Coordination
    - Proactivity
    - Dedication and commitment
    - Problem Solving
    - Desire to learn

- ## Hard Skills

    - English (Advanced)
    - German (Basics)
    - Python (Advanced)
    - Excel (Basics)
    - Canva
    - HTML (Basics)
    - CSS (Basics)
    - QGIS (Intermediate)
    - Git
    - GitHub

<br>
<div align="center">

  [![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:matheuslegw@gmail.com)

</div>
    