
#  AnaGabK 

- Ana Gabrielle Kataoka
- 21 anos
- Ciência da Computação

## 🌸 Redes 

[![Gmail](https://img.shields.io/badge/Gmail-f06292?style=for-the-badge&logo=gmail&logoColor=white)](mailto:ana.kataoka606@gmail.com) 
[![GitHub](https://img.shields.io/badge/GitHub-f06292?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AnaGabK)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-f06292?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/ana-kataoka-9370601a4)

## 🌸 Tecnologias

### ☆ Linguagens de Marcação ☆

![CSS3](https://img.shields.io/badge/CSS3-f06292?style=for-the-badge&logo=css3&logoColor=white)
![HTML5](https://img.shields.io/badge/HTML5-f06292?style=for-the-badge&logo=html5&logoColor=white)

### ☆ Linguagens de Programação ☆

![PHP](https://img.shields.io/badge/PHP-f06292?style=for-the-badge&logo=php&logoColor=white)
![Java](https://img.shields.io/badge/java-f06292?style=for-the-badge&logo=openjdk&logoColor=white)
![Python](https://img.shields.io/badge/python-f06292?style=for-the-badge&logo=python&logoColor=white)

### ☆ Bibliotecas e Frameworks ☆

![Tailwind](https://img.shields.io/badge/tailwindcss-f06292?style=for-the-badge&logo=tailwind-css&logoColor=white)
![Laravel](https://img.shields.io/badge/laravel-f06292?style=for-the-badge&logo=laravel&logoColor=white)
![Spring](https://img.shields.io/badge/spring-f06292?style=for-the-badge&logo=spring&logoColor=white)

### ☆ Banco de Dados ☆

![PostgreSQL](https://img.shields.io/badge/PostgreSQL-f06292?style=for-the-badge&logoColor=white&logo=postgresql)
![MySQL](https://img.shields.io/badge/MySQL-f06292?style=for-the-badge&logo=mysql&logoColor=white)