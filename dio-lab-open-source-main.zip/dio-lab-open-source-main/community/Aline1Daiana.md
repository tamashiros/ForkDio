Olá, meu nome é Aline

Assistente de recursos humanos e estudante de programação.


- 📖 Formada em Gestão de Recursos humanos
- 🔤 Inglês Intermediário
- 🚀 Realizando meu primeiro Bootcamp

<p align="center"><img width="50" height="50" src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/dotnetcore/dotnetcore-original.svg" /> </p>

<p align="center"> <b>Aprendendo a programar em .NET</b> </p>