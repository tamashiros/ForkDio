# AmandaStefaniz

## Conecte-se comigo 
[![LinkedIn](https://img.shields.io/badge/LinkedIn-b608ff?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/amanda-stefan%C3%AD-493a86234/)

[![GitHub](https://img.shields.io/badge/GitHub-b608ff?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AmandaStefaniz)



## Habilidades
[![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)](https://developer.mozilla.org/pt-BR/docs/Web/JavaScript/)

 [![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)](https://docs.python.org/3/)

[![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)](https://git-scm.com/doc)

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AmandaStefaniz)

[![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)](https://code.visualstudio.com/docs)





## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AmandaStefaniz&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=b608ff&title_color=b608ff&text_color=b608ff)

## Minhas Contribuições 
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AmandaStefaniz&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=b608ff&title_color=b608ff&text_color=FFF)](https://github.com/AmandaStefaniz/dio-lab-open-source)