# Sobre Mim

## Git Profile

- **Nome**: [Amauri Damasceno]
- **Usuário GitHub**: [Amauri-Dam]
## Formação
  **Agronomia no Instituto Federal do Pará - Campus Castanhal** 

## Objetivos: 
  **Desenvolver habilidades em na área tech, principalmente em programação**



Conecte-se Comigo:
[GitHub](https://github.com/Amauri-Dam)
