![header](https://capsule-render.vercel.app/api?type=waving&color=#6A5ACDheight=300&section=header&text=capsule%20render&fontSize=90)

<div align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&weight=600&size=32&duration=4977&pause=1000&color=6A5ACD&background=FFFFFF00&width=300&lines=Hello+world!" alt="Typing SVG" /></a>
</div>

<h2>My Github Stats </h1>

<div align="center">
  <a href="https://github.com/manuletsgo">
  <img height="180em" src="https://github-readme-stats-sigma-five.vercel.app/api?username=Alessandraxz&show_icons=true&count_private=true&line_height=30&theme=dark"/>
  <img height="180em" src="https://github-readme-stats-sigma-five.vercel.app/api/top-langs/?username=Alessandraxz&layout=compact&theme=dark"/>
</div>
 <br>

![HTML](https://img.shields.io/badge/HTML-E34F26?style=for-the-badge&logo=html5&logoColor=white)
[![CSS](https://img.shields.io/badge/CSS-1572B6?style=for-the-badge&logo=css3&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/CSS)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![Spring](https://img.shields.io/badge/Spring-6DB33F?style=for-the-badge&logo=spring&logoColor=white)&nbsp;
![Angular](https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white)&nbsp;
![Ionic](https://img.shields.io/badge/Ionic-3880FF?style=for-the-badge&logo=ionic&logoColor=white)&nbsp;



<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=&height=120&section=footer"/>