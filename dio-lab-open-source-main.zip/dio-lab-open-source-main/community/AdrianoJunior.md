[![Adriano Junior](https://github.com/AdrianoJunior/AdrianoJunior/blob/main/CodeCraftsman.png)](https://codecraftsman.tech)

<div align="center">
   
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=30&pause=1000&color=70A5FD&center=true&width=600&height=100&lines=Hey+There!;My+name+is+Adriano+Coutinho;I+like+mobile+development;+exploring+new+techs;+and+solving+problems)](https://git.io/typing-svg)

</div>


## Stars and contributions


[![GitHub Streak](https://streak-stats.demolab.com?user=AdrianoJunior&theme=gruvbox&locale=pt_BR)](https://git.io/streak-stats)



  [![Ashutosh's github activity graph](https://github-readme-activity-graph.vercel.app/graph?username=AdrianoJunior&theme=react-dark)](https://github.com/ashutosh00710/github-readme-activity-graph)

  
</div>

## Used Tools


<div style="display: inline_block" align="center">
<img align="center" alt="Adriano-dart" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/dart/dart-original-wordmark.svg"/>
  <img align="center" alt="Adriano-dart" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/flutter/flutter-original.svg"/>
  <img align="center" alt="Adriano-java" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/java/java-original-wordmark.svg" />
  <img  align="center" alt="Adriano-spring" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/spring/spring-original-wordmark.svg" />
  <img align="center" alt="Adriano-android" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/android/android-original-wordmark.svg" />    
  <img align="center" alt="Adriano-android-studio" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/androidstudio/androidstudio-original-wordmark.svg" />
  <img align="center" alt="Adriano-apple" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/apple/apple-original.svg" />    
  <img align="center" alt="Adriano-chrome" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/chrome/chrome-original-wordmark.svg" /> 
  <img align="center" alt="Adriano-firebase" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/firebase/firebase-plain-wordmark.svg" /> 
  <img align="center" alt="Adriano-git" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/git/git-original-wordmark.svg" /> 
  <img align="center" alt="Adriano-github" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/github/github-original-wordmark.svg" /> 
  <img align="center" alt="Adriano-jetbrains" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/jetbrains/jetbrains-original.svg" />

  <img align="center" alt="Adriano-material" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/materialui/materialui-original.svg" />

  <img align="center" alt="Adriano-sqlite" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/sqlite/sqlite-original-wordmark.svg" />

  <img align="center" alt="Adriano-vscode" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/vscode/vscode-original-wordmark.svg" />

<img align="center" alt="Adriano-xcode" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/xcode/xcode-original.svg" />      

  <img align="center" alt="Adriano-xd" height="50" width="40" src="https://github.com/devicons/devicon/blob/v2.15.1/icons/xd/xd-line.svg" />        
</div>

<div align="center">
  <a href="https://github.com/AdrianoJunior">
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=AdrianoJunior&layout=compact&langs_count=7&theme=react-dark"/>  
</div>
