<picture>
 <source media="(prefers-color-scheme: dark)" srcset="YOUR-DARKMODE-IMAGE">
 <source media="(prefers-color-scheme: light)" srcset="YOUR-LIGHTMODE-IMAGE">
 <img alt="YOUR-ALT-TEXT" src="YOUR-DEFAULT-IMAGE">
</picture>

# Alana 
Olá meu nome é Alana, tenho 24 anos e sou formada em Análise e deselvimento de sistemas, ainda em busca de uma area dentro da minha profissão, espero um dia poder ouvir menos a minha auto-sabotagem e acreditar no meu potencial, prazer em conhecê-los.

# Habilidades 
Desenvolvendo e aperfeiçoando.