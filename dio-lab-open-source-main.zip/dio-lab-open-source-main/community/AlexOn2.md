# Renato
Opa! Me chamo Renato Junior e sou estudante de Ciência da Computação
## Conecte-se comigo
[![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/renatin09/)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlexOn2&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
