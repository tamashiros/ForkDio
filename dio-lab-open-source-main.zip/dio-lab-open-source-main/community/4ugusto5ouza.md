# Olá, sou Samuel Souza! 👋

## Sobre mim

- 📚 Estudante do 6º período do curso de Engenharia de Software na UniFil.
- 👨‍💻 Desenvolvedor Full Stack com mais de três anos de experiência em .NET e React.js.

## Experiência

- 💼 Trabalho atualmente como Desenvolvedor Full Stack.
- 🔧 Minhas habilidades incluem desenvolvimento web, design de banco de dados, arquitetura de software e muito mais.
- 🌐 Já contribuí para diversos projetos de código aberto e participei de projetos pessoais.

## Tecnologias

- 💻 Linguagens de programação: C#, JavaScript.
- 🌐 Front-end: React.js, HTML, CSS.
- 🖥️ Back-end: .NET, ASP.NET, Entity Framework.
- 🗃️ Banco de dados: SQL Server, MySQL.
- 🧰 Ferramentas de Desenvolvimento: Visual Studio, Visual Studio Code, Git.
- 🌍 Outras: Docker, RESTful APIs.
