
<div>
    <h1>oi, meu nome é breno tudo bem?  👋 </h1>
    <h2>Bem vindo ao meu Perfil.</h2>
    <p> 
Minhas historia com a programação se inicia em um cenario um pouco improvavel. Sou um jovem filho de agricultor, de familia toda da fazenda, simples, que nem conhecia pra que serve um PC.
Porém, sempre um destaque nos estudos, principalmente em exatas, era incentivado a sempre se aprimorar, aos 15 anos, comecei com um simples curso de informatica basica, evoluindo para area administrativa, manunteção de Hardware, edições graficas, ate conhecer a senhora Log. de Programação, dando trabalho para os professores, usando a complexidade, como uma combustivel para avançar. E assim começava a nova jornada...
Ja trabalhava com a informatica e administração em uma renomada loja de veiculos como aprendiz. Pouco tempo depois, aos 18 anos, me tornei o professor ao qual me socorria na senhora Logica de programação, na mesma escola. Aqui, o sabio mestre yoda ja diria "ser programador, vc deve". Comecei no ano seguinte Tec. em Analise e desenvolvimento de sistemas, me apaixonei ainda mais, e com dedicação, em 2022, me formei, com a premiação de maior nota da turma, progredindo nessa vida tec.
Hoje, tenho 21 anos, sou um programador web, com maior conhecimento na area back-end,  mais habituado com a tecnologia Java, mas buscando conhecimento para torna-me fullstack.Apaixonado em novas tecs, tendencias do mercado e inovações. Um gosto um pouco estranho, é o fato de gostar de resolver problemas. Graças a todas as oportunidades, sou um hoje, um analista de suporte, dedicado, em uma otima empresa de prestação de serviço publico, aprimorando ainda mais para trabalhar em uma empresa como dev, mas muito grato, por toda essa historia me agregar habilidades de comunicação, liderança e principalmente, em resolver os problemas.
    </p>
    <p>Seguimos firmes, e mais para frente, eu volto pra contar um pouco da experiencia que o conhecimento vem me agregando... 
    </p>
</div>
<div>
    <h2>Conecte-se comigo</h2>
   <a href="https://www.linkedin.com/in/breno-miranda-de-oliveira-desenvolvedor/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
    <a href = "mailto:1Brenomiranda@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
</div>
<br>
<div align="center">
  <a href="https://github.com/83Rafa">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=83Rafa&show_icons=true&theme=tokyonight&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=83Rafa&layout=compact&langs_count=7&theme=tokyonight"/>
</div>
<div style="display: inline_block"><br>
    <h2>Tecnologias</h2>
  <img align="center" alt="Rafa-MySQL" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original-wordmark.svg">
  <img align="center" alt="Rafa-MongoDB" height="30" width="40" src="https://www.pngall.com/wp-content/uploads/13/Mongodb-PNG-Image-HD.png">
  <img align="center" alt="Rafa-AWS" height="30" width="30" src="https://static-00.iconduck.com/assets.00/aws-icon-2048x2048-274bm1xi.png">
  <img align="center" alt="Rafa-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Rafa-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
</div>
<br>
<br>

