# **Aline Danyelle de Alencar Britto**

## *Sobre mim*

Tenho 33 anos, sou formada em Processos Químicos pela FATEC-PG e estou em transição de carreira para a área de tecnologia, cursando Análise e Desenvolvimento de Sistemas. 

Ainda iniciante mas sempre aprendendo.

## *Conecte-se comigo*

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/aline-danyelle-de-alencar-britto-453774140/)

[![GitHub](https://img.shields.io/badge/github-000?style=for-the-badge&logo=github&logoColor=0E76A8)](https://github.com/ADABritto)

[![DIO](https://img.shields.io/badge/dio-000?style=for-the-badge&logo=github&logoColor=0E76A8)](https://www.dio.me/users/alinedanyellea)



## *Habilidades*

| Tecnologia  | Nível   |
| -------     | -------- |
| ![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)     | Básico    |
| ![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)      | Básico   |
