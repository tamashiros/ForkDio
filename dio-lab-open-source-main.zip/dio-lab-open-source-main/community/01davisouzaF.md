<h1 align="left">Hello There!! 🙂</h1>

###

<div align="left">
  <img src="https://img.shields.io/static/v1?message=LinkedIn&logo=linkedin&label=&color=0077B5&logoColor=white&labelColor=&style=for-the-badge" height="22" alt="linkedin logo"  />
  <a href="https://twitter.com/deiv_sf" target="_blank">
    <img src="https://img.shields.io/static/v1?message=Twitter&logo=twitter&label=&color=1DA1F2&logoColor=white&labelColor=&style=for-the-badge" height="22" alt="twitter logo"  />
  </a>
</div>

###

<h3 align="left">My name is Davi</h3>

###

<h5 align="left">My Skills:</h5>

###

<div align="left">
  <img src="https://skillicons.dev/icons?i=java" height="30" alt="java logo"  />
  <img width="12" />
  <img src="https://skillicons.dev/icons?i=spring" height="30" alt="spring logo"  />
  <img width="12" />
  <img src="https://skillicons.dev/icons?i=js" height="30" alt="javascript logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-original.svg" height="30" alt="postgresql logo"  />
  <img width="12" />
  <img src="https://skillicons.dev/icons?i=html" height="30" alt="html5 logo"  />
  <img width="12" />
  <img src="https://skillicons.dev/icons?i=css" height="30" alt="css3 logo"  />
  <img width="12" />
  <img src="https://skillicons.dev/icons?i=figma" height="30" alt="figma logo"  />
  <img width="12" />
  <img src="https://cdn.simpleicons.org/canva/00C4CC" height="30" alt="canva logo"  />
</div>

###

<p align="left">• 🎓 Analysis and Systems Development Student<br>• 🧑🏽‍💻 Passionate about learning new things</p>

###

<div align="left">
  <img src="https://github-readme-stats.vercel.app/api/top-langs?username=01davisouzaF&locale=en&hide_title=false&layout=compact&card_width=320&langs_count=5&theme=dark&hide_border=true&order=2" height="150" alt="languages graph"  />
</div>

###
