# Hi, I'm Alan Joabio! 👋

<h4 align="center">

[![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AlanJoabio)
[![Instagram](https://img.shields.io/badge/Instagram-%23E4405F.svg?style=for-the-badge&logo=Instagram&logoColor=white)](https://www.instagram.com/alanjoabio/)
[![LinkedIn](https://img.shields.io/badge/linkedin-%230077B5.svg?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/mwlite/in/alan-joabio-souza-04452a134/)
[![Discord](https://img.shields.io/badge/Discord-%235865F2.svg?style=for-the-badge&logo=discord&logoColor=white)](https://discord.com/app)
[![Portifolio Badge](https://img.shields.io/badge/-Portfolio-green?style=flat-square&logo=Portfolio&logoColor=white&link=https://alanjoabio.github.io/O-Portfolio/)](https://alanjoabio.github.io/O-Portfolio/)
![LICENSE MIT BADGE](https://img.shields.io/github/license/AlanJoabio/AlanJoabio)

</h4>



### About me/Sobre em mim!

In addition to discovering this great transmission and interest in the area of technology, this area permeates several sciences and has been presenting itself as a promising career in current times in the face of constant technological advancement, and also with excellent opportunities in the job market now and in the future.

I'm passionate about technology! So I chose this career, because I want to acquire a new professional training in the area of technology, which I've been researching and identifying with more and more.

[Tradução](#sobre-mim-em-portuquês)


🌱 I’m currently learning :
<p>
HTML, CSS, JavaScript, JAVA, Python, Bootstrap, Git, Linux, Windows, Figma, Canvas, Network security.
</p>

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AlanJoabio&repo=dio-lab-open-source&bg_color=0000&border_color=6bbbca&show_icons=true&icon_color=6bbbca&title_color=6bbbca&text_color=fff)](https://github.com/AlanJoabio/dio-lab-open-source) 

| ![](http://github-profile-summary-cards.vercel.app/api/cards/stats?username=AlanJoabio&theme=nord_dark) | ![](http://github-profile-summary-cards.vercel.app/api/cards/repos-per-language?username=AlanJoabio&hide=Html&theme=nord_dark) | ![](http://github-profile-summary-cards.vercel.app/api/cards/most-commit-language?username=AlanJoabio&theme=nord_dark) |
| :-: | :-: | :-: |

| ![](http://github-profile-summary-cards.vercel.app/api/cards/profile-details?username=AlanJoabio&theme=nord_dark) | ![](https://github-readme-streak-stats.herokuapp.com/?user=AlanJoabio&hide_border=true&date_format=M%20j%5B%2C%20Y%5D&background=2D3742&stroke=2D3742&ring=6bbbca&fire=6bbbca&currStreakNum=fff&sideNums=6bbbca&currStreakLabel=6bbbca&sideLabels=fff&dates=fff) |
| :-: | :-: |

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlanJoabio&theme=nord_dark&bg_color=2D3742&border_color=6bbbca&show_icons=true&icon_color=6bbbca&title_color=6bbbca&text_color=6bbbca)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AlanJoabio&bg_color=2D3742&border_color=6bbbca&title_color=6bbbca&text_color=6bbbca)


Sobre mim em Portuquês
======================

Sobre mim...

Além de descobrir essa grande transmissão e interesse pela área de tecnologia, essa área permeia diversas ciências e vem se apresentando como uma carreira promissora nos tempos atuais diante do constante avanço tecnológico, e também com excelentes oportunidades no mercado de trabalho atualmente. e no futuro.

Sou apaixonado por tecnologia! Então escolhi essa carreira, porque quero adquirir uma nova formação profissional na área de tecnologia, a qual venho pesquisando e me identificando cada vez mais.

-----------------------------
