### Alfredo Lucas
- 📜 Sistemas de Informação - UFJF
- 🌱 Estudando Data Science / Machine Learning
- 20 anos


<div>
    <a href="https://github.com/AlfredoLSN"></a>
    <img height="180em" src="https://github-readme-stats.vercel.app/api?username=AlfredoLSN&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF" >
    <img height="180em" src="https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AlfredoLSN&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF">
    
</div>
<div style="display: inline_block"><br>
  <img align="center" alt="Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Node"  height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg" /> 
</div>
</div>
  
  ##
 
<div> 
  <a href = "mailto:alfredolsn@hotmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/alfredo-lucas-da-silva-neto-254a58271?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3BKigh%2BddGTPm8Z%2FV3tCSp7w%3D%3D" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
  
</div>