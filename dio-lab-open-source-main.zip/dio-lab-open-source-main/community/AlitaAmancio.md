
# Hello there! :star2:

I'm Alita and I'm glad to see you here! I invite you to take a look at my profile and contact me via my email or LinkedIn. In this journey to becoming an experienced programmer I'm open to any form of advice, tips and knowledge exchange, but at the end of the day we all know that the real treasure is the friends we make along the way, so just go ahead and contact me anyway! 

## Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlitaAmancio&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AlitaAmancio&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)


## Links
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alitaamancio/)


