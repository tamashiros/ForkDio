# Alberto Gonçalves - @AlbertoGoncalves


- 🔭 I’m currently working on Manager in Information Technology, Development in ADVPL, LGPD 
- 🔭 Atualmente estou trabalhando como Gerente em Tecnologia da Informação, Desenvolvimento em ADVPL, FLUTTER e PYTHON  

### 📫 Contatos:
<div>
<a href = "mailto:jjunior666@gmail.com"><img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
<a href="https://www.linkedin.com/in/alberto-gon%C3%A7alves-20a0176b" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>   
<a href="https://instagram.com/albertojunior00" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
</div>


### Ferramentas e Tecnologias

<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/arduino/arduino-original-wordmark.svg" width="40" height="40"/> <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original-wordmark.svg" width="40" height="40"/> <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/microsoftsqlserver/microsoftsqlserver-plain-wordmark.svg" width="40" height="40"/> <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/trello/trello-plain-wordmark.svg" width="40" height="40"/> <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg" width="40" height="40"/> <img src=https://user-images.githubusercontent.com/91420997/171313375-1bbbf97c-757c-497e-95c8-06ffe2714a4d.gif width="100" height="40" />



### 🎓 I’m currently learning | Estou aprendendo
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" width="40" height="40"/> <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-original.svg" width="40" height="40"/> <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/flutter/flutter-original.svg" width="40" height="40"/>


          


[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=AlbertoGoncalves&layout=compact&theme=dark)](https://github.com/USERNAME/github-readme-stats)

<!-- ![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=AlbertoGoncalves&show_icons=true&theme=radical) -->




 

