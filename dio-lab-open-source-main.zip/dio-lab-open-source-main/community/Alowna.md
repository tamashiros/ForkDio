# Alona Nicolau

## Bem vindo(a) ao meu perfil

Olá, meu nome é Alona Nicolau e estudo Tecnologia em Análise e Desenvolvimento de Sistemas. 
<br><br>Meu foco em 2023/2024 é entender principalmente os temas de Desenvolvimento Web e Banco de Dados.


## Principais Redes Sociais


[![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com/Alonuum/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/aloonas2/)

## Meus hobbies

- Escrever/Ler Poesia
- Assistir filmes/séries
- Jogar jogos competitivos
- Ler
- Programar

## Focos de Estudo

- [![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)
- [![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)
- ![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
- ![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)
- ![C](https://img.shields.io/badge/C-00599C?style=for-the-badge&logo=c&logoColor=white)

## GitHub Status

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alowna&theme=transparent&bg_color=0f211c&border_color=123027&show_icons=true&icon_color=30A3DC&title_color=3cf0be&text_color=FFF)
