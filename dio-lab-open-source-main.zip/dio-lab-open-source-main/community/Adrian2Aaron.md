[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&size=25&pause=1000&color=5102F7&center=true&random=false&width=435&lines=Ol%C3%A1!+Eu+sou+o+Adriano+Robson.;Seja+bem+vindo!)](https://git.io/typing-svg)

Eu sou um graduando em *Sistemas de infomormação* na Universidade Federal de Uberlandia ***(UFU)*** que sempre foi amante de computação e robótica.
E atualmente eu atuo como um membro efetivo de programação da equipe de robotica *[ROBOFORGE](https://linktr.ee/ufu.roboforge])*  

## Conecte-se comigo 

[![Discord](https://img.shields.io/badge/Discord-5102F7?style=for-the-badge&logo=discord&logoColor=white)](https://discord.com/channels/@adrianorobson/) | [![GitHub](https://img.shields.io/badge/GitHub-5102F7?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Adrian2Aaron) | [![Gmail](https://img.shields.io/badge/Gmail-5102F7?style=for-the-badge&logo=gmail&logoColor=white)](mailto:adriano.robson16@gmail.com) | [![Instagram](https://img.shields.io/badge/-Instagram-5102F7?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/adrian2aaron/) | [![LinkedIn](https://img.shields.io/badge/LinkedIn-5102F7?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/Adriano-Robson-45497a1a2/)
:--------: | :------: | :-------: | :------: | :-------:  

## Conheço as linguagens  
![C](https://img.shields.io/badge/C-5102F7?style=for-the-badge&logo=c&logoColor=white) | ![C++](https://img.shields.io/badge/C%2B%2B-5102F7?style=for-the-badge&logo=c%2B%2B&logoColor=white) | ![Haskell](https://img.shields.io/badge/Haskell-5102F7?style=for-the-badge&logo=haskell&logoColor=white) | ![Python](https://img.shields.io/badge/python-5102F7?style=for-the-badge&logo=python&logoColor=ffdd54) | ![R](https://img.shields.io/badge/R-5102F7?style=for-the-badge&logo=r&logoColor=white)
:--------: | :------: | :-------: | :------: | :-------:  

## Interesses e Aspirações 
Me interesso muito por Machine Learning, Inteligencia Artificial, e por Computação em Nuvem. Gostaria muito de me especializar em uma dessas areas