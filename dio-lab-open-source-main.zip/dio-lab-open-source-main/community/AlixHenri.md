<!--Github Stats Panel-->
<div align="center">
  <a href="https://github.com/alixhenri">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=alixhenri&show_icons=true&theme=dracula&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=alixhenri&layout=compact&langs_count=7&theme=dracula"/>
</div>
  
<h3>The Distro I use / A Distro que uso:</h3>
  <img src = "https://img.shields.io/badge/Manjaro-35BF5C?style=for-the-badge&logo=Manjaro&logoColor=white">

<!--Social Badges-->
<div id="Socials">
  <h3>My Socials / Minhas Redes Socials</h3>
  <a href="https://open.spotify.com/user/222o4dlvyefwxhylqdfayysoa" target="_blank"><img src="https://img.shields.io/badge/Spotify-1ED760?&style=for-the-badge&logo=spotify&logoColor=white" target="_blank"></a>
  <a href="https://twitter.com/HenriKobain" target="_blank"><img src="https://img.shields.io/badge/Twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white" target="_blank"></a>
  <a href="https://www.instagram.com/mozart_henri/" target="_blank"><img src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/matheus-henri-fran%C3%A7a-aa83061b9/" target="_blank"><img src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white"></a>
</div>  

