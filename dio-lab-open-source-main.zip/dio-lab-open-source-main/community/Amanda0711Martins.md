# Amanda Nelva Almeida Martins - @amandanelva

##### Olá, me chamo Amanda e atualmente estou cursando o 3º semestre da Graduação em Sistemas de Informação
##### Estudo no IFMG em Ouro Branco e sou apaixonada por qualquer assunto relacionado à tecnologia.
#####    No momento estou fazendo o Bootcamp 2024 do Santander Backend com Java, aqui na [DIO] {https://www.dio.me/}

Acredito que esse Bootcamp será minha chance de mudar de carreira, se você gostou desta contribuição me ajude a conseguir minha tão sonhada vaga! 👩‍💻



### 📒 Contatos:

E-mail: amandanelvaalmeida@gmail.com
Linkedin: {https://www.linkedin.com/in/amanda-martins-89944a304/}

### Ferramentas e Tecnologias

No momento não me considero proficiente em nenhuma linguagem, porém tenho conhecimentos básicos em:
Java
VSCode

Obrigada por ler até aqui, até a próxima ✌️
