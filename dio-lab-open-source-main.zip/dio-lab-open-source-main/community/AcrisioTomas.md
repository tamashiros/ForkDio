
### Seja bem vindo!

# Meu nome é Acrísio Tomas
Sou profissional de marketing eu ajudo empresas e líderes empresariais a atingir objetivos e metas em seus negócios através de metodologias, processos e tecnologia.

Convido a todos para ler meu perfil e conhecer mais sobre minhas
realizações profissionais.

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/SEUUSERNAME/)

## Soft Skills

- Curiosidade
- Perfil Análitico
- Ivestigativo
- Fácil Adaptabilidade
- Confiabilidade
- Aprendizado Contínuo
- Trabalho em equipe

## Hard Skills

- Graduação em Marketing 
- Mestrados em Gestão Estratégica

## Habilidades

![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=30A3DC)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=E94D5F)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

## Projetos DIO

### Manipulação de dados com Python e Pandas ​:panda_face:​

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AcrisioTomas&repo=analise_dados&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/SEUUSERNAME/SEUREPOSITORIO)

A análise de dados com Phyton, pode transformar grandes conjuntos de dados, estruturados ou não estruturados, em informações claras para a tomada de decisão. Essa análise envolve reduzir os custos, melhorar a qualidade do serviço ou produto, inovar e otimizar o desempenho das vendas.


