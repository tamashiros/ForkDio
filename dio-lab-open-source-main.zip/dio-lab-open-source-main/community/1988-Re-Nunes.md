
# **Olá, meu nome é Renata** 

Sou estudante de Ciências de Dados pela UNIVESP - Universidade Estadual Do Estado De São Paulo e ingressei em 2023.\
Atualmente trabalho na área da saúde, sou Biomédica e meu intuito é migrar para área de Tecnologia. Em busca de oportunidades melhores e de crescimento profissional.  
</br>
</br>

##  **Conecte-se comigo**
[![portfolio](https://img.shields.io/badge/my_portfolio-000?style=for-the-badge&logo=github&logo=ko-fi&logoColor=white)](https://github.com/1988-Re-Nunes)
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=github&&logo=linkedin&logoColor=white_button&width1000px&height=100px)](https://www.linkedin.com/in/renata-nunes-322248aa?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3BR3oqPbHJTcu1MwHy79CqJA%3D%3D)
[![instagram](https://img.shields.io/badge/instagram-1DA1F2?style=for-the-badge&logo=github&logo=instagram&logoColor=white)](https://www.instagram.com/rncnunees?igsh=MTRiZGtpZTFjZm9j)
</br>
</br>
</br>

## **Status do Github** 
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=1988-Re-Nunes&theme=transparent&bg_color=122&border_color=40A5DC&show_icons=true&icon_color=50A5DC&title_color=E94D5F&text_color=EEB)
![Linguagens mais usadas](https://github-readme-stats.vercel.app/api/top-langs/?username=1988-Re-Nunes&theme=transparent&bg_color=122&border_color=40A5DC&show_icons=true&icon_color=50A5DC&title_color=E94D5F&text_color=EEB&layout=compact)
</br>
</br>
</br>

## **Minhas  Contribuições**
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=1988-Re-Nunes&repo=dio-lab-open-source&bg_color=122&border_color=30A3DC&show_icons=true&icon_color=50A5DC&title_color=E94D5F&text_color=EEB)](https://github.com/1988-Re-Nunes/dio-lab-open-source)
</br>
</br>
</br>

## **Estou Aprendendo**
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![github](https://img.shields.io/badge/GitHub-000000?style=for-the-badge&logo=GitHub&logoColor=white)
![java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)
![python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
</br>
</br>
</br>
## **Objetivo Desta atividade**
Aprender a como colaborar com projetos open source utilizando o GitHub.