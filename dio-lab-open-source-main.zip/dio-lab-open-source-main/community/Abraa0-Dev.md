### Olá! eu me chamo Abraão. 👋🏽🧑🏽‍💻<Br>

<hr/>

### Estudante de Desenvolvimento Web
#### Ensino Técnico Integrado ao Ensino médio em Desenvolvimento de Sistemas pela Escola Técnica Estadual Luiz Alvez Lacerda 

<hr>

#### Estudando desenvolvimento web através da plataforma Udemy
#### Dedicando-me a aprimorar meus conhecimentos no segmento Front-End do desenvolvimento Web, bem como bancos de dados com PHP e linguagem de programação JavaScript.
<hr>

![Abraão's GitHub stats](https://github-readme-stats.vercel.app/api?username=Abraa0-Dev&show_icons=true&theme=react)

<hr>

## Tecnologias nas quais busco me aprimorar:

![Skills](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)![Skills](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)![Skills](https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E)![Skills](https://img.shields.io/badge/Sass-CC6699?style=for-the-badge&logo=sass&logoColor=white)![Skills](https://img.shields.io/badge/Bootstrap-563D7C?style=for-the-badge&logo=bootstrap&logoColor=white)![Skills](https://img.shields.io/badge/PHP-777BB4?style=for-the-badge&logo=php&logoColor=white)![Skills](https://img.shields.io/badge/MySQL-005C84?style=for-the-badge&logo=mysql&logoColor=white)![Skills](https://img.shields.io/badge/Ionic-3880FF?style=for-the-badge&logo=ionic&logoColor=white)



<hr>

## Redes Sociais
#### Você pode me encontrar nas seguintes redes sociais:

[![Blog](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/abraao_fsantos/)[![Blog](https://img.shields.io/badge/Facebook-1877F2?style=for-the-badge&logo=facebook&logoColor=white)](https://www.facebook.com/profile.php?id=61554218602385)[![Blog](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/abra%C3%A3o-santos-aaa915273/)
<hr>

