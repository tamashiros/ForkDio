
# Alice Gabrieli S. Pereira

## 👩 Futilidades sobre mim
- Comecei minha jornada em tecnologia há pouco tempo👩‍💻
- Sou estudante de jornalismo 📰🤓
- Sou fangirl de cantores pop (ou que já foram pop)🎤
- Sou do signo de câncer ♋🦀
- Sou viciada em True Crime 🔪
- Sou uma amante de livros 📚
- Amo futebol (SPFC) ⚪🔴⚫⚽

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlynhaBe&theme=transparent&bg_color=FFC0CB&border_color=FF69B4&show_icons=true&icon_color=FF69B4&title_color=FF1493&text_color=FF69B4)

[![GitHub Streak](https://streak-stats.demolab.com/?user=AlynhaBe&theme=bear&background=FFC0CB&border=FF69B4&dates=FF69B4)](https://git.io/streak-stats)

## 📩 Comunication
- Você pode entrar em contato comigo por essas redes:

     _(Não sei porque iria querer, mas dá)_
[![GitHub](https://img.shields.io/badge/GitHub-FFC0CB?style=for-the-badge&logo=github&logoColor=FF69B4)](https://github.com/AlynhaBe) 
```
-> No GitHub entro mais por conta dos cursos, não tem muita coisa lá.
```

[![Instagram](https://img.shields.io/badge/-Instagram-FFC0CB?style=for-the-badge&logo=instagram&logoColor=FF69B4)](https://www.instagram.com/alice.gab.rieli/)
```
-> No Instagram tem eu sendo aesthetic, muitas fotos fazendo coisas divertidas (e fingindo que não passo a semana toda sem pisar o pé na rua por conta do trabalho e da faculdade)
```

[![X](https://img.shields.io/badge/X-FFC0CB?style=for-the-badge&logo=x)](https://www.x.com/AlynhaBe)
```
-> No Twitter é onde o bicho pega, tem xingamento e choro a vontade. Normalmente os dois envolvem futebol.
```


## 💻 Sistemas
![Windows](https://img.shields.io/badge/Windows-FFC0CB?style=for-the-badge&logo=windows&logoColor=FF69B4)
```
-> O windows 10 capenga do meu laptop da xuxa, pelo menos funciona.
```


![Android](https://img.shields.io/badge/Android-FFC0CB?style=for-the-badge&logo=android&logoColor=FF69B4)
```
-> Nem todo mundo consegue pagar um Iphone, tô ocupada gastando com shows, ok?
```


## 🛠 Ferramentas
![Git](https://img.shields.io/badge/GIT-FFC0CB?style=for-the-badge&logo=git&logoColor=FF69B4)
```
-> Comecei a usar agora no Bootcamp da DIO Santander.
```


![Vscode](https://img.shields.io/badge/Vscode-FFC0CB?style=for-the-badge&logo=visual-studio-code&logoColor=FF69B4)
```
-> Fiz um outro curso em que usei, mas olha, que dor de cabeça pra entender esse querido.
```


![NodeJS](https://img.shields.io/badge/node.js-FFC0CB?style=for-the-badge&logo=node.js&logoColor=FF69B4)
```
-> Mesma coisa que o Vscode, com a diferença que foi pior 🤡
```

### Repositório:
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AlynhaBe&repo=dio-lab-open-source&bg_color=FFC0CB&border_color=FF69B4&show_icons=true&icon_color=FF69B4&title_color=E94D5F&text_color=FF69B4)](https://github.com/AlynhaBe/dio-lab-open-source)