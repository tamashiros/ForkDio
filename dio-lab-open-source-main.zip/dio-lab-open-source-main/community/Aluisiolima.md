# Aluisio lima 

# Bem vindo(a) ao meu perfil

Oi eu sou o Aluisio, um estudante inicial nesse percurso da tecnologia, um amante  da internet e grande apreciador dos games.\
Quem saber futuramente um desenvolvedor... 

## conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/aluísio-lima-1311542ab/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/aluiz_nt/)

## Informções pessoas 
- tenho 17 anos 
- sou estudante do CETI acrisio veras 
- medalista em mençao honrosa na  OBMEP 
- integrante do curso de robotica 

## Meus hobbies

- Ler mangás 
- Assistir animes e Series


## Atualmente estudando

- Git e GitHub
- html
- Javascript
- css
- Angular

## GitHub Status

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Aluisiolima&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
