# Alcimar M. Trindade
Hi! My name is Alcimar, nice to meet you. This is my github and contacts info. If you find a black cat named Bob, please, don't call me. It isn't mine.

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/alcimartri1998?tab=skills/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:alcimartri1998@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/alcimar-m-trindade/)
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](discordapp.com/users/soloniudsdn#0/)

### Habilidades

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlcimarMT&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

