# Ana00Sara
Estudante de Análise e Desenvolvimento de Sistemas.


## Habilidades
![Static Badge](https://img.shields.io/badge/Python-lightblue?style=for-the-badge)

![Static Badge](https://img.shields.io/badge/JAVA-pink?style=for-the-badge)

## Áreas de Interesse

![Static Badge](https://img.shields.io/badge/Segurança_DA_INFORMAÇÃO-pink?style=for-the-badge)

![Static Badge](https://img.shields.io/badge/Desenvolvimento_de_jogos-lightblue?style=for-the-badge)

![Static Badge](https://img.shields.io/badge/machine_learning-pink?style=for-the-badge)

