# Prazer sou Bruno de Melo Allucci
Sou Analista de sistema, atualmente trabalho em um hospital no qual utilizo o sistema Tasy um ERP hospitalar, onde para acesso e pesquisa ao banco de dados utilizo MYSQL, atualemte estou espandindo meu conhecimento com a linguagem Python.
# Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/bruno-allucci-b79903197/)

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Allucc1)


# Habilidades
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)

![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)

![MySQL](https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white)

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Allucc1)

![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)

![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)
# GitHub Stats
