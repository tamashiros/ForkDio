 
 ## [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=18&pause=1000&color=ed1fa9&width=435&align=center&lines=Olá+DEVS!+Sejam+bem-vindos+ao+meu+perfil!+;Prazer%2C+meu+nome+%C3%A9+Ana+Kércia.)](https://git.io/typing-svg)
 
 # Quem sou eu?
    Oie, tudo bem? Eu sou a ANA KÉRCIA🤗
    
     Formada em Administração de empresas,
     Pós graduada em Gestão Àgil e Desenvolvimento de Software, e
     Estudante de Desenvolvimento Front End.
  
#### "A persistência é a chave para o sucesso na jornada do desenvolvedor de sistemas, onde cada linha de código é uma oportunidade de criar um mundo de possibilidades tecnológicas."😉️
### Conecte-se Comigo!

[![Perfil na DIO](https://img.shields.io/badge/perfil%20na%20dio-007ACC?style=for-the-badge&logo=DIO&logoColor=red)](https://www.dio.me/users/anakercia10)

[![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/anakercia.balbueno/)

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/anakerciagregorio/)

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Anakercia1)

[![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:anakercia1010@gmail.com)


### Habilidades em Desenvolvimento

![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)

![TypeScript](https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript&logoColor=white)

![Angular](https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white)

![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)

![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)


### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Anakercia1&count_private=true&include_all_commits=true&show_icons=true&theme=neon&hide_border=false&show_owner=true")
![GitHub Stats](https://github-readme-stats.vercel.app/api/top-langs/?username=Anakercia1&theme=neon&hide_border=false&&layout=compact)


### Principais Projetos na DIO
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&bg_color=000&theme=neon&hide_border=false&&layout=compact)](https://github.com/elidianaandrade/dio-lab-open-source)

### *Outros Projetos desenvolvidos ao longo dos estudos.

[![GitHub](https://github-readme-stats.vercel.app/api/pin/?username=AnaKercia1&repo=Buscante&bg_color=000&theme=neon&hide_border=false&&layout=compact)](https://github.com/AnaKercia1/Buscante)

[![GitHub](https://github-readme-stats.vercel.app/api/pin/?username=AnaKercia1&repo=modelo-pagina-web-vagas-emprego&bg_color=000&theme=neon&hide_border=false&&layout=compact)](https://github.com/AnaKercia1/modelo-pagina-web-vagas-emprego)

[![GitHub](https://github-readme-stats.vercel.app/api/pin/?username=AnaKercia1&repo=Mochila-de-Viagem&bg_color=000&theme=neon&hide_border=false&&layout=compact)](https://github.com/AnaKercia1/Mochila-de-Viagem)

[![GitHub](https://github-readme-stats.vercel.app/api/pin/?username=AnaKercia1&repo=Jogo-NumeroSecreto&bg_color=000&theme=neon&hide_border=false&&layout=compact)](https://github.com/AnaKercia1/Jogo-NumeroSecreto)

