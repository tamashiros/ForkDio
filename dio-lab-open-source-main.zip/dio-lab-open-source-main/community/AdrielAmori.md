
## 🚀 Sobre mim
Estou estudando para ser um  desenvolvedor full-stack...




## 🛠 Habilidades
Javascript, HTML, CSS, Python...


## Outras seções comuns em perfis do GitHub

🧠 Estou aprendendo desenvolvimento full-stack...

👯‍♀️ Procuro colaborar em projetos que utilizem Javascript e Python...

⚡️ Fatos engraçados...

