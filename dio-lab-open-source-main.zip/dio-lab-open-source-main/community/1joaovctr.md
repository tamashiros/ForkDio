### Olá, eu sou o João Victor.

- 🔭 Buscando oportunidade profissional.
- 📚 Cursando o 5º semestre de Ciência da computação.
- 🧑🏿‍🦱 Ele/dele.

![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=1joaovctr&show_icons=true&theme=midnight-purple)
##
<div style="display: inline_block"><br>
  <img align="center" alt="Rafa-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Rafa-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Rafa-BOOTSTRAP" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/bootstrap/bootstrap-original.svg">
  <img align="center" alt="Rafa-PHP" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/php/php-original.svg">
  <img align="center" alt="Rafa-PHP" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  
</div>
