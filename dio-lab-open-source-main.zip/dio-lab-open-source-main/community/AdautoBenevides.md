### Olaa 👋🏻👋🏻! sou Adauto Benevides Couto, estou cursando Análise e Desenvolvimento de Sistemas 💻 no Instituto Federal Baiano de Educação, Ciência e Tecnologia Baiano!

### Sou apaixonado por tecnologia e programação, e estou sempre em busca de novos desafios e aprendizados.

<img class="main-content" width="500px" height="281px" src="https://images7.alphacoders.com/499/499787.png" alt="Trust me, I'm a Programmer" title="Trust me, I'm a Programmer">

##

<div>
<a href="https://github.comadautoBenevides">
<img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=AdautoBenevides&layout=compact&langs_count=7&theme=dracula"/>
<img height="180em" src="https://github-readme-stats.vercel.app/api?username=AdautoBenevides&show_icons=true&theme=dracula&include_all_commits=true&count_private=true"/>
 
</div>
 
  
  ## Linguagens Dominantes
  
<div style="display: inline_block"><br>
  
<img align="center" alt="Adauto-Js" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" />

<img align="center" alt="Adauto-Js" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" />

<img align="center" alt="Adauto-Js" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" />

<img align="center" alt="Adauto-Js" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" />
  
<img align="center" alt="Adauto-Js" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" />
  
<img align="center" alt="Adauto-Js" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/c/c-original.svg" />
  
<img align="center" alt="Adauto-Js" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original-wordmark.svg" />
  
<img align="center" alt="Adauto-Js" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" />
  
<img align="center" alt="Adauto-Js" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/django/django-plain.svg" />
          
<img align="center" alt="Adauto-Js" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg" />


</div>
  
  ## Redes Sociais 
 
<div> 
  <a href="https://instagram.com/dau_benevides" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href = "mailto:daucouto9@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/adauto-benevides-b61119263/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
 
</div>

## Minhas Contribuições

[![GitHub Streak](https://streak-stats.demolab.com/?user=AdautoBenevides&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)
