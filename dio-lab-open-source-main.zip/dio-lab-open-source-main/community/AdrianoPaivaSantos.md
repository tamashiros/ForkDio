#Adriano Paiva dos Santos

&nbsp;

Me chamo Adriano e estou buscando expandir meu aprendizado para um dia atuar na área de tecnologia.

&nbsp;

O caminho é árduo mas só terá sucesso quem trilhar por ele sem desistir.

&nbsp;

##Conecte-se comigo

&nbsp;

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/adriano-paiva-dos-santos-193b8a214/)

&nbsp;

##Linguagens de Programação que estou estudando

&nbsp;

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C)

&nbsp;

##GitHub Status

&nbsp;

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AdrianoPaivaSantos&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

&nbsp;

##Repositório

&nbsp;

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AdrianoPaivaSantos&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/SEUUSERNAME/SEUREPOSITORIO)

&nbsp;

##Minhas Contribuições

&nbsp;

[![GitHub Streak](https://streak-stats.demolab.com/?user=AdrianoPaivaSantos&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

&nbsp;
