## :cherry_blossom:Olá! Sou Ana Clara Becker:cherry_blossom:

Sou formada em Arquitetura e Urbanismo e estou fazendo transição de carreira para a área de desenvolvimento de software. 

#### Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/anacbecker/)



#### Habilidades

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=JAVA)![JavaScript](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=GitHub)![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=Git&logoColor=red)![AWS](https://img.shields.io/badge/AWS-000?style=for-the-badge&logo=aws&logoColor=red)



#### GitHub Stats

```
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Ana-Becker&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

```



## 













