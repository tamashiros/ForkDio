# Alison Cavalcanti do Nascimento

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alison-cavalcanti-518677155/)
## Habilidades
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alison-Cavalcanti&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Alison-Cavalcanti&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Alison-Cavalcanti&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Alison-Cavalcanti/dio-lab-open-source)