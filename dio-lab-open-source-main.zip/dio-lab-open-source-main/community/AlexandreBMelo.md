# Alexandre Melo 


👋 Olá, eu sou o Alexandre Melo!

🎓 Estudante de Sistemas para Internet <br>
💻 Apaixonado por tecnologia e desenvolvimento web <br>
📚 Sempre em busca de novos conhecimentos e desafios <br>
🌐 Explorando o universo da programação e suas infinitas possibilidades <br>

Vamos construir algo incrível juntos!

## 🔗 Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alexandre-melo-1b9118214/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AlexandreBMelo)

## 💻 Github Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlexandreBMelo&locale=pt-br&bg_color=000&title_color=FFF&text_color=FFF&show_icons=true&icon_color=FFF)


## 🤹‍♂️ Habilidades 
![Markdown](https://img.shields.io/badge/Markdown-FFF?style=for-the-badge&logo=markdown&color=000)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5&logoColor=FFF)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=white)
![Java](https://img.shields.io/badge/java-000.svg?style=for-the-badge&logo=openjdk&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=white)

## 📲 Contato

[![Gmail](https://img.shields.io/badge/Gmail-000?style=for-the-badge&logo=gmail&logoColor=white)](mailto:contato.alexandrebmelo@gmail.com)
[![WhatsApp](https://img.shields.io/badge/WhatsApp-000?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/5575981649727)
[![Instagram](https://img.shields.io/badge/-Instagram-000?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/alx.mlo/)

