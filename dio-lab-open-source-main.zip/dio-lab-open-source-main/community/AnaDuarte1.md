# Ana Beatriz Rocha Duarte

## Experiência

Não possue experiências proffisional, mas estou em busca de adquirir novos conhecimentos na tecnologia e adentrar nesse mercado de trabalho.

## Habilidades

- Linguagens de Programação: JavaScript, Java, C e PHP
- Banco de Dados: MySQL
- Ferramentas de Desenvolvimento: Git, VS Code

## Projetos Destacados

1. **Iniciação científica**  
   Desenvolvimento de objetos de aprendizagem para auxiliar professores acerca da plataforma do APP Inventor. Inicialmente desenvolvemos uma página html estática, com css e boostrap.

2. **Projeto de extensão:**  
   Colaborei no projeto de extensão, no qual fui responsável por realizar aulas para crianças do 7° ao 9° ano da escola acerca da programação em blocos e robótica. Utilizamos as plataformas do Scratch e do Lego.


## Contato

- Email: anaberocha1333@gmail.com
- LinkedIn: [Ana Duarte](https://www.linkedin.com/in/ana-beatriz-rocha-duarte-39046723a?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app)

Sinta-se à vontade para entrar em contato para oportunidades de colaboração ou apenas para trocar experiências!