Esta é minha contribuição para o lab open source

Me chamo Lucca e isto é um teste. Minha linguagem preferida é ![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)

**Olá, mundo!**
