# Olá, eu sou Alexei Ruiz Rodríguez (AlexeiRuizR)

### Desenvoledor de Software na Truechange

## Atuação Profisional
- Engenheiro Industrial

## Email
alexeiruizrodri@gmail.com
