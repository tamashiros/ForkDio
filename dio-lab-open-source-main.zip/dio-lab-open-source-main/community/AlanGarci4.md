Olá Pessoal! Eu me chamo Alan Garcia da Silva Santos, e estou participano do Bootcamp promovido pela Santander Open Academy e sendo explanado pela Dio. Sendo QA nós últimos 5 anos atualmente venho procurando melhorar e
melhorar minhas Hards Skills, voltadas pricnipalmente a parte de codificação, com foco atualmente na amplitude do dsenvolvimento Web por meio do Java, JavaScript, Html, Css, TypeScrypt, Angular e outras tecnologias de 
linguagens de programação que possam agregar valor pra que me torne um especialista em automação de testes e com capacidade de desenvolvimento Web pleno. Sendo assim podemos nos conectar e comunicarmos pelos caminhos a seguir:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alan-garcia-santos/)
