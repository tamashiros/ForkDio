# Alcimar Silva


Eu sou um programador iniciante atraves da DIO. Minha familiaridade como a TI esta relacionada ao suporte em infraestrura.

Conecte-se comigo:

[![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/alcimar.ma/)

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Alcimar3)

[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)](mailto:alcimar3@hotmail.com)
