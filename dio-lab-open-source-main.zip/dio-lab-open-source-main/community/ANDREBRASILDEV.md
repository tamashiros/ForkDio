

# Autognose <a href="https://www.w3.org/html/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/devicon/devicon-line.svg" alt="html5" width="40" height="40"/> </a>


<p style="color:yellow" align=justify> Meu nome é André Brasil tenho 40 anos, tenho 3 lindos filhos e estou voltando para o mundo do T.I depois de um longo período fora da área. Comecei no ramo da programação com 18 anos nos tempos do ensino médio agregado ao curso técnico em programção de computadores o qual a instituição Federal do Amazonas (IFAM) proporcionava, em seguida consegui curar na mesma instituição de ensino o curso superior em desenvolvimento de software em paralelo consegui, também, passar concursado na empresa PRODAM, centro de processamento de dados que tem boa parte o Estado como controlador. Nessa empresa consegui me destacar nas linguagens: java, javascript, struts, hibernate, spring, mobiles e entre outros.</p>

<p style="color:purple" align=justify> Após longos anos nessa área conheci o Direito o qual me formei e sou bacharel. Resumindo voltei para desenvolvimento de software, pois me contrataram no TJAM para participar do projeto interno de automação dos processos judiciarios do Estado do Amazonas e quando tive a oporunidade de participar da equipe de desenvolvimento do sistema principal o PROJUDI, não tive escolha a não ser voltar para area de T.I-Dev. Hoje estou numa seria de recilagem das linguagens e frameworks e estou feliz hoje que temos instituições online como a DIO que proporicona um ensino de qualidade e uma forma de interação sem igual!</p>

## Connect for me

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/ANDREBRASILDEV)
[![WhatsApp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/5592992724472)
[![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:andre.teles.brasil)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/andré-brasil-b48333118/)
[![Facebook](https://img.shields.io/badge/Facebook-1877F2?style=for-the-badge&logo=facebook&logoColor=white)](https://www.facebook.com/andre.brazil.am/)
[![X](https://img.shields.io/badge/X-000?style=for-the-badge&logo=x)](https://x.com/SEUUSERNAME)
[![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/andre.teles.brasil/)
[![Telegram](https://img.shields.io/badge/Telegram-000?style=for-the-badge&logo=telegram&logoColor=2CA5E0)](https://t.me/AndreBrazil)


## Hard-Skill - Linguagens

<a href="https://www.w3.org/html/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="40" height="40"/> 
![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white)</a>
<a href="https://www.w3schools.com/css/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original-wordmark.svg" alt="css3" width="40" height="40"/>
![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white)</a>
<a href="https://www.java.com/pt-BR/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg" alt="java" width="40" height="40"/>
![Java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)</a>
<a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/>
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
</a>
<a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/>
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
</a>
<a href="https://kotlinlang.org/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/kotlin/kotlin-original.svg" alt="kotlin" width="40" height="40"/>
![Kotlin](https://img.shields.io/badge/Kotlin-111111?&style=for-the-badge&logo=kotlin&logoColor=purple)
</a>

## Hard-Skill -FrameWorks

![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)
![React Native](https://img.shields.io/badge/React_Native-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)
![Angular](https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white)
![Flutter](https://img.shields.io/badge/Flutter-02569B?style=for-the-badge&logo=flutter&logoColor=white)
![Django](https://img.shields.io/badge/django-%23092E20.svg?style=for-the-badge&logo=django&logoColor=white)![Spring](https://img.shields.io/badge/spring-%236DB33F.svg?style=for-the-badge&logo=spring&logoColor=white)

## Hard-Skill - Banco de Dados

![MySQL](https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-000?style=for-the-badge&logo=postgresql)

## Hard-Skill - Ferramentas

![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)
![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)
![NodeJS](https://img.shields.io/badge/node.js-6DA55F?style=for-the-badge&logo=node.js&logoColor=white)


## 📊 Github Analytics
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=ANDREBRASILDEV&theme=transparent&bg_color=000&border_color=facd05&show_icons=true&icon_color=facd05&title_color=facd05&text_color=FFF)



