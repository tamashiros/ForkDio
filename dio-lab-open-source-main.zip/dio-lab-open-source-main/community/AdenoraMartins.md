Contribuição Projeto Open Source DIO
Olá sou Adenora, estudante de tecnologia e faço parte da comunidade DIO onde estou participando do Bootcamp Santander 2024 - Preparatório Certificação AWS.

🚀 Sobre mim
Estudo Análise e Desenvolvimento de Sistemas. Realizei alguns cursos voltados para Desenvolvimento Full Stack.

🔗 Links
linkedin

🛠 Habilidades
Javascript, HTML, CSS, Python, Inteligência Artificial
