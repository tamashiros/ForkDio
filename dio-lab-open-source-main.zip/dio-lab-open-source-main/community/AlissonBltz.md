# Sou Alisson Szynkoviak

Tenho 25 anos e estou cursando Análise e Desenvolvimento de Sistemas pela Unicesumar, estou focado em estudar Java para ganhar proeficiência na área, tenho interesse também na área de jogos e amo jogar.


## Conecte-se Comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-FFF?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alissonbltz/)

[![Instagram](https://img.shields.io/badge/Instagram-FFF?style=for-the-badge&logo=instagram)](https://www.instagram.com/zunterr_/)