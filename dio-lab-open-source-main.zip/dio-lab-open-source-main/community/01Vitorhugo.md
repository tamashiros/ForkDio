<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=ffff&height=120&section=header"/>



<h1 align="center">Olá! Eu sou o Vitor Hugo 👋</h1>


 <h2>Sobre mim</h2> 
Estudante de Análise e Desenvolvimento de Sistemas e apaixonado pro tecnologia. Gosto muito do Full-Stack, porém estou focando mais no Front-End.

<h2>Redes Sociais</h2>

<div style="display: flex">
<br>

[![linkedin](https://img.shields.io/badge/linkedin-000?style=for-the-badge&logo=linkedin&logoColor=blue)](https://www.linkedin.com/public-profile/settings?trk=d_flagship3_profile_self_view_public_profile)

[![instagram](https://img.shields.io/badge/instagram-000?style=for-the-badge&logo=instagram&logoColor=blue)](https://twitter.com/)
</div>

<h2>Habilidades</h2>

<div style="display: flex">
<br>

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=yellow)

![ReactJs](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react&logoColor=blue)

![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript&logoColor=blue)

![Php](https://img.shields.io/badge/Php-000?style=for-the-badge&logo=php&logoColor=blue)

![FireBase](https://img.shields.io/badge/firebase-000?style=for-the-badge&logo=firebase&logoColor=yellow)

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=blue)

![SASS](https://img.shields.io/badge/SASS-000?style=for-the-badge&logo=sass)

![Styled-Component](https://img.shields.io/badge/StyledComponent-000?style=for-the-badge&logo=styledComponents)

</div>

<div  align="center">

![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=01VitorHugo&layout=compact&langs_count=7&theme=react)

</div>
 
<h2>Sistema operacional</h2>
<br>

![Windows](https://img.shields.io/badge/Windows-000?style=for-the-badge&logo=windows&logoColor=2CA5E0)

<h2>Conecte-se comigo</h2>
<br>

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/01Vitorhugo)

