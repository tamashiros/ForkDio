<div align="center" style="text-align: center;">
  <a href="https://git.io/typing-svg">
    <img src="https://readme-typing-svg.herokuapp.com/?center=true&vCenter=true&color=ffffff&lines=Olá,%20+me+chamo+Lucas+Carvalho;Seja+muito+bem+vindo!+:)" alt="Typing SVG">
  </a>
</div>

<div align="center"> 
  <a href="https://www.instagram.com/1ucas_ruan/" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href = "mailto:lucasruan1.tuc@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/lucas-carvalho-a2125a186/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>   
</div>

<div>
  <h3>Eu gosto de...</h3>
  <br>
  <ul>
    <li>👩‍💻 Codar</li>
    <li>🎮 Jogar</li>
    <li>☕ Café</li>
  </ul>
</div>

<br>

<h2 align="center">Principais tecnologias:</h2>
</br>
<div align="center">
  <img src="https://skillicons.dev/icons?i=html,css,js,ts,nodejs,py,cs,java,spring,react,mysql,git,github,vscode,visualstudio,figma,&perline=8" />
</div>

<br> </br>

<h2 align="center">💻 GitHub Profile Stats</h3>
</br>
<div align="center"> 
  <a href="https://github.com/1ucasruan">
  <img src="https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=1ucasruan&layout=compact&hide_border=true&theme=dracula" alt="Profile statistics" height="180em"><a>
  <img src="https://github-profile-summary-cards.vercel.app/api/cards/stats?username=1ucasruan&layout=compact&hide_border=true&theme=dracula" alt="Profile statistics" height="180em"></a>
</div>