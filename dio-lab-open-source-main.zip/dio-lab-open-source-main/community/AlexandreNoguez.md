### Olá, eu sou o Alexandre Noguez, desenvolvedor de software fullstack!
#
<p>
  Trabalho como desenvolvedor de software React/Nodejs a 1 ano e 4 meses em uma empresa de automação e gestão de energia através 
  de dispositivos IoT. Criando, organizando e gerindo minha equipe de desenvolvimento para adicionar novas funcionalidades para 
  plataforma de acordo com o roadmap desenhado pelo PO e CTO para atender as necessidades dos clientes.
</p>

#
### Educação
* Superior de Tecnologia em Análise e Desenvolvimento de Sistemas | (UniLasalle)<br/>


### Tecnologias

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-0D1117?style=for-the-badge&logo=javascript)&nbsp;
![React](https://img.shields.io/badge/react-%2320232a.svg?style=for-the-badge&logo=react&logoColor=%2361DAFB)
![NodeJS](https://img.shields.io/badge/node.js-6DA55F?style=for-the-badge&logo=node.js&logoColor=white)
![Angular.js](https://img.shields.io/badge/angular.js-%23E23237.svg?style=for-the-badge&logo=angularjs&logoColor=white)
![Bootstrap](https://img.shields.io/badge/bootstrap-%238511FA.svg?style=for-the-badge&logo=bootstrap&logoColor=white)
![NPM](https://img.shields.io/badge/NPM-%23CB3837.svg?style=for-the-badge&logo=npm&logoColor=white)
![MongoDB](https://img.shields.io/badge/MongoDB-%234ea94b.svg?style=for-the-badge&logo=mongodb&logoColor=white)
![MySQL](https://img.shields.io/badge/mysql-%2300f.svg?style=for-the-badge&logo=mysql&logoColor=white)
![Java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)
![Spring](https://img.shields.io/badge/Spring-6DB33F?style=for-the-badge&logo=spring&logoColor=white)


### Github Analytics
![Alexandre GitHub stats](https://github-readme-stats.vercel.app/api?username=AlexandreNoguez&show_icons=true&theme=tokyonight)
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=AlexandreNoguez&layout=compact&theme=tokyonight)


### Conecte-se comigo!

[![LinkedIn](https://img.shields.io/badge/LinkedIn-CCC?style=for-the-badge&logo=linkedin&logoColor=blue)](https://www.linkedin.com/in/alexandre-noguez/)
