## Sobre mim

É um prazer! Sou Ana Luiza, tenho 20 anos. Atualmente, estou no 4° período do curso [Ciência da Computação](https://www.ifnmg.edu.br/noticias-moc/noticias-2012/3378-curso-de-bacharelado-em-ciencia-da-computacao) no Instituto Federal do Norte de Minas Gerais.

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/ana-luiza-nobre-cordeiro/)[![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/nalunobrec/)[![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:analuizanc13@gmail.com)

![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=AnaLuizanc&hide=contribs,issues&theme=transparent&hide_rank=true)    ![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=AnaLuizanc&layout=compact&theme=transparent)
