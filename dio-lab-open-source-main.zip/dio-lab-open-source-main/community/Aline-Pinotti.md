# Aline Pinotti
![MyOctoCat](https://avatars.githubusercontent.com/u/164499124?v=4){: width="100px"}

## Conecte-se comigo
[![GitHub](https://img.shields.io/badge/GitHub-7389DA?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/Aline-Pinotti) [![LinkedIn](https://img.shields.io/badge/LinkedIn-7389DA?style=for-the-badge&logo=linkedin&logoColor=fff)](www.linkedin.com/in/aline-pinotti) [![Instagram](https://img.shields.io/badge/Instagram-7389DA?style=for-the-badge&logo=instagram&logoColor=fff)]([www.linkedin.com/in/aline-pinotti](https://www.instagram.com/garciaaline32))

## Habilidades

- O que uso no meu trabalho atual

    ![HTML5](https://img.shields.io/badge/HTML5-0D1117?style=for-the-badge&logo=html5) ![CSS3](https://img.shields.io/badge/CSS3-0D1117?style=for-the-badge&logo=css3&logoColor=1572B6)

    ![PL](https://img.shields.io/badge/PL%2FSQL-FFFFFF?style=for-the-badge&logo=oracle&logoColor=FF0000&labelColor=FFFFFF&color=0D1117) ![JavaScript](https://img.shields.io/badge/JavaScript-0D1117?style=for-the-badge&logo=javascript)

    ![Bootstrap](https://img.shields.io/badge/-boostrap-0D1117?style=for-the-badge&logo=bootstrap&labelColor=0D1117) ![.NET](https://img.shields.io/badge/.NET-0D1117?style=for-the-badge&logo=.net&logoColor=5C2D91)

- Em qual já me formei, mas não estou usando (infelizmente)
![Java](https://img.shields.io/badge/java-%230D1117.svg?style=for-the-badge&logo=openjdk&logoColor=ED8B00)

- O que estou estudando atualmente
  ![JavaScript](https://img.shields.io/badge/JavaScript-0D1117?style=for-the-badge&logo=javascript) ![Python](https://img.shields.io/badge/python-0D1117?style=for-the-badge&logo=python&logoColor=ffdd54)

## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Aline-Pinotti&theme=transparent&bg_color=7389DA&show_icons=true&icon_color=2d418c&title_color=2d418c&text_color=FFF&hide_title=true&hide=stars)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Aline-Pinotti&bg_color=7389DA&border_color=fff&title_color=2d418c&text_color=FFF)

<!--## Minhas Contribuições


 [![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Aline-Pinotti&repo=dio-lab-open-source&bg_color=7389DA&border_color=2d418c&show_icons=true&icon_color=2d418c&title_color=2d418c&text_color=FFF)](https://github.com/Aline-Pinotti/dio-lab-open-source/community/Aline-Pinotti.md) -->
