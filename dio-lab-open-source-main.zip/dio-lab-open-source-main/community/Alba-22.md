## Hey there, I'm [Alba](https://alba.dev) 👋

<img src="https://raw.githubusercontent.com/Alba-22/Alba-22/main/images/estus_flask.gif" min-width="400px" max-width="400px" width="300px" align="right" alt="Estus Flask">

### 👨🏻‍💻 About me

<p align="left">
  <li>🏠 Living in Uberlândia - MG, Brazil</li>
</p>

<p align="left">
  <li>📜 Studying Computer Science at Federal University of Uberlândia(UFU)</li>
</p>

<p align="left">
  <li>💼 Working as Mobile Developer @ <a href="https://www.linkedin.com/company/act-digital/">Act Digital</a></li>
</p>

### 🛠 Tech Stack

![Dart](https://img.shields.io/badge/Dart-02569B?style=for-the-badge&logo=dart&logoColor=white)
![Firebase](https://img.shields.io/badge/Firebase-F5820D?style=for-the-badge&logo=firebase&logoColor=white)
![Flutter](https://img.shields.io/badge/Flutter-0175C2?style=for-the-badge&logo=flutter&logoColor=white)
![Git](https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white)
![Figma](https://img.shields.io/badge/Figma-AE4DFF?style=for-the-badge&logo=figma&logoColor=white)

### 📧 Get in touch with me

[![Twitter](https://img.shields.io/badge/Twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white)](https://twitter.com/zAlba22)
[![Linkedin](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alba22/)
[![Discord](https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white)](https://discord.com/users/304785670520700928)

### 👨‍💻 My Coding Activity in the Last Year(by Wakatime)

[![Wakatime](https://wakatime.com/share/@alba22/94cef256-3022-4044-9967-0fb046c32530.svg)](https://wakatime.com/@alba22)

<!-- ![https://wakatime.com/share/@alba22/94cef256-3022-4044-9967-0fb046c32530.svg](https://wakatime.com/share/@alba22/94cef256-3022-4044-9967-0fb046c32530.svg) -->
