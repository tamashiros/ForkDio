### Olá, eu sou Alvaro Baffi 

**Formação** 
- Formado em Matemática
- Cursando Bootcamp Santander java back-end

**Espectativas**
- Após a minha graduação em matemática percebi que a área de desenvolvimento seria perfeita para mim, então por curiosidade comecei a pesquisar e estudar sobre ela, foi quando desenvolvi o gosto por programação.
- Atualmente estou estudando para me capacitar e conseguir uma oportunidade de colocar meus conhecimentos em prática.
