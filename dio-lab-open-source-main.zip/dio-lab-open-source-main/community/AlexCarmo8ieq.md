# | AlexCarmo8ieq

## Sobre mim.
Atuo na área de T.I a 10 anos como Suporte de T.I, formado em Superior de Técnologia de Gestão em T.I, estou na DIO para desenvolver novas habilidades relacionadas a programação, criando um portifólio que cause interesse nos recrutadores. Amo hardware, mas atualmente estou quebrando um preconceito próprio a respeito de desenvolvimento de códigos e aceitando novos desafios.





### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://web.dio.me/users/alexsandronew)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:alexsandronew@hotmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/alex-sandro-nascimento-96535895/)
[![Intagram](https://img.shields.io/badge/-Instagram-000?style=for-the-badge&logo=Instagram&logoColor=30A3DC)](https://www.instagram.com/alex.nascimentocarmo/)
[![Facebook](https://img.shields.io/badge/-Facebook-000?style=for-the-badge&logo=Facebook&logoColor=30A3DC)](https://www.facebook.com/alex.nascimentocarmo)

## GitHub Stats


![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlexCarmo8ieq&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
