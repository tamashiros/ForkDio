# Amanda Prudêncio

#### Não atuo na área tecnológica, estou em busca da transição de carreira, então procuro constantemente aquirir conhecimentos da área.

### Conecte-se comigo

[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://https://discord.com/channels/@Amanda_sz/)

[![GitHub](https://img.shields.io/badge/GitHbt-000?style=for-the-badge&logo=github&logoColor=white)](+https://github.com/Amanda-psz)

### Habilidades
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Amanda-psz&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Amanda-psz&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)


[![GitHub Streak](https://streak-stats.demolab.com/?user=Amanda-psz&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)
