# Olá! Me chamo Alana Amancio 👋



## 🎓 Sobre mim

Sou graduada em filosofia e tenho pós-graduação e psicopedagogia, atualmente estou migrando para a área de programação e estou amando cada nova descoberta e aprendizagem. 



### :rocket: **Minha jornada** 

Durante minha graduação fui despertando interesse pela programação graças a um amigo, após alguns tempo decidi que esse seria o novo caminho que iria trilhar, me apaixonei por esse universo e tenho me dedicado a aprender sobre as variadas  possibilidades para decidir qual faculdade fazer. 



# 💻 Habilidades e Expertise



### 🔧 Linguagens de programação



### ![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)

### ![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)

### ![HTML](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)

### ![CSS](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)

### ![Java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)



# :link:Links 



[![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/aamancios/)

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alana-amancio-sousa-46176b182/)

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AlanaAmancio)

[![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](alanalgm@gmail.com)



# 📈 Github Stats



|                                                              |
| :----------------------------------------------------------: |
| ![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlanaAmancio&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF) |



