[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&center=true&vCenter=falso&repeat=verdadeiro&random=falso&width=435&lines=Welcome!;Hey+everyone!+I+am+Alex+Junior+;I+am+18+years+old!;A+Front-End+Developer!)](https://git.io/typing-svg)
<br>
<br>
[![Ashutosh's github activity graph](https://github-readme-activity-graph.vercel.app/graph?username=AlexjrFS&bg_color=transparent&color=e6e6e6&line=0581f5&point=1a1aff&area=true&hide_border=true)](https://github.com/ashutosh00710/github-readme-activity-graph)
<br>
  <br>
 <div align="center">
  <a href = "https://github.com/AlexjrFS">
  <img height="210em" src="https://github-readme-stats.vercel.app/api?username=AlexjrFS&show_icons=true&theme=dracula&include_all_commits=true&count_private=true"/>
  <img height="290em" width="290rem" src="https://github-readme-stats.vercel.app/api/top-langs/?username=AlexjrFS&layout-compact&langs_count=16&theme=dracula"/>
</div>

  <br>
  <br>
   <h2>I am courrently learning about: </h2>  
<div > 
  <img align = "center" alt="Alex-TS" height="35" width="50" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-plain.svg" />
  <img align = "center" alt="Alex-JS" height="35" width="50" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-plain.svg"/>
  <img align = "center" alt="Alex-HTML" height="35" width="50" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" />
  <img align = "center" alt="Alex-CSS" height="35" width="50" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-plain.svg" />
  <img align = "center" alt="Alex-TAILWIND" height="35" width="50" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/tailwindcss/tailwindcss-plain.svg" />
  <img align = "center" alt="Alex-BOOTSTRAP" height="35" width="50" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original.svg" />
  <img align = "center" alt="Alex-REACT" height="35" width="50" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" />
  <img align = "center" alt="Alex-MYSQL" height="35" width="50" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" />       
  <img align = "center" alt="Alex-FIGMA" height="35" width="50" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/figma/figma-original.svg"" />
  <img align = "center" alt="Alex-CSS" height="35" width="50" src="https://cdn-icons-png.flaticon.com/512/226/226777.png" />
</div>
<br>
<h2>Contact:</h2>
<div>
    <a href="mailto:afortunatosacramento@gmail.com"><img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" target="_blanck">
    <a href="https://www.linkedin.com/in/alex-junior08122223/"><img src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blanck">
    <a href="https://www.instagram.com/_.alexx12_"><img src="https://img.shields.io/badge/Instagram-0077B5?style=for-the-badge&logo=instagram&logoColor=white" target="-blanck"></a>
  </div>
<!---
AlexjrFS/AlexjrFS is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
