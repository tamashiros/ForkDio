
# 🦝 Ailton Sergio Alves Riciopo

## Meu Perfil para o desafio de Projeto de Contribuição Open-Source pelo Github

###
 Sou um profissional trabalhando ha mais de 40 anos com informática em ambiente mainframe, com vasta experiência em infraestrutura (Suporte de Sistema Operacional z/OS, análise de performance e planejamento de capacidade, suporte bancos de dados DB2, ambiente transacional CICS, MQ Series, vários softwares IBM e não IBM, administração de storage).  Apesar de trabalhar em um alto cargo executivo, ainda gosto muito de programar.  Minhas linguagens nativas são Assembler para sistemas Z, Cobol e Easytrieve.  Estou aprendendo a programar Java e Phyton para acompanhar minha filha, que começou o curso superior de Enegenharia de SW

## Meus objetivos imediatos:

#### 1° - Aprender a programar em Python
#### 2° - Aprencer a programar em Java
#### 3° - Me aprofundar em IA