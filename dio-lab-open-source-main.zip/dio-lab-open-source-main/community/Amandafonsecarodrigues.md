# Amanda Fonsêca Rodrigues

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Amandafonsecarodrigues&layout=compact&bg_color=000&border_color=E94D5F&title_color=E94D5F&text_color=FFF)

## Entre em contato

[![LinkedIn](https://img.shields.io/badge/LinkedIn-E94D5F?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/amanda-fonseca-b4189426b/)

[![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/amandafonsca/)

[![GitHub](https://img.shields.io/badge/GitHub-E94D5F?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Amandafonsecarodrigues)

## Linguagens de Programação

![JavaScript](https://img.shields.io/badge/JavaScript-E94D5F?style=for-the-badge&logo=javascript&logoColor=white)

![Java](https://img.shields.io/badge/java-%E94D5F.svg?style=for-the-badge&logo=openjdk&logoColor=white)

![C](https://img.shields.io/badge/C-E94D5F?style=for-the-badge&logo=c&logoColor=white)

## Linguagens de marcação e estilo

![HTML5](https://img.shields.io/badge/HTML5-E94D5F?style=for-the-badge&logo=html5&logoColor=white)

![CSS3](https://img.shields.io/badge/CSS3-E94D5F?style=for-the-badge&logo=css3&logoColor=white)
