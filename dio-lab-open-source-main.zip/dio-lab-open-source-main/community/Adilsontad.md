# Adilson Tadeu de Paula

Atualmente atuando como consultor de atendimento na rede de farmácias PanVel e buscando aprender programação que é uma área muito fascinante 
