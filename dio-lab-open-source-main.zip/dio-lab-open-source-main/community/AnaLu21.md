# Ana Luisa
Olá!, me chamo Ana Luisa e estou cursando Banco de dados no Senac. Estou em busca da minha primeita oportunidade na área de dados.

# Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/ana-vasconcelos-b0690b265/)