# Alan Soares

Olá, me formei como tecnólogo em Análise e Desenvolvimento de Sistemas em 2023. Conheci a DIO em 2020, ainda nos primeiros semestres da faculdade, com um bootcamp de NodeJs. Ao final de 2020 entraria no mercado de trabalho, não utilizando Node, como eu planejava, mas sim C#/.NET!

No meu perfil do github você pode encontrar repositórios antigos, criados durante o primeiro bootcamp.

Não tenho um portfólio variado para .NET (apesar de ter trabalhado com a ferramenta por 2 anos), mas você pode checar o repositório do projeto [![CraftPls](https://img.shields.io/badge/craftpls-red)](https://github.com/AlanSoares21/craftpls) (ou, caso não queira ler código, pode ver a [implementação clicando aqui](https://ws.craftpls.app.br))

## Redes Sociais
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue?style=for-the-badge&logo=linkedin&logoColor=fff)](https://www.linkedin.com/in/alan-s-silva26) [![LinkedIn](https://img.shields.io/badge/Github-black?style=for-the-badge&logo=github&logoColor=FFF)](https://github.com/AlanSoares21)