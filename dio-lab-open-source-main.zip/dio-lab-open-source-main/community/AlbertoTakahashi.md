# Alberto Takahashi 🤔

Oi! Eu sou o Alberto, engenheiro eletricista (UFMG) e tecnólogo em Análise e Desenvolv de Sistemas (PUC-PR). 

## Minha Atuação 🛠️

Trabalhei por muitos anos na área de engenharia (telecom) atuando principalmente no desenvolvimento de projetos de redes de voz (convencional e IP) e dados (WAN e LAN) assim como infraestruturas de segurança e  datacenter.

Agora busco meus primeiros passos em um novo desafio, na área de desenvolvimento de aplicativos...

## Meus contatos
[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AlbertoTakahashi)
[![Yahoo](https://img.shields.io/badge/Yahoo-0077B5?style=for-the-badge&logo=Yahoo&logoColor=white)](mailto:alberto_takahashi@yahoo.com.br)

## Habilidades

![MySQL](https://img.shields.io/badge/mysql-4479A1.svg?style=for-the-badge&logo=mysql&logoColor=white)
![Postgres](https://img.shields.io/badge/postgres-%23316192.svg?style=for-the-badge&logo=postgresql&logoColor=white)
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![PowerBI](https://img.shields.io/badge/powerbi-3670A0?style=for-the-badge&logo=powerbi&logoColor=ffdd54)