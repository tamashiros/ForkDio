### Oi Oiii Devs 👋

## <img width="50" src="https://img.freepik.com/vetores-premium/nao-sei7_619097-115.jpg"> **Quem Sou eu?**
Me chamo Ana Clara, Tenho 20 anos, Atualmente Trabalho como Programadora Trainee na IOB. Estudo Ciência da Computação e sou apaixonada pela área Tech. Adoro jogos de FPS e tomar um bom drink. ✨

## **Linguagens e Ferramentas**  

<code><img height="30" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mongodb/mongodb-original.svg">
<code><img height="30" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original.svg"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png"></code>
<code><img height="30" src="https://icons.iconarchive.com/icons/tatice/cristal-intense/48/Java-icon.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/visual-studio-code/visual-studio-code.png"></code>
<code><img height="30" src="https://img.icons8.com/color/48/000000/visual-studio.png"></code>
<code><img height="30" src="https://brandslogos.com/wp-content/uploads/images/eclipse-logo-vector.svg"></code>
<code><img height="30" src="https://git-scm.com/images/logos/downloads/Git-Icon-1788C.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/html/html.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/css/css.png"></code>
<code><img height="30" src="https://cdn.icon-icons.com/icons2/2667/PNG/512/another_redis_desktop_manager_icon_161297.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/terminal/terminal.png"></code>
<code><img height="30" src="https://wac-cdn.atlassian.com/dam/jcr:5cae308d-24a4-40d0-8fe2-ce7f46cd7a02/JSW%20sign-responsive.png?cdnVersion=1180"></code>
<code><img height="30" src="https://cdn-icons-png.flaticon.com/512/25/25231.png"></code>
<code><img height="30" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Jenkins_logo.svg/1483px-Jenkins_logo.svg.png"></code>


## **GitHub Estatísticas**

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AnaDamiao&theme=transparent&bg_color=000&border_color=ee19c3&show_icons=true&icon_color=ee19c3&title_color=44f3f6&text_color=FFF)

## **Linguagens mais Utilizadas em meus Repositórios**

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AnaDamiao&layout=compact&bg_color=000&border_color=ee19c3&title_color=44f3f6&text_color=FFF)

## **Contribuições**

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AnaDamiao&repo=provaTech4me-bruana&bg_color=000&border_color=ee19c3&show_icons=true&icon_color=ee19c3&title_color=44f3f6&text_color=FFF)](https://github.com/AnaDamiao/provaTech4me-bruana)
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AnaDamiao&repo=tech4pet&bg_color=000&border_color=ee19c3&show_icons=true&icon_color=ee19c3&title_color=44f3f6&text_color=FFF)](https://github.com/AnaDamiao/tech4pet)

[instagram]: https://www.instagram.com/damiao_clara/
[linkedin]: https://www.linkedin.com/in/ana-clara-dami%C3%A3o-1a280a234/
<br>

#### Conecte Comigo em Minhas Rede Sociais!
**|** 
👔 [linkedin][linkedin] **|** 
📷 [instagram][instagram] **|** 