<img width=100% src="https://capsule-render.vercel.app/api?type=waving&height=180&color=gradient&text=Alex%20Vieira%20da%20Silva&+Mangueira&fontSize=25&fontColor=ffffff&animation=twinkling&fontAlignY=35"/>

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alex-vieira-2456a61b7/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)](mailto:alexvieira.360@hotmail.com)

## Meu GitHub

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alex-Vieira-da-Silva&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=almangr&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)


## Minhas Tecnologias

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![Sass](https://img.shields.io/badge/Sass-000?style=for-the-badge&logo=sass)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Git](https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white)
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)
![Node.js](https://img.shields.io/badge/Node.js-339933?style=for-the-badge&logo=node.js&logoColor=white)
![Microsoft SQL Server](https://img.shields.io/badge/Microsoft%20SQL%20Server-1e88e5?style=for-the-badge&logo=microsoft-sql-server&logoColor=white)
![Oracle Database](https://img.shields.io/badge/Oracle%20Database-CC2927?style=for-the-badge&logo=oracle&logoColor=white)
![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript)
![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=angular&logoColor=C3002F)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java&logoColor=white)
![Dotnet](https://img.shields.io/badge/Dotnet-000?style=for-the-badge&logo=dotnet&logoColor=white)
![Dynamics 365](https://img.shields.io/badge/Dynamics-000?style=for-the-badge&logo=dynamics&logoColor=white)
![Postgre SQL](https://img.shields.io/badge/Postgre%20SQL-4fc3f7?style=for-the-badge&logo=postgresql&logoColor=white)
