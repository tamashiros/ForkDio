
# DIO | Contribuição AktEric 
### Deixando minha jornada até aqui 

Repositório para armazenar meu pequeno conhecimento, assim como minha demostração de inicio de jornada, minha personalidade e habilidades desenvolvidas com minha pequena vivência. 

## 📖 Experiências com progamação
- 2018-2022 Estudado Delphi, HTML, PHP em meu curso técnico
- 2022-2023 Foram 6 meses de suporte técnico, ótimos para aprender como funciona SQL e estrutura de código.
- 02/2023-05/2023 Pequeno projeto da Sponte, onde nos ensinaram CSharp e onde comecei a amar a programação.
-04/2024 - Primeiro Bootcamp ganhado do Santander pela Dio

## 🥸 Habilidades desenvolvidas 

|Soft Skills |  Hard Skills |
|------------|--------------|
|Comunicação |Lógica de programção|
|Proatividade|PHP| 
|Adaptação fácil|Delphi|
|Ótima Sociabilidade|SQL|
|Mentalmente Estavel|Analise de sistemas|
|Lido bem com problemas|Redes e comunicação|
|Aprende bem com desafios|CSharp



## 🏆Conquistas
- Reconhecimento de projeto desenvolvido em hacktoon para melhoria da cidade em pandemia, assinado pelo vice-prefeito e encaminhado para analise de desenvolvimento do SUS.
- Vitória da competição regional da Unidep como co-lider com a PatoIA, fazendo parte do time de apresentação e controlando as arrecadação.
- Aprovação na Bootcamp do Santander


## 👾 Hobbys
- Leituras: Filosofia:Nietzsche, Platão e Sócrates
- Jogos FPS: MMO, Estratêgia e Mundo Aberto
- Esportes: Futebol, Vôlei e Futvôlei
- Filmes: Ficção, Desenhos e comédia