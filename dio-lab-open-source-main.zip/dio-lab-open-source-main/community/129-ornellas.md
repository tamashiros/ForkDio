# Oi, eu sou Marcos.

  <div id="badges">
  <a href = "https://www.linkedin.com/in/marcos-ornellas">
    <img src="https://img.shields.io/badge/LinkedIn-blue?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn Badge"/>
  </a>
</div>

Sou um Desenvolvedor Fullstack com quase dois anos de experiência em aplicações web.

Atualmente integro o time de tecnologia da Amais Educação, desenvolvendo relatórios web-template dinâmicos utilizando as tecnologias PHP, KoolReport, MySQL, HTML, CSS, Bootstrap, Git, Docker, Linux dentre outras. Sou responsável pelo funcionamento da aplicação, acolhimento de chamados e alinhamentos com os clientes sobre os produtos.

Também tenho experiência em Python, Django, Javascript e Vue.js, onde desenvolvi diversas aplicações do zero e realizei ajustes e melhorias em aplicações já desenvolvidas, pensando toda arquitetura de software e nos ciclos de vida dos apps.

Além disso, me considero muito comunicativo, gosto de entender os problemas e sempre pensar nas melhores soluções a serem implementadas. Acredito que a união e a colaboração são as melhores formas de atingir objetivos com exatidão.