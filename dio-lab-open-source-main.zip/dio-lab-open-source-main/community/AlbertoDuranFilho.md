<h1 align="center">Olá, Eu sou Alberto Duran</h1>
<h3 align="center">Graduando em Desenvolvimento e análise de Sistemas pelo SENAC e Desenvolvedor Full-Stack na empresa Montês Tecnologia</h3>

<div align="center">
  <a href="https://github.com/albertoDuranFilho">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=albertoDuranFilho&show_icons=true&theme=dracula&include_all_commits=true&count_private=true"/>
   <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=albertoDuranFilho&layout=compact&langs_count=16&theme=dracula" />
</div>
<div align="center">
<h3 >Tecnologias</h3>
 <div style="display: inline_block" ><br>
  <img align="center" alt="Alberto-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Alberto-Ts" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-plain.svg">
  <img align="center" alt="Alberto-React" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg">
  <img align="center" alt="Alberto-nodejs" height="30" width="40" src="https://cdn.worldvectorlogo.com/logos/nodejs-icon.svg">
  <img align="center" alt="Alberto-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Alberto-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Alberto-git" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/git/git-original.svg">
</div>
</div>
 
<div align="center">
<h3 >Contatos</h3>
<div> 
  <a href="https://instagram.com/betoduranf" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href = "mailto:albertoduranfilho@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/alberto-janeiro" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>  
  
 ![Snake animation](https://github.com/AlbertoDuranFilho/AlbertoDuranFilho/blob/output/github-contribution-grid-snake.svg)  
</div>
</div>
  
<div align="center">
  <p>Feito com :heart: e JavaScript.</p>
  <p>Créditos: <a href="https://github.com/anuraghazra/github-readme-stats">Anurag Hazra</a> e <a href="https://github.com/rafaballerini">Rafaella Ballerini</a></p>
</div>

