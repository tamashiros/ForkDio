# Aline Porto

# Conecte-se comigo
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/)
# Habilidades
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
# Github Status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=alinep29&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
# Minhas Contribuições

