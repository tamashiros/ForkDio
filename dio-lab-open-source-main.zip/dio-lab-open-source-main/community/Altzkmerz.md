
<h1>
    <a href="https://Altzkmerz.github.io/">
        <img align="center" alt="Logo Altzkmerz" width="40px" src="https://i.imgur.com/hCUAGvf.png">
    </a>
    <span style="color: #a7755c;">Altzkmerz</span>
</h1>


<img align="right" alt="me!" height="200" src="https://i.imgur.com/crBrIG4.png">

💻 I'm a developer in development :D 

👩‍🎓 I graduated Production Engineering, and I have been working as a Microsoft Dynamics 365 CRM functional consultant from almost 2 years now, but I've always been interested in programming and, so, recently decided to study harder to improve my skills.

👩‍🏫 When I'm not working and studying I'm teaching at my ESL online school called [Cross Module](https://www.crossmodule.com.br/), where I'm a coordinator to the kids and teens course. 

🎮 Buuuut, of course I can have fun too, and my hobbies include playing video games, watching series and movies (and overanalyzing them) and drawing.

### You can also find me on

[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=fff&color:a7755c)](https://www.linkedin.com/in/amandagc2/) 


<h3 align="left">GitHub Stats (yet to improve)</h3>

![GitHub stats](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api?username=Altzkmerz&hide_title=true&show_icons=true&include_all_commits=false&count_private=true&line_height=25&hide=issues&bg_color=fff&title_color=a7755c&text_color=a7755c&border_radius=3&border_color=fbddae&icon_color=a7755c&theme=jolly)

<details align="left">
  <summary></summary> 
 
  - GitHub Stats by <a href="https://github.com/anuraghazra/github-readme-stats">anuraghazra</a>.
  - Wanna learn English? Check my awesome school <a href="https://www.crossmodule.com.br/">here</a>.