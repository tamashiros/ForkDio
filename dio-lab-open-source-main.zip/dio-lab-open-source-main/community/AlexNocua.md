<center>

# Fala pessoal, Sou Alex Nocua. 😉

</center>
<center>Estudante de Engenharia de Sistemas na Colombia 
<br>
<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAACXBIWXMAAAsTAAALEwEAmpwYAAABrklEQVR4nO2YIU4DURRFRzS5a2AhlT+DANOkKbVFsAVsCQmrGYHAdTQzqiuYBZBg8bhHxmBH/d5HOCe5GzjnffObBgAAAAAAAAAAAAAAAADglxhW63jXNVN9B8NqvXh6MWiKUcFU38GgiSBjomMjiPwRCCK/eILIL5sg8gsmiPxSCSK/SILIL48g8gsjiPySCJJAzEgQv4wxwfg6kT8CQeQXTxD5ZRNEfsEEkV8qQeQXSRD55RFEfmEEkV8SQRKIGQnilzEmGF8n8kcgiPziCSK/bILIL5gg8ksliPwiCSK/PILIL4wg8kvKFmR36M67++6LdfUdHLrzYpB2f5rafR+sv4CD0/ILIUh/wWMkSOR6+QQJfwSChF88QcIvmyDhF0yQ8EslSPhFEiT88ggSfmEECb8kgiQQ0+cN8rR5/njZHIMdqzuYXS8G+WyvvqM0wZrqDmbXBCl5jo0gxR+BIMUvniDFL5sgxS+YIMUvlSDFL5IgxS+PIMUvjCDFL4kgCcQEQfwyIsH4Oil/MMjr7d3D2832kW2rO5hdLwYBAAAAAAAAAAAAAAAAgOb/8AMoNJZG7V/NBwAAAABJRU5ErkJggg==" ></center>
<center>

## Conecte-se comigo

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://www.dio.me/users/nocua68)
[![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:nocua68@gmail.com)
[![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/alexnocua_/)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/alexnocua/)
[![Discord](https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white)](https://discord.com/channels/@alexnocua/)
[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AlexNocua)

## Mais informações:

![Foto de perfil](https://alexnocua.netlify.app/IMG/yo3.jpg)

**Idade:** 21 anos.

**Idiomas:** Espanhol Col (Nativo) e Português Br (A1 + 5 meses de experiência de residência no Brasil).

**Vistos:** Visto MERCOSUL Brasil.

**Hobbies:** Astronomia, esportes, escrita, leitura, música e muito mais.

**Pontos fortes e habilidades:** Trabalho em equipe, adaptabilidade, resolução de problemas, persuasão, criatividade e pensamento analítico.

[🔍 My site](https://alexnocua.netlify.app/)

## Informação do meu GitHub

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AlexNocua&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF&theme=dark)

### Tenho conhecimentos em:

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![PHP](https://img.shields.io/badge/PHP-777BB4?style=for-the-badge&logo=php&logoColor=white)
![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![MongoDB](https://img.shields.io/badge/MongoDB-%234ea94b.svg?style=for-the-badge&logo=mongodb&logoColor=white)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-000?style=for-the-badge&logo=postgresql)
![SQLite](https://img.shields.io/badge/SQLite-000?style=for-the-badge&logo=sqlite&logoColor=07405E)

