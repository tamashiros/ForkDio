
# Ailton Alberto

Olá! Eu sou Ailton Desenvolvedor Front-End 👋🏾

## Conecte-se Comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/ailton-alberto/) [![GitHub](https://img.shields.io/badge/GitHbt-000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AiltonAlberto)

## Habilidades

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white) ![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)

## GitHub Stats
![Ailton GitHub Stats](https://github-readme-stats.vercel.app/api?username=AiltonAlberto&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AiltonAlberto&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/AiltonAlberto/dio-lab-open-source)


### Listarei meus Objetivos pois sou apenas um fanático de Jogos que deseja seguir a carreira de Game Designer e Front-End.

#### 1° - Quero fazer jogos incríveis
#### 2° - Para fazer meus Jogos estou apredendo toda estrutura de desenvolvimento mesmo que algumas delas não seja meu ponto forte mas para cumprir meus objetivos, conhecimento nunca é demais
#### 3° - Bootcamps e Cursos para utilizar ferramentas, linguagens e afins estão em meus pontos de foco para conhecimento prático
#### 4° - Exercer colocando conhecimento na prática e conhecer mais considero algo básico, se não fizermos o básico não alcançamos a evolução pessoal e nossa contribuição para o mundo

