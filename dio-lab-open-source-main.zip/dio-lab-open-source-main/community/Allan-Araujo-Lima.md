# Olá, Eu sou Allan Araújo! 👋

👨‍💻 Backend Developer


## 🚀 Sobre Mim
Graduado em ciências contábeis, busco uma mudança de carreira para a área de tecnologia, focado principalmente no segmento de **Backend**.
## 🧠 Conhecimentos

- ![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python&logoColor=ffe060)
- ![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github&logoColor=283344)
- ![HTML](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=e4542d)
- ![CSS](https://img.shields.io/badge/CSS-000?style=for-the-badge&logo=css3&logoColor=316af0)
- ![SQL](https://img.shields.io/badge/SQL-000?style=for-the-badge&logo=postgresql&logoColor=396c94)
- ![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)
## 🔗 Links
- [![instagram](https://img.shields.io/badge/instagram-ff2e79?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/imnot.allan/)
- [![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/allan-araujo-lima)