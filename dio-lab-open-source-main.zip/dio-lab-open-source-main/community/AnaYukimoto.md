# Olá, sou a Ana Eliza Yukimoto 👋

## Sobre Mim:
> Em um momento de minha vida fiz um curso online de Introdução à Linguagem de Programação 👩‍💻, onde descobri uma área em que me encontrei. Hoje sou técnica em Desenvolvimento de Sistemas e estou cursando Tecnológo em Informática para Negócios, onde encontrei a junção de duas áreas em que sou apaixonada 🥰 são elas a de gestão e tecnologia, pois me permitem expressar minha criatividade e me trazem gratificação pelo o que faço. Em resumo, sou uma pessoa otimista 😄, com dedicação e vontade de aprender 💪.


## Contato:
[![LinkedIn](https://img.shields.io/badge/LinkedIn-%230077B5.svg?style=for-the-badge&logo=linkedin&logoColor=white)](https://linkedin.com/in/anaelizayukimoto) [![Codepen](https://img.shields.io/badge/Codepen-000000?style=for-the-badge&logo=codepen&logoColor=white)](https://codepen.io/@AninhaYuki) [![Gmail](https://img.shields.io/badge/Gmail-EB0C0C?style=for-the-badge&logo=Gmail&logoColor=white)](mailto:anaelizayuki@gmail.com) [![Portfolio](https://img.shields.io/badge/Portfolio-E90A63?style=for-the-badge)](https://anayukimoto.github.io/)


## Tecnologias:
![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white) ![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white) ![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=java&logoColor=white) ![PHP](https://img.shields.io/badge/php-%23777BB4.svg?style=for-the-badge&logo=php&logoColor=white) ![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54) ![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E) ![C#](https://img.shields.io/badge/c%23-%23239120.svg?style=for-the-badge&logo=c-sharp&logoColor=white) ![Bootstrap](https://img.shields.io/badge/bootstrap-%23563D7C.svg?style=for-the-badge&logo=bootstrap&logoColor=white) ![MySQL](https://img.shields.io/badge/mysql-%2300f.svg?style=for-the-badge&logo=mysql&logoColor=white) ![Canva](https://img.shields.io/badge/Canva-%2300C4CC.svg?style=for-the-badge&logo=Canva&logoColor=white) ![Git](https://img.shields.io/badge/git-%23F05033.svg?style=for-the-badge&logo=git&logoColor=white)


## GitHub Troféus
![](https://github-profile-trophy.vercel.app/?username=AnaYukimoto&theme=monokai&no-frame=false&no-bg=true&margin-w=4)

