# [Ana Clara Luz](https://www.dio.me/users/anaclarabbcluz)

Sou graduada em Sistemas de Informação pela ESPM e atualmente estou em busca de novas oportunidades de emprego na área de TI, com foco especial em front-end e desenvolvimento web. Tenho uma forte paixão por trabalhar em equipe e estou sempre empenhada em aprender e aprimorar minhas habilidades.

Além do meu interesse profissional, meus hobbies incluem ler livros, ouvir músicas, assistir a filmes e séries, e jogar videogames. Acredito que essas atividades me ajudam a manter a criatividade e o pensamento crítico, essenciais para minha atuação na área de tecnologia.

## Conecte-se comigo

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Ana-Luz)

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/anaclarabustamante/)

## My Stats

<div align="center">
  <a href="https://github.com/Ana-Luz">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=Ana-Luz&show_icons=true&theme=gruvbox&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Ana-Luz&layout=compact&langs_count=7&theme=gruvbox"/>
</div>
