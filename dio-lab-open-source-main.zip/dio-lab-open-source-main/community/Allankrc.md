<link rel="stylesheet" type="text/css" href="./style.css">

<h1 align="center">
  ALLAN KRC 👋
</h1>
<h1>
  About Me 🧑‍💻
</h1>

```javascript
export default {
  name: 'Allan kardek da Rocha Correia Correia',
  from: 'Natal, RN, Brasil',
  profession: 'desempregado',
  email: ['allankrc@gmail.com'],
  linkedin: ['https://www.linkedin.com/in/allan-k-r-correia-80963538/'],
  curriculum:, 'https://allankrc.github.io/MyProfile/',
    contato: '(84) 98627-1371',
  description: {
    myProfile: `Olá! .`,
    myObjective: 'RPA', 'ANALISE DE DADOS', 'VISÃO COMPUTACIONAL' ,'BACKEND'`
  },
  skills: {
    languages: [
      'Python', 'PHP', 'JS'
    ],
    backend: [
      'Node.js', 'Express', 'MySQL', 'MongoDB', 'PHP', 'PYTHON'
    ],
    frontend: [
      'HTML5', 'CSS3', 'Javascript'
    ],
    tools: [
      'GIT', 'Github'
    ],
    designTools: [
      'Canva',
    ],
  },
};
```

<br/>

<h1 align="center">
  Contatos: 👇
</h1>

<section align="center">
  <p
    align="center"
    class="connection-container"
  >
    <a
      href="https://github.com/Allankrc"
      target="_blank"
    >
      <img
        align="center"
        src="https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white"
        alt="github"
      />
    </a>
    <a
      href="https://www.linkedin.com/in/allan-k-r-correia-80963538/" target="_blank"
    >
      <img
        align="center"
        src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white"
        alt="linkedin"
      />
    </a>
    <a
      href="mailto:allankrc@gmail.com"
      target="_blank"
    >
      <img
        align="center"
        src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white"
        alt="email"
      />
    </a>
    <a
      href="mailto:c.kardek@academico.ifrn.edu.br"
      target="_blank"
    >
      <img
        align="center"
        src="https://img.shields.io/badge/Outlook-0078D4?style=for-the-badge&logo=microsoft-outlook&logoColor=white"
        alt="email"
      />
    </a>
    <a
      href="https://wa.me/84986271371"
      target="_blank"
    >
      <img
        align="center"
        src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"
        alt="whatsApp"
      />
    </a>
  </p>
</section>
<br/>
<h1 style="text-align: center;">Technologies and Tools 💡</h1>  <section>  <div class="technologies-container">  <p style="text-align: left;">  <a href="https://www.w3.org/html/" target="_blank">  <img src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white" alt="html5" />  </a>  <a href="https://www.w3schools.com/css/" target="_blank">  <img src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white" alt="css3" />  </a>  <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank">  <img src="https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E" alt="javascript" />  </a>  <a href="https://www.typescriptlang.org/" target="_blank">  <img src="https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript&logoColor=white" alt="typescript" />  </a>  <a href="https://www.python.org/" target="_blank">  <img src="https://img.shields.io/badge/Python-FFD43B?style=for-the-badge&logo=python&logoColor=blue" alt="python" />  </a>  <a href="https://www.mysql.com/" target="_blank">  <img src="https://img.shields.io/badge/MySQL-005C84?style=for-the-badge&logo=mysql&logoColor=white" alt="mysql" />  </a>  <a href="https://www.mongodb.com/docs/" target="_blank">  <img src="https://img.shields.io/badge/MongoDB-4EA94B?style=for-the-badge&logo=mongodb&logoColor=white" alt="mongodb" />  </a>  <a href="https://www.docker.com/" target="_blank">  <img src="https://img.shields.io/badge/Docker-2CA5E0?style=for-the-badge&logo=docker&logoColor=white" alt="docker" />  </a>  <a href="https://www.linux.org/" target="_blank">  <img src="https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black" alt="linux" />  </a>  <a href="https://git-scm.com/" target="_blank">  <img src="https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white" alt="git" />  </a>  <a href="https://github.com/Allankrc" target="_blank">  <img src="https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white" alt="github" />  </a>  </p>  </div>  </section>  <br/>  <h1 style="text-align: center;">Statistics 📈</h1>  <div style="text-align: center;">  <h3>Top Languages</h3>  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=Allankrc&theme=tokyonight&layout=compact" alt="Top Languages">  <h3>GitHub Stats</h3>  <img src="https://github-readme-stats.vercel.app/api?username=Allankrc&show_icons=true&theme=tokyonight" alt="GitHub Stats of Allankrc">  <h3>GitHub Streak</h3>  <img src="https://github-readme-streak-stats.herokuapp.com/?user=Allankrc&theme=tokyonight" alt="Allankrc" >  </div>  
