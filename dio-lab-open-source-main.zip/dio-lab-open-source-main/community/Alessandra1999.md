### Hi there 👋

- 👱‍♀️ My name is Alessandra
- 👩‍🎨 Development student
- 👩‍💻 I’m currently learning Full Stack Development
- 😄 Pronouns: She/Her

 <hr/>
 
<h2 align="center">Technologies</h2>
<div>
<p align="center">
  <a href="https://skillicons.dev">
    <img src="https://skillicons.dev/icons?i=java,js,html,css,mysql,postman,docker,git,github,vscode,eclipse" />
  </a>
</p>
</div>

 <hr/>
 
<div>
  <p align="center">
<a href="https://github.com/Alessandra1999">
<a href="https://github.com/Alessandra1999">
<img loading="lazy" height="180em" src="https://github-readme-stats.vercel.app/api?username=Alessandra1999&theme=dracula&show_icons=true&hide_border=true&count_private=true"/>
<img loading="lazy" height="180em" src="https://github-readme-streak-stats.herokuapp.com/?user=Alessandra1999&theme=dracula&hide_border=true"/>
<img loading="lazy" height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Alessandra1999&theme=dracula&show_icons=true&hide_border=true&layout=compact"/>
</p>
</div>

<hr/>
