<h1 align="center" style="color: #EB9326">Daniel dos Santos Chaves</h1>
<p align="center">Sou conhecido por <b style="color: #EB9326">Chaves</b> e estou cursando Análise e Desenvolvimento de Sistemas no IFRS - Campus Osório</p>

<h2 align="center"> 🔌Conecte-se comigo / Connect with me </h2>

<div align="center">

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/daniel-chaves-63b498240/)
[![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=Github&logoColor=fffff)](https://github.com/0Chaves)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=White)](mailto:danieldossantoschaves@gmail.com)

</div>
<h3 align=center>Sobre mim</h3> 

<p>
🔹Há muito tempo atrás cursei licenciatura em matemática e estive perto da formatura, porém descobri que dar aulas de matemática não era meu desejo.
</p>

<p>
🔹Atualmente estou investindo no mundo da programação pois sempre gostei de solucionar problemas.
</p>

<p>
🔹Despertei um grande interesse pela programação em C e Java, a forma de estruturar o algoritmo detalhadamente e de criar soluções com estas linguagens me fascina.
</p>

<p>
🔹Gosto muito de aprender a origem das coisas, e quase sempre busco compreender "como a roda foi inventada".
</p>

<p>
🔹Tenho uma paixão gigante por games, desde a infância eu aprecio a arte dos games e vejo 'making ofs' para sanar a curiosidade.
A ideia de me tornar um Game Dev passou a gerar um "calorzinho no peito", e desde então passei a focar neste segmento.
</p>

<h3 align=center>About</h3> 

<p>
🔹Long time ago I tried a degree in mathematics and I was close to complete, but I realize that beign Math teacher wasn't my wish.
</p>

<p>
🔹Nowadays I'm giving a shot to the programming world because I always liked to solve problems.
</p>

<p>
🔹I have developed a great interest for programming in C and Java, the way of structuring the alghoritm and creating solutions with these languages fascinates me.
</p>

<p>
🔹I enjoy learning the source of things, and I almost always seek to understand "how the wheel was invented".
</p>

<p>
🔹I have a great passion for games, since my childhood I enjoy games' art and search for making-of videos for curiosity.
The idea of becoming a Game Dev started to get me excited, so I began to focus on that.
</p>

<h2 align="center"> ⚒️ Habilidades / Hardskills</h2>

<h3 align="center"> Linguagens </h3>

<div align="center">

![C](https://img.shields.io/badge/C-00599C?style=for-the-badge&logo=c&logoColor=white)
![C++](https://img.shields.io/badge/C%2B%2B-00599C?style=for-the-badge&logo=c%2B%2B&logoColor=white)
![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
</div>

<h3 align="center">Engines</h3>

<div align="center">

![Unreal Engine](https://img.shields.io/badge/Unreal_Engine-FFF?style=for-the-badge&logo=unrealengine&logoColor=black)
![Godot Engine](https://img.shields.io/badge/godot_Engine-FFF?style=for-the-badge&logo=godotengine&logoColor=blue)
</div>


<h2 align="center"> 📋 Github Stats </h2>

<div align="center">

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=0Chaves&layout=donut&bg_color=353D41&border_color=123547&title_color=EB9326&text_color=FFF&)

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=0Chaves&theme=transparent&bg_color=353D41&border_color=123547&show_icons=true&icon_color=EB9326&title_color=EB9326&text_color=FFF&hide_title=true&hide=stars&rank_icon=github)

<!-- [![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=0Chaves&repo=SEUREPOSITORIO&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/0Chaves/SEUREPOSITORIO) -->
</div>

<h2 align="center"> 📖 Cursos e Bootcamps </h2>

<div align="center">
• Santander Bootcamp 2024
</div>

<h2 align="center"> 📱 Redes sociais / Social media </h2>

<div align="center">

[![Discord](https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white)](https://discord.com/channels/@rhisen/)
[![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/danieel.chavess/)
</div>
<br>
<br>
<br>
<br>


>"Como pode um cara escrever uma coisa que eu não entenda? Não tem como! Eu vou ler aquela m**** até entender!", Clóvis de Barros Filho.
