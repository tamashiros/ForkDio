# Adão Ferreira

<h1>Sejam bem vindos ao meu perfil</h1>

Meu nome é Adão e agora estou estudando tecnologias como C#, MySql,
Cloud Computing e o sistema operacional Linux.

<h1>Conecte-se comigo</h1>
Meu perfil no github: https://github.com/AdaoFerreira

<h1>Habilidades</h1>
<h2>C#</h2>
<img src = "https://growiz.com.br/wp-content/uploads/2020/08/kisspng-c-programming-language-logo-microsoft-visual-stud-atlas-portfolio-5b899192d7c600.1628571115357423548838.png">
<h2>Git<h2>
<img src = "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Git_icon.svg/2048px-Git_icon.svg.png">
<h2>Linux<h2>
<img src = "https://logosmarcas.net/wp-content/uploads/2020/09/Linux-Logo.png">

<h1>Meus projetos<h1>

<h2>Calculadora de IMC</h2>
<a href = "https://github.com/AdaoFerreira/Calculadora_de_IMC">

</h2>Lista de Tarefas</h2>
<a href = "https://github.com/AdaoFerreira/Lista-de-tarefas">
