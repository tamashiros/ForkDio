# In Development...

<h3>👋 Hi, I’m Adelmir Junior (Adelmirjunior) ! <h3/>
  
- 👀 I’m interested in Learning:
  
![PowerShell](https://img.shields.io/badge/PowerShell-%235391FE.svg?style=for-the-badge&logo=powershell&logoColor=white)

![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E)

![MicrosoftSQLServer](https://img.shields.io/badge/Microsoft%20SQL%20Server-CC2927?style=for-the-badge&logo=microsoft%20sql%20server&logoColor=white)

 #
 <h2>  
   Career
  <h2/>
 

- 📫 How to reach me:
