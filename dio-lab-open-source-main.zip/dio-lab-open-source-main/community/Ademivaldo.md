
# Ademivaldo

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/ademivaldo-souza-72a06a22b/)

## Habilidades
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

![React Native](https://img.shields.io/badge/React-Native-000?style=for-the-badge&logo=React-Native)

![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)
## GitHub stats
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Ademivaldo&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Ademivaldo&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Ademivaldo&repo=BKP_Automatico&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Ademivaldo/BKP_Automatico)

## Minhas contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Ademivaldo&repo=ProjetoReact&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Ademivaldo/ProjetoReact)

 

### ----------------------------------------------------


