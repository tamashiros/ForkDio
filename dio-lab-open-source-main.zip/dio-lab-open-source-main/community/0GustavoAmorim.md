### Salve!!! Eu sou o Gustavo Amorim 👋


- 💻 Estagiário de Engenharia de Software na Recovery 
- 💻 Analise e Desenvolvimento de Sistemas | Faculdade Impacta
- 👨‍💻 Técnico em Desenvolvimento de Sistemas na ETEC.
- 👨‍💻 Instituto PROA.

<div align="center">
  <a href="https://github.com/0GustavoAmorim">
  <img align="center" height="180em" src="https://github-readme-stats.vercel.app/api?username=0GustavoAmorim&show_icons=true&theme=tokyonight&include_all_commits=true&count_private=true"/>
  <img align="center" height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=0GustavoAmorim&layout=compact&langs_count=7&theme=tokyonight"/>
</div>
<div align="center" style="display: inline_block"><br>
    <img alt="Gu-Vue" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vuejs/vuejs-original-wordmark.svg" />
    <img alt="Gu-dotnet" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/dotnetcore/dotnetcore-original.svg" />
    <img align="center" alt="Gu-Js" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg">
    <img align="center" alt="Gu-HTML" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg">
    <img align="center" alt="Gu-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
    <img align="center" alt="Gu-PHP" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg">
    <img align="center" alt="Gu-C#"  height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg">
    <img align="center" alt="Gu-Java"  height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg">
    <img align="center" alt="Gu-MySQL"  height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original-wordmark.svg">
    <img align="center" alt="Gu-AndroidStudio"  height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/androidstudio/androidstudio-original.svg">
</div>
