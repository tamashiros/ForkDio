
# Willder Acioly

`Hello world!`

Me chamo Willder, sou estudante de Artes Visuais, tenho 27 anos e adoro tecnologia e arte. No momento tenho me focado em estudar *Java*, acabei gostando muito da linguagem. 
![java](https://hermes.dio.me/articles/cover/7b89fda2-4af3-4ae0-98bc-ad2b65854909.png)


## conecta-se comigo:
[![Gmail](https://img.shields.io/badge/Gmail-660066?style=for-the-badge&logo=gmail&logoColor=black)](mailto:willder20@gmail.com) | [![LinkedIn](https://img.shields.io/badge/LinkedIn-660066?style=for-the-badge&logo=linkedin&logoColor=black)](https://www.linkedin.com/in/willder-acioly-8258b020a/) | [![Discord](https://img.shields.io/badge/Discord-660066?style=for-the-badge&logo=discord&logoColor=black)](https://https://discord.com/channels/vista4597/) 
:--------: | :------: | :-------:

 ## Tecnologias: 

![HTML5](https://img.shields.io/badge/HTML5-660066?style=for-the-badge&logo=html5&logoColor=white) | ![CSS3](https://img.shields.io/badge/CSS3-660066?style=for-the-badge&logo=css3&logoColor=white) | ![JavaScript](https://img.shields.io/badge/JavaScript-660066?style=for-the-badge&logo=javascript&logoColor=white) | ![Java](https://img.shields.io/badge/Java-660066?style=for-the-badge&logo=java)
:--------: | :------: | :-------: | :-------:

## Github Status:
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Acioly2&theme=transparent&bg_color=000&border_color=b366ff&show_icons=true&icon_color=005ce6&title_color=005ce6&text_color=80b3ff)