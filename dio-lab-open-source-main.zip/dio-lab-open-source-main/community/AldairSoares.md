### Olá! Eu sou Aldair Soares!

- 🔭 Desenvolvedor
- 🌱 Estudando Java, Javascript, HTML, CSS, e alguns frameworks
- 😄 Pronouns: ele/dele
- teste

 <div align="space-between">
  <a href="https://github.com/aldairsoares">
  <img height="140em" src="https://github-readme-stats.vercel.app/api?username=aldairsoares&show_icons=true&theme=dracula&include_all_commits=true&count_private=true"/>
  <img height="140em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=aldairsoares&layout=compact&langs_count=7&theme=dracula"/>
</div>
 <div style="display: inline_block"><br>
  <img align="center" alt="Aldair-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Aldair-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Aldair-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Aldair-Java" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original-wordmark.svg">
 </div>

##
  
<div> 
  <a href = "mailto:aldair.soares.as@gmail.com"><img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
   <a href = "mailto:aldair_soares@hotmail.com"><img src="https://img.shields.io/badge/Microsoft_Outlook-0078D4?style=for-the-badge&logo=microsoft-outlook&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/aldair-soares" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>

  
![Snake animation](https://github.com/aldairsoares/aldairsoares/blob/output/github-contribution-grid-snake.svg)
  
</div>
