
# Alan Oliveira R. Santiago
Meu nome é Alan Oliveira Rocha Santiago, sou estudante de Analise e Desenvolvimento de Sistemas e tenho como objetivo uma vaga de estágio para iniciar na área de tecnologia.
## Conecte-se comigo
[![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail)](mailto:alanorsantiago10@gmail.com)  [![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/alanorsantiago/)  [![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Alan-Santiago2004)
## Habilidades
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)  ![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)  	![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)  ![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)  ![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)
## Git Stats
![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=Alan-Santiago2004&theme=dark&show_icons=true)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Alan-Santiago2004&layout=compact&bg_color=151515&border_color=FFF&title_color=6DE287&text_color=9F9F9F)

