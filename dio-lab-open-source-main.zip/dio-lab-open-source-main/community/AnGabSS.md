# Angelo Gabriel Souza Santana

## Formas de contato
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/angelo-gabriel-souza-santana-614118247/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://github.com/AnGabSS)

## 👩‍💻 About me  
<br>
From an early age, I have been an admirer of computers, and I have always liked anything related to IT, from hardware maintenance to software development, which is why I decided to continue in the area, and started my graduation in Systems Analysis and Development, in which I am currently studying the 3rd semester. During my graduation I came into contact with the Java programming language, which I liked more and decided to specialize in it.

<br>

## Principals Skills

![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)
![Kotlin](https://camo.githubusercontent.com/177b36905bdd347c8af85d1a489a8949a4a0bedfb10e0d7b658e14f678b80e6e/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f4b6f746c696e2d4231323545413f7374796c653d666f722d7468652d6261646765266c6f676f3d6b6f746c696e266c6f676f436f6c6f723d7768697465)
![CSharp](https://img.shields.io/badge/C%23-239120?style=for-the-badge&logo=csharp&logoColor=white)
![Android](https://img.shields.io/badge/Android-3DDC84?style=for-the-badge&logo=android&logoColor=white)
![Ubuntu](https://img.shields.io/badge/Ubuntu-E95420?style=for-the-badge&logo=ubuntu&logoColor=white)
![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)
![Spring](https://img.shields.io/badge/Spring-6DB33F?style=for-the-badge&logo=spring&logoColor=white)
![Spring Boot](https://img.shields.io/badge/Spring_Boot-F2F4F9?style=for-the-badge&logo=spring-boot)
![MySQL](https://img.shields.io/badge/mysql-%2300f.svg?style=for-the-badge&logo=mysql&logoColor=white)



![AnGabSS's Stats](https://github-readme-stats.vercel.app/api?username=AnGabSS&theme=dracula&show_icons=true&hide_border=true&count_private=true)
![AnGabSS's Top Languages](https://github-readme-stats.vercel.app/api/top-langs/?username=AnGabSS&theme=dracula&show_icons=true&hide_border=true&layout=compact)