
# Alison Rocha
Olá, sou Alison Rocha. Sou um entusiasta da programação que está formando carreira no mercado de trabalho.

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)]([https://www.dio.me/users/alisonrocha1704](https://www.dio.me/users/alisonrocha1704))
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=fff)]([https://www.linkedin.com/in/SEUUSERNAME/](https://www.linkedin.com/in/devalisonrocha/))




### Habilidades
![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=fff)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=fff)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=fff)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=fff)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://docs.github.com/)



![ ](https://github-readme-stats.vercel.app/api?username=AlisonRochaa&theme=transparent&bg_color=000&border_color=&show_icons=true&icon_color=30A3DC&title_color=fff&text_color=fff&hide_title=true&hide=stars)

