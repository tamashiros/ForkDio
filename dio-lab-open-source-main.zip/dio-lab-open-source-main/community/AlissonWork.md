# Olá, eu sou Alisson dos Santos (AlissonWork) 🌊

**Formação**
- Engenharia de Computação (Graduando) 💻

*Sou iniciante na área de desenvolvimento e busco uma adesão nesse mercado*
