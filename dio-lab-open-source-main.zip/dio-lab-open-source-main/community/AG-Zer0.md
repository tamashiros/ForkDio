
# **Arthur Giovanni Santos Bof**


**English:**

Hello, my name is Arthur. I am 18 years old and I started studying programming a year and a half ago. I am proficient in English, but I am not completely fluent. Sometimes I forget some words, which can make it difficult for me to fully express myself.

My goal is to become a future Data Scientist/Analyst.

**Português:**

Olá meu nomé é Arthur, tenho 18 anos comecei a estudar programação a 1 ano e meio, tenho experiência em avançada em Python, possuo proficiência em inglês, mas não sou completamente fluente. Às vezes, esqueço algumas palavras, o que pode dificultar minha expressão de forma completa.

Minha Meta é me tornar um futuro Cientista/Analista de Dados






## 🛠 Skills / Habilidades 
- ![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
- ![Git](https://img.shields.io/badge/git-%23F05033.svg?style=for-the-badge&logo=git&logoColor=white) 

## 🤝 Soft Skills
- ✅ Knowledge of the 5S Program / Conhecimentos do Programa 5S
- 🎯 Focused / Focado
- 🎓 Easy learning / Fácil aprendizagem
- ⏰ Flexibility / Flexibilidade
- 📚 Self-taught

## 🔗 Links 

[![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AG-Zer0)

[![Gmail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:artiovanni16@gmail.com)

[![Perfil DIO](https://img.shields.io/badge/-Perfil%20DIO-0077B5?style=for-the-badge&logo=gitbook&logoColor=white)](https://www.dio.me/users/arthurgiovanni2021)

[![Instagram](https://img.shields.io/badge/Instagram-%23E4405F.svg?style=for-the-badge&logo=Instagram&logoColor=white)](https://www.instagram.com/4rt_vanni/)