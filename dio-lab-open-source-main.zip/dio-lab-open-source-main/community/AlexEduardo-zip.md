# Alex Eduardo

Meu nome é Alex, sou estudante de Ciência da Computação na Universidade Federal de Minas Gerais, estou no 6° Periodo e busco minha primeira oportunidade de trabalhar como desenvolvedor Back-End.

# Desenvolvimento
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlexEduardo-zip&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

# Usamos muito C e C++ na faculdade

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AlexEduardo-zip&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

# Entre em contato comigo atraves do Linkedin ou Email!

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alex-eduardo-a3b621211/)

# alexeduardoaeas@gmail.com
