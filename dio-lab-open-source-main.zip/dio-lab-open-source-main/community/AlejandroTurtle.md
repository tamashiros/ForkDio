## Olá eu sou o Alejandro 👋

## 🚀 Sobre mim

Sou Alejandro, tenho 23 anos e atualmente trabalho com conteúdo tributário mas sempre fui apaixonado pela area da tecnologia e estou me estudando e me aperfeioando para poder entrar na area e trabalhar com o que sempre quis. 

## Conecte-se comigo
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)](alejandrogomes23@hotmail.com)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-111?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alejandro-gomes)
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https:https://web.dio.me/users/alejandrogomes23?tab=achievements)

## 🛠 Hard Skills
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![Git](https://img.shields.io/badge/git-%23000.svg?style=for-the-badge&logo=git)

![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)

![Postgre SQL](https://img.shields.io/badge/Postgre%20SQL-4fc3f7?style=for-the-badge&logo=postgresql&logoColor=white)

## Frameworks
![Node](https://img.shields.io/badge/Node-111?style=for-the-badge&logo=node.js&logoColor)


[![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=AlejandroTurtle)](https://github.com/AlejandroTurtle/github-readme-stats)
