# Alfradiquejr

## Apresentação

Olá, me chamo Paulo Alfradique, tenho 25 anos e decidi me aventurar nesse meio da tecnologia. Comecei a estudar sobre programação há 2 dias e estou completamente apaixonado e louco ao mesmo tempo!

## Conecte-se comigo
[![DIO](https://img.shields.io/badge/DIO-000?style=for-the-badge&logo=DIO)](https://www.dio.me/users/pauloalfradique98)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)](https://github.com/Alfradiquejr)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/paulo-alfradique-610132293/) 

## Habilidades
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)](https://docs.github.com/)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git)](https://git-scm.com/doc)


## Gihub Stats
[![GitHub Streak](https://streak-stats.demolab.com?user=AlfradiqueJr&theme=aura)](https://git.io/streak-stats)

## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AlfradiqueJr&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/AlfradiqueJr/dio-lab-open-source)