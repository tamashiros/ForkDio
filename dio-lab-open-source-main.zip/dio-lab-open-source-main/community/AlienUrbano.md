# Paulo Gabriel Neves Santos

## Quem sou eu?

**Desenvolvedor Fullstack**, um **apaixonado** por tecnologia e **viciado** em descobrir como as coisas funcionam, melhorar, contribuir e solucionar problemas para que possamos sempre ter deixado algo melhor e *honrar os gigantes do passado nos quais subimos em seus ombros para vermos mais longe.* 

Me dedico a trilhar meu caminho na tecnologia, sempre aprendendo, contribuindo e me realizando como profissional. 

## Estudos:

Curso **A**nálise e **D**esenvolvimento de **S**istemas, assim como cursos livres e profissionais no mercado.

*A maior escola é não se contentar e tentar sempre aprimorar o que aprendeu, com um grande empurrão da curiosidade e da inspiração.*

## Minhas habilidades e aprendizados:

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![TypeScript](https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript&logoColor=white)
![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![Angular](https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white)
![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)
![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)
![Figma](https://img.shields.io/badge/Figma-696969?style=for-the-badge&logo=figma&logoColor=figma)

## Onde me encontrar:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/paulo-gabriel-neves-santos-73b181283/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)](mailto:paulogabrielneves@hotmail.com)
[![Discord](https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white)](https://https://discord.com/channels/@alienurbano/)
