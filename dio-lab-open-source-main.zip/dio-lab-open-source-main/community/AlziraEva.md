<div>
<img src = "https://raw.githubusercontent.com/AlziraEva/AlziraEva/main/gifcat.gif" width = "340" align = "right">
 
###  Olá ! Sou a Eva 🙋‍♀️  
##### Atualmente estou em transição de carreira para a área da programação

- Meu foco no momento é aprofundar meus conhecimentos em desenvolvimento web Full-Stack
- Meus hobbies favoritos são assistir doramas e mergulhar em um bom livro de fantasia

</div>
<br>

### 🌐 Tecnologias e Ferramentas

<br>
<div>
<img align="center" src = "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" 
title="JavaScript" alt="JavaScript" width="50" height="50"/>
<img align="center" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg" 
title="vscode" alt="vscode" width="50" height="50"/>
<img align="center"src= "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-plain-wordmark.svg"
title="Git" alt="Git" width="50" height="50"/>
<img align="center"src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-plain-wordmark.svg"
title="Node" alt="Node" width="50" height="50"/>
<img align="center" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-plain-wordmark.svg" 
title="SQL" alt="SQL" width="50" height="50"/>
 <img align="center" src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/csharp/csharp-original.svg"
 title="C#" alt="SQL" width="50" height="50"/>  
 </div>
 <br>

### ☎ Contatos

<br>
<div>

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AlziraEva)
<a href = "mailto:contato@alziralves1996@gmail.com"><img loading="lazy" src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
<a href="https://www.linkedin.com/in/alzira-eva-cavalcanti-alves-a62b97135/" target="_blank"><img loading="lazy" src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>

</div>
<br>
 
### 📊 Estatísticas  
<br>

<a href="https://github.com/AlziraEva">
  <img height=170 align="left" src="https://github-readme-stats.vercel.app/api?username=AlziraEva&show_icons=true&theme=radical" />
</a>
<a href="https://github.com/AlziraEva">
  <img height=150 align="right" src="https://github-readme-stats.vercel.app/api/top-langs?username=AlziraEva&layout=compact&langs_count=8&card_width=320&theme=radical" />
</a>
