
# Gregory Valentim

Oi, sou Gregory, sou de Santos-SP, desenvolvedor de jogos, caso queira experimentar alguns de meus jogos pode entrar no meu [Gamejolt](https://gamejolt.com/@Akapaya/games) e no meu [Itch.io](https://akapaya.itch.io).


## 🔗 Conecte-se comigo
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/gregory-valentim/)

