<div>
    <h1>Olá, eu sou Aécio !</h1>
    <p>Atualmente curso licenciatura em computação na UFRPE e trabalho na empresa júnior Seed a bit.</p>
    <p>Acredito que posso mudar o mundo com a tecnologia e com o pensamento crítico!</p>
</div>
<div>
    <h2>Conecte-se comigo</h2>

[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://www.discord.com/users/329619852065243137)


</div>

<div>
    <h2>Linguagens de programação</h2>

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

</div>