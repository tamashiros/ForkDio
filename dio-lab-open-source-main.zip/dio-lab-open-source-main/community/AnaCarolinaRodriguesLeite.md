# Ana Carolina

💼 Estagiária de Desenvolvimento de software na Vetta S.A há quase 2 anos e quase Engenharia de Software pela Unb.

👨‍🎓 Tenho experiências profissionais(Todas em estágios por conta da graduação), tendo tido contato com diversas linguagens de programação e tecnologias, como: JavaScript, TypeScript, Angular, Ionic, HTML, CSS, Bootstrap, Java, C, Python, Pascal, Postgree, Mysql.....
Estou a procura de novas oportunidades na área de backend, no qual possa aumentar os conhecimentos em Java, Python e incluir C# e seus frameworks na lista. Em princial, poder ter experiências na área de dados está sendo uma busca e aprendizado constante.

🛰 Sempre tive a curiosidade por diversas áreas da tecnologia, como o processo de construção do software como um todo desde a concepção a fase de planejamento até o desenvolvimento, teste e entrega, conseguindo ter o espetro do produto como um todo no processo.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/ana-carolina-rodrigues-495a61160/)

[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:anacarolinarodrigues480@gmail.com)

## Git Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AnaCarolinaRodriguesLeite&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AnaCarolinaRodriguesLeite&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
