# AlexandreWChantal
## Sobre mim
Sou Alexandre Wandenkolk de Chantal, formado em Ciência da Computação e Pós-Graduado em Ciência de Dados e Big Data
## Habilidades
![PLS/SQL](https://img.shields.io/badge/PL/SQL-blue?style=for-the-badge)
![Tableau](https://img.shields.io/badge/Tableau-orange?style=for-the-badge)
![Python](https://img.shields.io/badge/Python-gray?style=for-the-badge)
![Analise de dados](https://img.shields.io/badge/Analise%20de%20dados-green?style=for-the-badge)
![Data WareHouse](https://img.shields.io/badge/Data%20Warehouse-brown?style=for-the-badge)
![Business Intelligence](https://img.shields.io/badge/Business%20Intelligence-black?style=for-the-badge)
## Conecte-se comigo
[![Gmal](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](alexandrewchantal@gmail.com)
