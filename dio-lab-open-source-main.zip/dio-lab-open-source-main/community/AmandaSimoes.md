# Olá mundo! Eu sou a Amanda Simões! 👋 

🎓 Designer em Transição de Carreira

🎓Cursando Análise e Desenvolvimento de Softwares 

👩‍💻 Busco minha primeira vaga em tecnologia


### Sobre mim

Sou designer há 10 anos e atuei em diversos setores. Sou apaixonada por aprender e estou estudando tecnologia desde o início de 2022 afim de fazer minha transição de carreira para a área. Sou movida a desafios e gosto de trabalhar na resolução de problemas.


Para me divertir eu gosto de estar em contato com a naturaza, exercitar o corpo, conhecer novos lugares e estar em contato com pessoas queridas.


### Habilidades
![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=30A3DC)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=E94D5F)
![Bootstrap](https://img.shields.io/badge/bootstrap-%238511FA.svg?style=for-the-badge&logo=bootstrap&logoColor=white)
![SASS](https://img.shields.io/badge/SASS-hotpink.svg?style=for-the-badge&logo=SASS&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=30A3DC)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
![React](https://img.shields.io/badge/react-%2320232a.svg?style=for-the-badge&logo=react&logoColor=%2361DAFB)
![Angular](https://img.shields.io/badge/angular-%23DD0031.svg?style=for-the-badge&logo=angular&logoColor=white)

### Conecte-se Comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/amanda_assimoes?tab=skills)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:amandasimoesdev@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/amanda-assimoes/)

