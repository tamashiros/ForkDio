
Meu nome é Anallyssa, sou do Distrito Federal. Atualmente estou cursando tecnólogo em banco de dados.

