# Olá, me chamo Alexandre (Alexandre-Paiva)👍
    Estudante de Ti na área de banco de dados pela Universidade Estácio de Sá.  
    Porém ainda sem experiência estou buscando conhecimento através de cursos e pequenos projetos.


![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alexandre-Paiva&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Alexandre-Paiva&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alexandre-paiva-60845229b/)
