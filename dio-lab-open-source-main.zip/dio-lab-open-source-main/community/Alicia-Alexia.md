## Olá, sou Alícia! 👩🏻‍💻   
<picture>
 <img alt="Gif" src="https://media.giphy.com/media/WIQ0N0OUvei1OW1h9Z/giphy.gif">
</picture>

Me chamo Alícia sou formada em Sistemas de Informação pela faculdade Unifametro. 

 🔹 Tenho grande interesse na área de desenvolvimento, análise de dados, IA. 📊
 
🔹 Estou construindo meu caminho na tecnologia através da criatividade, comunicação, pró-atividade e muita vontade de aprender!

## 📲 Conecte-se comigo
[![Linkedin](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alicia-alexia-554a2a1b0/)

[![GitHub Streak](https://streak-stats.demolab.com/?user=alicia-alexia&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

## ⚒️ Habilidades 
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![TypeScript](https://img.shields.io/badge/TypeScript-000?style=for-the-badge&logo=typescript)
![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git)
![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=alicia-alexia&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
## 📚 Idiomas
- Inglês intermediário 
- Espanhol básico
