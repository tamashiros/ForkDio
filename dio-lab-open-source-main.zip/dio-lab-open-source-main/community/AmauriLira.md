
**Olá pessoal🙋🏻‍♂️! Sou Amauri Lira, e estou Estudando de Análise e desenvolvimento de sistemas**

Faculdade Anhembi Morumbi.


![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AmauriLira&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF) 


![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AmauriLira&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF) 

Conecte-se Comigo:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=fff)](https://www.linkedin.com/in/amauri-lira-663966272/)





