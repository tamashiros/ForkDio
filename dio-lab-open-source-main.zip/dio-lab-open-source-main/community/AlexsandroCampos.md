# Alexsandro
<div>
  <a href="https://github.com/AlexsandroCampos">
  <img height="167em" src="https://github-readme-stats.vercel.app/api?username=AlexsandroCampos&show_icons=true&theme=dracula&include_all_commits=true&count_private=true"/>
  <img height="167em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=AlexsandroCampos&layout=compact&langs_count=7&theme=dracula"/>
</div>
  
 <div style="display: inline_block"><br>
   <img align="center" alt="Alexsandro-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Alexsandro-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Alexsandro-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
   <img align="center" alt="Alexsandro-Java" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg">
   <img align="center" alt="Alexsandro-CSharp" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/csharp/csharp-original.svg">
  <img align="center" alt="Alexsandro-Spring" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/spring/spring-original-wordmark.svg">
   <img align="center" alt="Alexsandro-DotNet" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/dot-net/dot-net-original-wordmark.svg">
   <img align="center" alt="Alexsandro-Angular" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/angular/angular-original.svg">
</div>
  
## Conecte-se comigo
 
<div>
  <a href="https://www.linkedin.com/in/alexsandro-de-souza-campos-133355231" target="_blank"><img src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
</div>
  
  
