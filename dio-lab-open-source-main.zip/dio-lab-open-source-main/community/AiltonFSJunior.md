
# 🦝 Ailton Ferreira dos Santos Junior

## Meu Perfil para o desafio de Projeto de Contribuição Open-Source pelo Github

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/ailtonfsjuniordev/)[![GitHub](https://img.shields.io/badge/GitHbt-000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AiltonFSJunior)

### Listarei meus Objetivos pois sou apenas um fanático de Jogos que deseja seguir a carreira de Game Designer

#### 1° - Quero fazer jogos incríveis
#### 2° - Para fazer meus Jogos estou apredendo toda estrutura de desenvolvimento mesmo que algumas delas não seja meu ponto forte mas para cumprir meus objetivos, conhecimento nunca é demais
#### 3° - Bootcamps e Cursos para utilizar ferramentas, linguagens e afins estão em meus pontos de foco para conhecimento prático
#### 4° - Exercer colocando conhecimento na prática e conhecer mais considero algo básico, se não fizermos o básico não alcançamos a evolução pessoal e nossa contribuição para o mundo

