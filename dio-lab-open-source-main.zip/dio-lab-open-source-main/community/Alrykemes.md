### Oi, eu sou o Alrykemes Cavalcanti

<div>
<a href="https://github.com/Alrykemes">
<img height="180em" src="https://github-readme-stats.vercel.app/api?username=alrykemes&count_private=true&show_icons=true&theme=dark">
</div>

<div style="display: inline_block"><br>
  
### Tecnologias Dominadas

  <br>
  <img align="center" alt="Kemes-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
   <img align="center" alt="Kemes-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Kemes-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Kemes-React" height="30" width="40" src="https://raw.githubusercontent.com/file-icons/DevOpicons/master/svg/react.svg">
  <img align="center" alt="Kemes-Java" height="30" width="40" src="https://raw.githubusercontent.com/file-icons/DevOpicons/master/svg/java.svg">
  <img align="center" alt="Kemes-MySql" height="30" width="40" src="https://raw.githubusercontent.com/file-icons/DevOpicons/master/svg/mysql.svg">
  <img align="center" alt="Kemes-Git" height="30" width="40" src="https://raw.githubusercontent.com/file-icons/DevOpicons/master/svg/git.svg">
  
</div>

##

<div> 
  <a href="https://www.instagram.com/alrykemes/" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href = "mailto:alrykemesgc@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/alrykemes-cavalcanti-ab937a267" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
</div>