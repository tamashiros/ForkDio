# Anaazv1272

## Sobre
Oie, sou Ana Beatriz de Azevedo Rodrigues, tenho 22 anos e curso Ciências Matemáticas e da Terra na Universidade Federal do Rio de Janeiro (UFRJ). Atualmente estou buscando minha primeira vaga de estágio na área de Dados. Realizei diversos cursos online voltados para a área e sou formada em inglês pelo CCAA.
## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/ana-beatriz-de-azevedo-rodrigues-054062144/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Anaazv1272)
[![Gmail](https://img.shields.io/badge/Gmail-000?style=for-the-badge&logo=gmail&logoColor=white)](mailto:anaazv100@gmail.com)

## Habilidades e ferramentas
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white)

## Linguas
![Inglês](https://img.shields.io/badge/Inglês-Avançado-000?style=for-the-badge=linkedin&logoColor=white)
![Espanhol](https://img.shields.io/badge/Espanhol-Intermadiário-000?style=for-the-badge=linkedin&logoColor=white)
![LIBRAS](https://img.shields.io/badge/LIBRAS-Iniciante-000?style=for-the-badge=linkedin&logoColor=white)

## GitHub stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Anaazv1272&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Anaazv1272&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Anaazv1272&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Anaazv1272/dio-lab-open-source)