# Alyson Ronnan Martins

### Wellcome

**I'm Alyson Ronnan Martins 🤓**, I'm currently looking for my job as a developer, dedicating myself to FrontEnd development.
I also have experience with web and desktop development. 

I'm currently studying with **ReactJS** to make web applications and desktop applications using **ElectronJS**.

[![AlysonDEVCode](https://github-readme-stats.vercel.app/api/top-langs/?username=AlysonDEV&hide=html&layout=compact&theme=dracula)](https://github.com/anuraghazra/github-readme-stats)

**I'm also on networks:**

[![Instagram Badge](https://img.shields.io/badge/-Instagram-3e3e9f?style=flat-square&labelColor=363636&logo=instagram&logoColor=white&link=https://www.instagram.com/alysonronnan/)](https://www.instagram.com/alysonronnan/)
[![Linkedin Badge](https://img.shields.io/badge/-Linkedin-3e3e9f?style=flat-square&labelColor=363636&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/alyson-ronnan-martins/)](https://www.linkedin.com/in/alyson-ronnan-martins/) 
[![Static Badge](https://img.shields.io/badge/DIO-alysonronnan-363636?labelColor=363636&color=3e3e9f)](https://web.dio.me/users/alysonronnan)
[![E-mail](https://img.shields.io/badge/-Gmail-3e3e9f?style=flat-square&labelColor=363636&logo=gmail&logoColor=white&link=mailto:alysonronnan@gmail.com)](mailto:alysonronnan@gmail.com)

**But, I also used it in projects:**

Languages:

![ReactJS](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)
![TypeScript](https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![SASS](https://img.shields.io/badge/Sass-CC6699?style=for-the-badge&logo=sass&logoColor=white)
![StyledComponents](https://img.shields.io/badge/styled--components-DB7093?style=for-the-badge&logo=styled-components&logoColor=white)
![Tailwind](https://img.shields.io/badge/Tailwind_CSS-38B2AC?style=for-the-badge&logo=tailwind-css&logoColor=white)
![PHP](https://img.shields.io/badge/PHP-777BB4?style=for-the-badge&logo=php&logoColor=white)
![Electron.js](https://img.shields.io/badge/Electron-191970?style=for-the-badge&logo=Electron&logoColor=white)
![Python](https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white)
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)

Designe: 

![Figma](https://img.shields.io/badge/figma-%23F24E1E.svg?style=for-the-badge&logo=figma&logoColor=white)
![Adobe Photoshop](https://img.shields.io/badge/adobe%20photoshop-%2331A8FF.svg?style=for-the-badge&logo=adobe%20photoshop&logoColor=white)

DBMS: 

![Mysql](https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white)
![Postgreesql](https://img.shields.io/badge/PostgreSQL-316192?style=for-the-badge&logo=postgresql&logoColor=white)
![Firebase](https://img.shields.io/badge/Firebase-F29D0C?style=for-the-badge&logo=firebase&logoColor=white)

Others:

![Wordpress](https://img.shields.io/badge/WordPress-006E93?style=for-the-badge&logo=wordpress&logoColor=white)
![Excel](https://img.shields.io/badge/Microsoft_Excel-217346?style=for-the-badge&logo=microsoft-excel&logoColor=white)
![Access](https://img.shields.io/badge/Microsoft_Access-A4373A?style=for-the-badge&logo=microsoft-access&logoColor=white)
![Linux](https://img.shields.io/badge/Linux-E34F26?style=for-the-badge&logo=linux&logoColor=black)

I also worked with **VBA**, **VB6**, **PHP**, **MySQL** and others. I enjoy creating solutions to real problems, writing clean code and applying best practices.

Today I am prepared for daily learning and also to show the knowledge gained in my career. 🖤



<details>
  <summary><b>Github Stats</b></summary>
  
  [![AlysonDEVCode](https://github-readme-stats.vercel.app/api?username=AlysonDEV&theme=dracula)](https://github.com/anuraghazra/github-readme-stats)
  
</details>
<!---
Objetivo: Quero mudar miha vida!
--->
