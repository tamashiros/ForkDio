

# Abiguelini 
## Sobre mim

Oi! Sou Álvaro Biguelini, formado em gastronomia e atualmente estudando análise e desenvolvimento de sistemas. Sou aluno do programa Santander 2024 - Backend com Java, e estou em transição de carreira para a área de TI.

## Contato

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=border_radius&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alvaro-biguelini/)

[![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?styleborder_radius&logo=instagram&logoColor=white)](https://www.instagram.com/alvarobiguelini/)

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=border_radius&logo=github&logoColor=white)](https://github.com/Abiguelini/)

## Habilidades
![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=border_radius&logo=openjdk&logoColor=white)

![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=border_radius&logo=javascript&logoColor=black)

![Spring](https://img.shields.io/badge/spring-%236DB33F.svg?style=border_radius&logo=spring&logoColor=white)



![Ionic](https://img.shields.io/badge/Ionic-%233880FF.svg?style=border_radius&logo=Ionic&logoColor=white)
