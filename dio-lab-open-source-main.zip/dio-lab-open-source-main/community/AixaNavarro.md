[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&weight=900&size=30&pause=1000&color=4AF7D8&random=false&width=435&lines=Aixa+Navarro)](https://git.io/typing-svg)



# 🚀Seja muito bem vindo ao meu perfil!

Sou bióloga e atualmente estou em processo de transição de carreira para a área de tecnologia. 
## Conecte-se comigo 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=E94D5F)](https://github.com/AixaNavarro)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-FFF?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/aixanavarrog/) 
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/aixanavarro11/) 

### Em desenvolvimento
![LoadingGifGIF](https://github.com/digitalinnovationone/dio-lab-open-source/assets/123226012/5e625d4c-f5e7-4d33-bfa5-5bc8aee88f7d)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=30A3DC)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)
![Python](https://img.shields.io/badge/python-000?style=for-the-badge&logo=python&logoColor=ffdd54)


### Github stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AixaNavarro&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

