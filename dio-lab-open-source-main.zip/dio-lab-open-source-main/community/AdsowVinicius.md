[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=FF0&size=30&center=true&vCenter=true&width=1000&lines=Oi,+meu+nome+é+Adsow+Vinicius.;Sou+de+Pindamonhangaba(sim+não+é+só+uma+piada+do+Raul+Gil+rsrsrs),+SP.;Seja+bem-vindo(a)!+:%29)](https://git.io/typing-svg)
 
![Adsow Vinicius GitHub stats](https://github-readme-stats.vercel.app/api?username=AdsowVinicius&show_icons=true&theme=dark)
[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=AdsowVinicius&theme=dark)](https://github.com/AdsowVinicius/github-readme-stats)

##

<div> 
  <a href="https://www.linkedin.com/in/adsow-vinicius-463a02208/" target="_blank"><img src="https://img.shields.io/badge/Adsow Vinicius-0077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
  <a href="https://www.instagram.com/adsowvinicius/" target="_blank"><img src="https://img.shields.io/badge/-Adsow Vinicius-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href = "mailto:adsow007@gmail.com"><img src="https://img.shields.io/badge/-adsow007@gmail.com-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  
</div>

### Skills:

<div style="display: inline_block">
  <img align="center" alt="JAVA" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg">
  <img align="center" alt="SprigBoot" height="30" width="" src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/spring/spring-original.svg">
  <img align="center" alt="Python" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg">
  <img align="center" alt="SQL" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/postgresql/postgresql-original-wordmark.svg">
  <img align="center" alt="FASTAPI" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/fastapi/fastapi-plain.svg">
    <img align="center" alt="REACT" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/react/react-original-wordmark.svg">
  <img align="center" alt="AWS" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/amazonwebservices/amazonwebservices-original-wordmark.svg">
</div>
  


### Ferramentas:

![Visual Studio Code](https://img.shields.io/badge/-Visual%20Studio%20Code-0D1117?style=for-the-badge&logo=visual-studio-code&logoColor=007ACC&labelColor=0D1117)&nbsp;
![GitHub](https://img.shields.io/badge/-GitHub-0D1117?style=for-the-badge&logo=github&labelColor=0D1117)&nbsp;
![Git](https://img.shields.io/badge/-Git-0D1117?style=for-the-badge&logo=git&labelColor=0D1117)&nbsp;
![Docker](https://img.shields.io/badge/-Docker-0D1117?style=for-the-badge&logo=docker&labelColor=0D1117)&nbsp;
![KUBERNETES](https://img.shields.io/badge/-KUBERNETES-0D1117?style=for-the-badge&logo=KUBERNETES&labelColor=0D1117)&nbsp;
![Linux](https://img.shields.io/badge/-Linux-0D1117?style=for-the-badge&logo=linux&labelColor=0D1117)&nbsp;