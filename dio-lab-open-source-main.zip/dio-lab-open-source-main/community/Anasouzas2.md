# Buenas!😎 Eu sou a Ana 😊 Seja muito bem-vindo(a)!

## 👧🏽 Sobre mim

#### Tenho 23 anos e atualmente estou conciliando meu trabalho como instrutora de treinamento e o curso superior em Análise e Desenvolvimento de Sistemas, desbravando o ramo da tecnología com foco em Front-end que me interessa tanto.

#### Sou autodidata e amo aprender coisas novas! Amante de vinho, música, idiomas, natureza e extremamente apaixonada pelos meus filhos pets: Zoe 🐶 e Zeus 😺!
----
## 💬 Idiomas
| Idioma | Proficiência|
|-----:|---------------|
|     Espanhol| Fluente     |
|     Inglês| Intermediário |
|     Português| Nativo      |

## 👥 Conecte-se comigo 
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/dev.anas2/)



