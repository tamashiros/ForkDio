# Aisla Cristina Silva

Olá para todos!
Me chamo Aisla Cristina, já sou formada em Pedagogia (Licenciatura), mas atualmente estou cursando Analise e Desenvolvimento de Sistemas.

Ainda não trabalho na area de TI, mas espero que em breve eu tenha essa oportunidade.

Além da faculdade, estou buscando construir conhecimento em programação com a plataforma DevClub e pela DIO.

## Contato

[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)](mailto:aisla.cris@hotmail.com)

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/aisla-cristina-silva-746a61218/)

[![WhatsApp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/5511985944377)

## Linguagens de Marcação e Estilo

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)

## Ferramentas

![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)



