![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=3ateusferrari&theme=moltack&show_icons=true)

[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=3ateusferrari&layout=compact&theme=moltack&show_icons=true)](https://github.com/3ateusferrari/github-readme-stats)

</div>
<div style="display: inline_block"><br>
  <img align="center" alt="Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Python" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" />
  <img align="center" alt="Python" height="30" width="40" src="https://cdn-icons-png.flaticon.com/512/1216/1216733.png" />
      
 ## Pra me conhecer melhor, me siga nas rede sociais!!
  
 <div> 
  <a href="https://instagram.com/mateusferrariii" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
  <a href = "mailto:mateusspier@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="www.linkedin.com/in/3ateus-ferrari" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
 
