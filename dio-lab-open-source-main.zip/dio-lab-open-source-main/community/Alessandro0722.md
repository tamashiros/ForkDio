# Alessandro Lobato Abranches
## Programador em formação
### Objetivo Geral: me tornar especialista na linguagem Python de programação. 
### Objetivo Específico: Aprender a utlizar integração entre Python e Power BI para análise de Dados.


## Cursos de Linguagem Python Realizados :
### Aquele basicão de Python (Potencia Tech)
### Data Analitycs com Python (Alura)
### Curso de Python (Curso em Vídeo)


## Outras linguagens cursadas:
### HTML (Alura)
### CSS (Alura)
### Javascript (Alura)
### Java (Alura)
### MySQL (Alura)

