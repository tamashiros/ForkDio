# Alan Cruz de Figueiredo

## Habilidades
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![Python](https://img.shields.io/badge/PYTHON-000?style=for-the-badge&logo=python&logoColor=)
![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E) 
![Git](https://img.shields.io/badge/git-000?style=for-the-badge&logo=git&logoColor=white) 
![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)

## Github Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alan-Figueiredo&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF&&hide_title=True)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Alan-Figueiredo&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF&&hide_title=True)
