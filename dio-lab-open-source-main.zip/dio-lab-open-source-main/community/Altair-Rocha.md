## Altair-Rocha
Olá eu sou o Altair e estou aperfeiçoando meus conhecimentos em Git e GitHub com a Elidiana através da DIO.

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/altairrocha2005/)
## Conecte-se comigo 
[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/https://github.com/Altair-Rocha)

## Habilidades
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Altair-Rocha&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Altair-Rocha&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

