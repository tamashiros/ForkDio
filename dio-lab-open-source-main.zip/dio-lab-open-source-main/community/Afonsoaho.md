# 👋 Olá, pode de chamar de Afonso!
Sou formado em Análise e Desenvolvimento de Sistemas, apaixonado por computadores. Estou me dedicando ao estudo de ferramentas de desenvolvimento.

##
### 📊 Estatísticas no GitHub:
<a href="https://github.com/Afonsoaho">
  <img height=200 align="center" src="https://github-readme-stats.vercel.app/api?username=Afonsoaho&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF" />
</a>

##
### 👨‍💻 Estudando atualmente: 🛠

<div style="display: inline_block"><br/>
<img aLign="center" alt="HTML 5" src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white" />
<img aLign="center" alt="CSS" src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white" />
<img aLign="center" alt="Java" src="https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white" />


</div>


##
### 📲 Você pode me encontrar em:

[![LinkedIn](https://img.shields.io/badge/linkedin-%230077B5.svg?style=for-the-badge&logo=linkedin&logoColor=white)](https://br.linkedin.com/in/afonsoaho)
