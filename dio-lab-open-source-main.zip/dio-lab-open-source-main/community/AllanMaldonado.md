# Allan Maldonado
<img  align="center" src="https://media.licdn.com/dms/image/D4D16AQF-ELKvH63RIA/profile-displaybackgroundimage-shrink_350_1400/0/1698065565408?e=1719446400&v=beta&t=xPBnVIxVobmb7dCIx8tZmjfItI6RoBEdKjwEkz0M_E8">


## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AllanMaldonado&theme=transparent&bg_color=000&border_color=814942&show_icons=true&icon_color=814942&title_color=903f39&text_color=fff&hide=issues)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AllanMaldonado&layout=compact&bg_color=000&border_color=814942&title_color=814942&text_color=FFF)

## Skills

<div style="display: inline_block"><br>
  <img align="center" alt="Allan-Js" height="40" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Allan-Java" height="45" width="45" src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/java/java-original.svg">
  <img align="center" alt="Allan-C" height="40" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/cplusplus/cplusplus-original.svg" >
  <img align="center" alt="Allan-HTML" height="40" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Allan-CSS" height="40" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">

</div>

## Links

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/allanmaldonado/)[![Instagram](https://img.shields.io/badge/-Instagram-000?style=for-the-badge&logo=instagram&logoColor=E1306C)](https://www.instagram.com/allanmalldonado/)[![CodePen](https://img.shields.io/badge/Codepen-000000?style=for-the-badge&logo=codepen&logoColor=white)](https://codepen.io/AllanMaldonado)

<hr>
