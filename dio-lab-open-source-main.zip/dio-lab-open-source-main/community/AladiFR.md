# 🙋🏽‍♂️Olá! Bem vindos ao meu perfil do Github 
## Me chamo Matheus Luiz e meu nick é "AladiFR"


- 🔍 Atualmente aprendendo:

 ![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black) ![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white) ![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)

 - 📱 Meus contatos:

 [![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/matheus-luiz-4070852a2/)
 [![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/theus_lr/) [![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AladiFR) [![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:matheuslr2@gmail.com)

 - 🛠 Ferramentas que eu utilízo: 

 ![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white) ![Figma](https://img.shields.io/badge/Figma-696969?style=for-the-badge&logo=figma&logoColor=figma) ![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)

## Linguágens que tenho mais afinidade

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AladiFR&layout=compact&bg_color=2F3542&border_color=000&title_color=1DD1A1&text_color=FFF)

## Meus repositórios públicos
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AladiFR&repo=AladiFR.github.io&bg_color=2F3542&border_color=000&show_icons=true&icon_color=82589F&title_color=1DD1A1&text_color=FFF)](https://github.com/AladiFR/AladiFR.github.io) [![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AladiFR&repo=Project-Second&bg_color=2F3542&border_color=000&show_icons=true&icon_color=82589F&title_color=1DD1A1&text_color=FFF)](https://github.com/AladiFR/Project-Second)

## Meus "Stats" no Github

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AladiFR&theme=transparent&bg_color=2F3542&border_color=000&show_icons=true&icon_color=82589F&title_color=1DD1A1&text_color=FFF)

### Além de portguês também falo francês!
