
# - 👋 Olá, eu sou o Italo!

- Sou um novato, gosto de programar e estou aprendendo muito na área. Tenho bastante interesse em back-and. 

## Conecte-se Comigo
[![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=Github&logoColor=0E76A8)](https://github.com/Akurejs/) 


## Habilidades
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)


## Github Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Akurejs&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=fff&text_color=FFF&hide_title=true)

[![GitHub Streak](https://streak-stats.demolab.com/?user=Akurejs&theme=bear&background=000&border=30A3DC&dates=FFF)](https://github.com/Akurejs)
