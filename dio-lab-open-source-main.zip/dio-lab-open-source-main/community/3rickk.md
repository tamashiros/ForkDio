# EUUU | 3rickk

Meu nome é Pedro Erick e sou acostumado com computadores desde pequeno, usava para jogar e etc. até que me surgiu uma curiosidade de como sites, games e tudo dentro da internet é feito, mas vi que era muito mais dificil do que parecia massss, chegou a fase em que tenho que decidir o que vou ser da vida e vi o mercado de programação desde então estou fazendo faculdade de analise desenvolvimento de software na UNP-Mossoró e busco aprender mais e mais pois é um assunto que me interesso muito!!
![Logo](https://cdn.sologo.ai/temp24h/logopreview/2568f767-c20a-4a87-980c-6a7eb561047d.svg)

