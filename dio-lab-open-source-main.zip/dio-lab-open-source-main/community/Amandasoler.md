# Amanda Soler


Olá! 

Sou Amanda, tenho 35 anos e mãe solo de um adolescente e uma bebê. ❤
Sou deficiente auditiva unilateral, apaixonada por tecnologia e com uma trajetória profissional nada linear, sempre me vi voltada para a área de humanas. Com espírito empreendedor e experiência em diferentes áreas de negócio, amo ajudar as pessoas e solucionar problemas de forma prática e criativa. 
Há pouco mais de um ano, resolvi criar coragem e "mergulhar de cabeça" nesse processo de aprendizado tão desafiador e empolgante da tecnologia. Atualmente estou cursando bacharelado em Inteligência Artificial e entusiasmada com a possibilidade de contribuir com projetos inovadores.


## Conecte-se comigo

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://www.dio.me/users/soler_amanda)[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/amanda-soller/)[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:soler.amanda@gmail.com)

## Linguagem
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)

## Desenvolvendo Habilidades
- Microsoft Power BI
- Python para Data Analytcs
- SQL

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Amandasoler&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
