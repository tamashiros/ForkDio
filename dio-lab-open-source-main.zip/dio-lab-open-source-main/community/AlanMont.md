
# Olá eu sou o Alan. 


Aqui temos algumas coisas sobre mim
___
- 👨🏽‍🎓 Formado em Análise e desenvolvimento de sistemas pela FATEC - Praia Grande
- 👨🏽‍💻 Trabalho atualmente como Desenvolvedor Pleno ServiceNow em uma Multinacional
- 🎮 Tenho como paixões Jogos, Mangás e Piadas Ruins
___

## Aluno do bootcamp Santander 2024 - Criando Jogos com Godot
![megaman](https://user-images.githubusercontent.com/210965/90380868-888d2100-e074-11ea-8f1f-2920212eb45c.gif) ![mario](https://media.tenor.com/UkvleU1dQK4AAAAi/2d-mario-running.gif) ![mew2](https://media.tenor.com/iGSsICUR-2oAAAAj/mewtwo-sprite.gif)![sonic](https://media.tenor.com/exeG8bsKjv4AAAAj/sonic.gif).
___
### 🖥 Habilidades
 ![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)  ![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)  ![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)  ![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)  ![TypeScript](https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript&logoColor=white)  ![Angular](https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white) 

___


#### ✉ Vamos manter contato!

 [![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alan-monteiro-7408751a3/)  [![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AlanMont)   [![LinkedIn](https://img.shields.io/badge/Behance-1769ff?style=for-the-badge&logo=behance&logoColor=white)](https://www.behance.net/AlanMont)






