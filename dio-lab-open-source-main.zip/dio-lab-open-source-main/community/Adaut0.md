# Adaut0

## **Conecte-se comigo**
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/adauto-valentim-a2847b2b9/)

## **Habilidades**
![Git](https://img.shields.io/badge/Git-777BB4?style=for-the-badge&logo=git&logoColor=white)
![Github](https://img.shields.io/badge/Github-777BB4?style=for-the-badge&logo=github&logoColor=white)

## **Github Stats**
[![GitHub Streak](https://streak-stats.demolab.com/?user=Adaut0&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)