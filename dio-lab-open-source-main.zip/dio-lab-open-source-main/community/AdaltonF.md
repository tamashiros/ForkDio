# Adalton Filho

### Sobre mim
Moro em São Carlos-SP e sou estudante de Ciências de Computação no ICMC-USP, estou no meu 3º ano do curso. 

## Redes Sociais
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/adaltonf_/) [![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/adalton-sena-filho/) [![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://www.discord.com/in/adaltonf/)

## Habilidades
Já tive contato com as seguintes linguagens de programação, ao longo de projetos pessoais e trabalhos da faculdade.

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) ![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c) ![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C) ![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java) ![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript) ![Godot](https://img.shields.io/badge/Godot-000?style=for-the-badge&logo=godotengine)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AdaltonF&repo=Snake-Game-Godot&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/AdaltonF/Snake-Game-Godot)



## Interesses

Tenho interesse em aprender mais sobre a seguintes áreas de tecnologia:

- *Desenvolvimento Web Fullstack*
- *Business Intelligence*
- *Desenvolvimento de Jogos*
- *Entre outras...*




