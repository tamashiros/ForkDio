# Alexandre Gasparini

## Bem Vindo!
#### Sou Alexandre Fernando Gasparini, entusiasta em Desenvolvimento de Softwares, 35 anos, Técnico em Desenvolvimento de Software pelo Centro Paula Souza (ETEC SP).
 
## Habilidades
![Python](https://img.shields.io/badge/PYTHON-yellow?style=for-the-badge&logo=python&logoColor=blue) ![PHP](https://img.shields.io/badge/PHP-777BB4?style=for-the-badge&logo=php&logoColor=white) ![JS](https://img.shields.io/badge/JAVASCRIPT-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E) ![MYSQL](https://img.shields.io/badge/MYSQL-005C84?style=for-the-badge&logo=mysql&logoColor=white) ![CSS3](https://img.shields.io/badge/CSS3-blue?style=for-the-badge&logo=css3&logoColor=white) ![HTML5](https://img.shields.io/badge/HTML5-orange?style=for-the-badge&logo=html5&logoColor=white) 


## Conecte-se comigo
[![Whatsapp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/5511991072362)  [![LinkedIn](https://img.shields.io/badge/LinkedIn-white?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alexandre-gasparini) [![Gmail](https://img.shields.io/badge/Gmail-black?style=for-the-badge&logo=Gmail)](mailto:alexandrefernandoo@gmail.com)
 [![GitHub](https://img.shields.io/badge/GitHub-gray?style=for-the-badge&logo=GitHub)](https://github.com/Alex-Gasparini)


## Cursos

![ETEC](https://img.shields.io/badge/ETEC_SP-red?style=for-the-badge&logo=etecsp&logoColor=white) ![COURSERA](https://img.shields.io/badge/COURSERA-0056D2?style=for-the-badge&logo=coursera&logoColor=white) ![DIO](https://img.shields.io/badge/DIO-black?style=for-the-badge&logo=dio)

## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alex-Gasparini&theme=transparent&bg_color=000&border_color=008000&show_icons=true&icon_color=008000&title_color=008000&hide_title=true&text_color=FFF)

## Minhas Contribuições

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Alex-Gasparini&repo=dio-lab-open-source&bg_color=000&border_color=008000&show_icons=true&icon_color=008000&title_color=008000&text_color=FFF)](https://github.com/Alex-Gasparini/dio-lab-open-source)