# Seja bem-vindo(a) ao meu perfil!! 



# 🚀 Sobre mim
Eu sou um futuro desenvolvedor fullstack. Atualmente, estudando tecnologias com ênfase em back-end porém, logo irei me aprofundar no front também.

Tenho 19 anos, e estou cursando a graduação de análise e desenvolvimento de sistemas.


## 🛠 Habilidades que estou aprendendo 
[![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)](https://www.markdownguide.org/)
[![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)](https://developer.mozilla.org/en-US/docs/Web/HTML)
[![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)](https://developer.mozilla.org/en-US/docs/Web/CSS)
[![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
[![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)](https://www.java.com/)
[![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C)](https://isocpp.org/)

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alex0925M&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Alex0925M&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)


## 🔗 Conecte-se comigo

[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alexmoirera/)
