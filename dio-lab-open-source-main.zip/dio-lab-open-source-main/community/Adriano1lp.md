# Olá eu sou o Adriano

Sou formado em Analise e desenvolvimento de Sistema, trabalhei dois anos como desenvolvedor Java, e hoje atuo como QA.

# Minha Rede

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)]https://www.linkedin.com/in/adriano-lima-76764085/