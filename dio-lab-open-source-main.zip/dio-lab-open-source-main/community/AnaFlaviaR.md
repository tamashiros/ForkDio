#  Flavia Reis

Olá, me chamo Flavia. 
Sou formada em Computação pela UECE e pós graduada em Análise e Desenvolvimento de Programas pela Universidade Descomplica, no momento estou a procura do meu primeiro emprego na área Dev, e continuo sempre estudando, buscando oportunidades e aprimorando meus conhecimentos para me tornar uma Dev Front-End.

## Conecte-se comigo

[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=FF00F6&color:FFF)](mailto:flavinhareis2000@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=FF00F6&color:FFF)](https://www.linkedin.com/in/ana-flavia-016413233/)
[![Instagram](https://img.shields.io/badge/-Instagram-000?style=for-the-badge&logo=instagram&logoColor=FF00F6&color:FFF)](https://www.instagram.com/aflaviareis/)



## Habilidades
 ![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript) 	![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white) ![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white) ![Boostrap](https://img.shields.io/badge/Bootstrap-563D7C?style=for-the-badge&logo=bootstrap&logoColor=white) ![Github](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)
 


## GitHub Stats
![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=AnaFlaviaR&theme=dark&show_icons=true)

[![Top Linguagens](https://github-readme-stats.vercel.app/api/top-langs/?username=AnaFlaviaR&theme=dark&show)](https://github.com/AnaFlaviaR/github-readme-stats)
