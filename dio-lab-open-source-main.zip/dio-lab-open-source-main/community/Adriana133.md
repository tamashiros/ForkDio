# Adriana Silva

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/adrianaa-silva/)

## Habilidades

[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)

![Java](https://img.shields.io/badge/Java-pink)
![Node.js](https://img.shields.io/badge/node-pink)
![AWS](https://img.shields.io/badge/aws-pink)

![SQL](https://img.shields.io/badge/SQL-pink)
![React](https://img.shields.io/badge/React-pink)
![HTML](https://img.shields.io/badge/HTML-pink)
![CSS](https://img.shields.io/badge/CSS-pink)

## GitHub Stats

## Minhas Contribuições
