# Alexya Adrianne
Olá! Eu me chamo Alexya Adrianne e escolhi estudar a ciência por traz dos dados. O primeiro curso que fiz foi o Bootcamp Santander 2023 de Data Science. 

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alexya-adrianne-6226a712b/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=GitHub&logoColor=0E76A8)](https://github.com/AlexyaAdrianne)

## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![SQL](https://img.shields.io/badge/SQL-000?style=for-the-badge&logo=SQL)
![PowerBI](https://img.shields.io/badge/PowerBI-000?style=for-the-badge&logo=powerbi)
![NoSQL](https://img.shields.io/badge/NoSQL-000?style=for-the-badge&logo=nosql)
![GIT](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git)
![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=SEUUSERNAME&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Leca&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

