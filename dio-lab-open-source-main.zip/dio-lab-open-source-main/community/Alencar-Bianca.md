#### Olá Pessoal! Eu me chamo Bianca

Futura Desenvolvedora Full Stack

#### 🌱 Estou estudando atualmente:
<div>
<img src="https://img.shields.io/badge/TypeScript-%232F74C0?style=flat-square&labelColor=%23414141&logo=typescript&logoColor=white" />
<img src="https://img.shields.io/badge/Angular-%23DE3641?style=flat-square&labelColor=%23414141&logo=angular&logoColor=white" />
<img src="https://img.shields.io/badge/Laravel-%23DB4512?style=flat-square&labelColor=%23414141&logo=Laravel" />
<img src="https://img.shields.io/badge/Git-%232E3641?style=flat-square&logo=Git&logoColor=white" />
</div>

#### 📫 Você pode me encontrar em:
[![DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://www.dio.me/users/bianca_re4)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-%230A66C2?style=flat-square&labelColor=%230A66C2&logo=linkedin&logoColor=black&link=https://www.linkedin.com/in/bianca-a-246b36a8/)](https://www.linkedin.com/in/bianca-a-246b36a8/)
[![Twitter](https://img.shields.io/badge/-Twitter-1ca0f1?style=flat-square&labelColor=1ca0f1&logo=twitter&logoColor=black&link=https://twitter.com/alencarbianca1)](https://twitter.com/alencarbianca1)
