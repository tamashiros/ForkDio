[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Press+Start+2P&size=24&pause=1000&color=00D800&vCenter=true&random=false&width=435&lines=HELLO%2C+WORLD!++%3D%5D)](https://git.io/typing-svg)


## Sobre mim

Me chamo Thiago, tenho 19 anos, estou entrando agora no mundo de T.I com o curso de programação do zero da DIO, e espero aprender pelo menos o básico, o suficiente para conseguir um bom emprego e trabalhar.