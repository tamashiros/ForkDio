
## 🚀 Sobre mim
Olá ✌️

Bem vindo ao meu perfil! 🥳

Eu sou a Ana Carolina,

Estou em processo de migração de carreira, atualmente cursando *Análise e Desenvolvimento de Sistemas* 📚...

E em paralelo fazendo alguns cursos sobre C#, Power Platform e Dynamics 🥰


![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alysiaa&show_icons=true&theme=dark&include_all_commits=true&count_private=true)

![GitHub Stats](https://github-readme-stats.vercel.app/api/top-langs/?username=Alysiaa&layout=compact&langs_count=7&theme=dark)

## 🛠 Habilidades
C#, Power Platform, Dynamics ...

## Conecte-se Comigo 🎈

[![LinkedIn](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/ana-carolina-96b07a28b/)